var require = meteorInstall({"both":{"methods":{"insert":{"invitations.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/methods/insert/invitations.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
  sendInvitation(invitation) {
    check(invitation, {
      email: String,
      role: String
    });

    try {
      Modules.server.sendInvitation({
        email: invitation.email,
        token: Random.hexString(16),
        role: invitation.role,
        date: new Date().toISOString()
      });
    } catch (exception) {
      return exception;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/methods/insert/users.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
  acceptInvitation(user) {
    check(user, {
      email: String,
      password: Object,
      token: String
    });

    try {
      var userId = Modules.server.acceptInvitation(user);
      return userId;
    } catch (exception) {
      return exception;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"read":{"collection.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/methods/read/collection.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
  readMethod(argument) {
    check(argument, String);
    var document = Collection.findOne(argument);

    if (!document) {
      throw new Meteor.Error('document-not-found', 'No documents found matching this query.');
    }

    return document;
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"remove":{"invitations.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/methods/remove/invitations.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
  revokeInvitation(inviteId) {
    check(inviteId, String);

    try {
      Invitations.remove(inviteId);
    } catch (exception) {
      return exception;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"update":{"users.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/methods/update/users.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
  setRoleOnUser(options) {
    check(options, {
      user: String,
      role: String
    });

    try {
      Roles.setUserRoles(options.user, [options.role]);
    } catch (exception) {
      return exception;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"modules":{"_modules.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/modules/_modules.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Modules = {};
Modules.both = {};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"redirect-users.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/modules/redirect-users.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let route = options => {
  return options && options.redirect ? _sendUserToDefault(options.redirect) : _sendUserToDefault();
};

let _sendUserToDefault = redirect => {
  let roles = _getCurrentUserRoles();

  if (roles[0] === 'admin') {
    _redirectUser('users', redirect);
  }

  if (roles[0] === 'manager') {
    _redirectUser('managers', redirect);
  }

  if (roles[0] === 'employee') {
    _redirectUser('employees', redirect);
  }
};

let _getCurrentUserRoles = () => {
  return Roles.getRolesForUser(Meteor.userId());
};

let _redirectUser = (path, redirect) => {
  if (redirect) {
    redirect(path);
  } else {
    FlowRouter.go(FlowRouter.path(path));
  }
};

Modules.both.redirectUser = route;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"startup.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/modules/startup.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let startup = () => {};

Modules.both.startup = startup;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"routes":{"authenticated.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/routes/authenticated.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
const authenticatedRedirect = () => {
  if (!Meteor.loggingIn() && !Meteor.userId()) {
    FlowRouter.go('login');
  }
};

const blockUnauthorizedAdmin = (context, redirect) => {
  if (Meteor.userId() && !Roles.userIsInRole(Meteor.userId(), 'admin')) {
    Modules.both.redirectUser({
      redirect: redirect
    });
  }
};

const blockUnauthorizedManager = (context, redirect) => {
  if (Meteor.userId() && !Roles.userIsInRole(Meteor.userId(), ['admin', 'manager'])) {
    Modules.both.redirectUser({
      redirect: redirect
    });
  }
};

const authenticatedRoutes = FlowRouter.group({
  name: 'authenticated',
  triggersEnter: [authenticatedRedirect]
});
authenticatedRoutes.route('/users', {
  name: 'users',
  triggersEnter: [blockUnauthorizedAdmin],

  action() {
    BlazeLayout.render('default', {
      yield: 'users'
    });
  }

});
authenticatedRoutes.route('/managers', {
  name: 'managers',
  triggersEnter: [blockUnauthorizedManager],

  action() {
    BlazeLayout.render('default', {
      yield: 'managers'
    });
  }

});
authenticatedRoutes.route('/employees', {
  name: 'employees',

  action() {
    BlazeLayout.render('default', {
      yield: 'employees'
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"configure.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/routes/configure.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
FlowRouter.notFound = {
  action() {
    BlazeLayout.render('default', {
      yield: 'notFound'
    });
  }

};
Accounts.onLogin(() => {
  let currentRoute = FlowRouter.current();

  if (currentRoute && currentRoute.route.group.name === 'public') {
    Modules.both.redirectUser();
  }
});

if (Meteor.isClient) {
  Tracker.autorun(() => {
    if (!Meteor.userId() && FlowRouter.current().route) {
      FlowRouter.go('login');
    }
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"public.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/routes/public.js                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
const publicRedirect = (context, redirect) => {
  if (Meteor.userId()) {
    Modules.both.redirectUser({
      redirect: redirect
    });
  }
};

const publicRoutes = FlowRouter.group({
  name: 'public',
  triggersEnter: [publicRedirect]
});
publicRoutes.route('/invite/:token', {
  name: 'invite',

  action() {
    BlazeLayout.render('default', {
      yield: 'invite'
    });
  }

});
publicRoutes.route('/login', {
  name: 'login',

  action() {
    BlazeLayout.render('default', {
      yield: 'login'
    });
  }

});
publicRoutes.route('/recover-password', {
  name: 'recover-password',

  action() {
    BlazeLayout.render('default', {
      yield: 'recoverPassword'
    });
  }

});
publicRoutes.route('/reset-password/:token', {
  name: 'reset-password',

  action() {
    BlazeLayout.render('default', {
      yield: 'resetPassword'
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"startup.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/startup.js                                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(() => Modules.both.startup());
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"course":{"courses.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/course/courses.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.Courses = new meteor_rxjs_1.MongoObservable.Collection('courses');
exports.CourseSubjects = new meteor_rxjs_1.MongoObservable.Collection('course_subjects');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"hivdb":{"index.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/hivdb/index.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var predictions_1 = require("./predictions");
exports.Predictions = predictions_1.Predictions;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"predictions.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/hivdb/predictions.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.Predictions = new meteor_rxjs_1.MongoObservable.Collection('predictions');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactional":{"accounts.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/transactional/accounts.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.TransactionAccounts = new meteor_rxjs_1.MongoObservable.Collection('transaction_accounts');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/transactional/index.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./transactions"));
__export(require("/collections/transactional/accounts"));
__export(require("./references"));

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"references.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/transactional/references.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.TransactionReferences = new meteor_rxjs_1.MongoObservable.Collection('references');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"transactions.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/transactional/transactions.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.Transactions = new meteor_rxjs_1.MongoObservable.Collection('transactions');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"users":{"index.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/users/index.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./users"));
__export(require("./invitations"));

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"invitations.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/users/invitations.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var SimpleSchema_1 = require("simpl-schema/dist/SimpleSchema");
exports.Invitations = new Mongo.Collection('invitations');
exports.Invitations.allow({
    insert: function () { return false; },
    update: function () { return false; },
    remove: function () { return false; }
});
exports.Invitations.deny({
    insert: function () { return true; },
    update: function () { return true; },
    remove: function () { return true; }
});
var InvitationsSchema = new SimpleSchema_1.SimpleSchema({
    email: {
        type: String,
        label: 'Email to send invitation to.'
    },
    token: {
        type: String,
        label: 'Invitation token.'
    },
    role: {
        type: String,
        label: 'Role to apply to the user.'
    },
    date: {
        type: String,
        label: 'Invitation Date'
    }
});
exports.Invitations.attachSchema(InvitationsSchema);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/users/users.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
var meteor_1 = require("meteor/meteor");
meteor_1.Meteor.users.allow({
    insert: function () { return false; },
    update: function () { return false; },
    remove: function () { return false; }
});
meteor_1.Meteor.users.deny({
    insert: function () { return true; },
    update: function () { return true; },
    remove: function () { return true; }
});
exports.Users = meteor_rxjs_1.MongoObservable.fromExisting(meteor_1.Meteor.users);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chats.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/chats.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.Chats = new meteor_rxjs_1.MongoObservable.Collection('chats');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/index.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("/collections/chats"));
__export(require("./messages"));
var courses_1 = require("/collections/course/courses");
exports.Courses = courses_1.Courses;
exports.CourseSubjects = courses_1.CourseSubjects;
__export(require("/collections/transactional/index"));
__export(require("./students"));
var users_1 = require("/collections/users/index");
exports.Users = users_1.Users;
exports.Invitations = users_1.Invitations;
__export(require("/collections/hivdb/index"));

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"messages.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/messages.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.Messages = new meteor_rxjs_1.MongoObservable.Collection('messages');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"students.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/students.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.StudentsData = new meteor_rxjs_1.MongoObservable.Collection('studentsData');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"publications":{"chats.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/chats.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor['publishComposite']('chats', function () {
    var _this = this;
    if (!this.userId) {
        return;
    }
    return {
        find: function () {
            return collections_1.Chats.collection.find({ memberIds: _this.userId });
        },
        children: [
            {
                find: function (chat) {
                    return collections_1.Messages.collection.find({ chatId: chat._id }, {
                        sort: { createdAt: -1 },
                        limit: 1
                    });
                }
            },
            {
                find: function (chat) {
                    return collections_1.Users.collection.find({
                        _id: { $in: chat.memberIds }
                    }, {
                        fields: { profile: 1 }
                    });
                }
            }
        ]
    };
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"courses.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/courses.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var alanning_roles_1 = require("meteor/alanning:roles");
var collections_1 = require("../../collections");
Meteor['publishComposite']('courses', function () {
    var _this = this;
    var loggedInUser = Meteor.user();
    if (!this.userId) {
        return;
    }
    if (!loggedInUser) {
        throw new Meteor.Error(403, 'Authentication failed');
    }
    if (!alanning_roles_1.Roles.userIsInRole(loggedInUser, ['tutor', 'manage-courses', 'view-courses', 'admin', 'super-admin'], alanning_roles_1.Roles.GLOBAL_GROUP)) {
        throw new Meteor.Error(403, 'Access denied');
    }
    return {
        find: function () {
            return collections_1.Courses.collection.find({ ownership: _this.userId });
        },
        children: [
            {
                find: function (course) {
                    return collections_1.CourseSubjects.collection.find({ courseId: course._id }, {
                        sort: { createdAt: -1 },
                        limit: 1
                    });
                }
            }
        ]
    };
});
Meteor.publish('subjects', function () {
    var loggedInUser = Meteor.user();
    if (!loggedInUser ||
        !alanning_roles_1.Roles.userIsInRole(loggedInUser, ['tutor', 'manage-courses', 'view-courses', 'admin', 'super-admin'], 'courses')) {
        throw new Meteor.Error(403, 'Access denied');
    }
    return collections_1.CourseSubjects.collection.find({ courseId: loggedInUser._id });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"invite.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/invite.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var invitations_1 = require("../../collections/users/invitations");
Meteor.publish('invite', function (token) {
    check(token, String);
    return invitations_1.Invitations.find({ 'token': token });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"messages.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/messages.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor.publish('messages', function (chatId, messagesBatchCounter) {
    if (!this.userId || !chatId) {
        console.log('Invalid User!!!');
        return;
    }
    return collections_1.Messages.collection.find({
        chatId: chatId
    }, {
        sort: { createdAt: -1 },
        limit: 30 * messagesBatchCounter
    });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"predictions.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/predictions.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor.publish('predictions', function () {
    //Predictions.publish(this, 'total-predictions', Predictions.find());
    return collections_1.Predictions.find({});
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"students.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/students.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor.publish('studentsData', function () {
    return collections_1.StudentsData.collection.find();
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"transactions.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/transactions.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor.publish('transactions', function () {
    return collections_1.Transactions.collection.find({});
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"transactions_accounts.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/transactions_accounts.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Transactional
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor.publish('transaction_accounts', function () {
    return collections_1.TransactionAccounts.collection.find({ ownerId: Meteor.userId() });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/users.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor.publish('users', function () {
    var isAdmin = Roles.userIsInRole(this.userId, ['manage-users', 'admin'], 'users');
    if (isAdmin) {
        return [
            collections_1.Users.find({}, { fields: { 'emails.address': 1, 'roles': 1 } }),
            collections_1.Invitations.find({}, { fields: { 'email': 1, 'role': 1, 'date': 1 } })
        ];
    }
    else {
        return null;
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
///<reference path="../node_modules/@types/meteor-roles/index.d.ts"/>
var collections_1 = require("../collections");
var collections_2 = require("../collections");
var models_1 = require("./models");
var check_1 = require("meteor/check");
var promise_1 = require("meteor/promise");
var nonEmptyString = check_1.Match.Where(function (str) {
    check_1.check(str, String);
    return str.length > 0;
});
var getStanfordURL = "https://hivdb.stanford.edu";
var timeout = 50000;
Meteor.methods({
    addChat: function (receiverId) {
        if (!this.userId) {
            throw new Meteor.Error('unauthorized', 'User must be logged-in to create a new chat');
        }
        check_1.check(receiverId, nonEmptyString);
        if (receiverId === this.userId) {
            throw new Meteor.Error('illegal-receiver', 'Receiver must be different than the current logged in user');
        }
        var chatExists = !!collections_1.Chats.collection.find({
            memberIds: { $all: [this.userId, receiverId] }
        }).count();
        if (chatExists) {
            throw new Meteor.Error('chat-exists', 'Chat already exists');
        }
        var chat = {
            memberIds: [this.userId, receiverId]
        };
        collections_1.Chats.insert(chat);
    },
    removeChat: function (chatId) {
        if (!this.userId) {
            throw new Meteor.Error('unauthorized', 'User must be logged-in to remove chat');
        }
        check_1.check(chatId, nonEmptyString);
        var chatExists = !!collections_1.Chats.collection.find(chatId).count();
        if (!chatExists) {
            throw new Meteor.Error('chat-not-exists', 'Chat doesn\'t exist');
        }
        collections_1.Chats.remove(chatId);
    },
    updateProfile: function (profile) {
        if (!this.userId) {
            throw new Meteor.Error('unauthorized', 'User must be logged-in to create a new chat');
        }
        check_1.check(profile, {
            name: nonEmptyString
        });
        Meteor.users.update(this.userId, {
            $set: { profile: profile }
        });
    },
    addRoleToUser: function (userId, role, group) {
        if (group) {
            Roles.addUsersToRoles(userId, role, group);
        }
        else {
            Roles.addUsersToRoles(userId, role);
        }
    },
    removeRoleFromUser: function (userId, role, group) {
        if (group) {
            Roles.addUsersToRoles(userId, role, group);
        }
        else {
            Roles.addUsersToRoles(userId, role);
        }
    },
    addCourse: function (courseName, courseDescription) {
        if (!this.userId) {
            throw new Meteor.Error('unauthorized', 'User must be logged-in to create a new course');
        }
        check_1.check(courseName, String);
        check_1.check(courseDescription, String);
        return {
            course: collections_1.Courses.collection.insert({
                name: courseName,
                ownership: this.userId,
                description: courseDescription
            })
        };
    },
    addMessage: function (type, chatId, content) {
        if (!this.userId) {
            throw new Meteor.Error('unauthorized', 'User must be logged-in to create a new chat');
        }
        check_1.check(type, check_1.Match.OneOf(String, [models_1.MessageType.TEXT]));
        check_1.check(chatId, nonEmptyString);
        check_1.check(content, nonEmptyString);
        var chatExists = !!collections_1.Chats.collection.find(chatId).count();
        if (!chatExists) {
            throw new Meteor.Error('chat-not-exists', 'Chat doesn\'t exist');
        }
        return {
            messageId: collections_2.Messages.collection.insert({
                chatId: chatId,
                senderId: this.userId,
                content: content,
                createdAt: new Date(),
                type: type
            })
        };
    },
    countMessages: function () {
        return collections_2.Messages.collection.find().count();
    },
    createSystemUser: function (email, password) {
        Accounts.createUser({ email: password });
    },
    predict: function (body, isSequence) {
        if (!this.userId) {
            throw new Meteor.Error('unauthorized', 'User must be logged-in to create a new request');
        }
        console.log('body', body);
        var bodyFormatted = {};
        var query = {};
        if (isSequence) {
            bodyFormatted = { "sequences": JSON.parse(body.sequences) };
            console.log(bodyFormatted);
            query = {
                operationName: "example",
                query: "query example($sequences: [UnalignedSequenceInput]!) {   viewer {     currentVersion { text, publishDate },     sequenceAnalysis(sequences: $sequences) {         inputSequence {         header,         sequence,         MD5,         SHA512       },       validationResults {         level,         message       },       absoluteFirstNA,       alignedGeneSequences {         gene {           name,           consensus,           length,           drugClasses {             name,             fullName,             drugs {               name,               displayAbbr,               fullName             }           },           mutationTypes         },         firstAA,         lastAA,         firstNA,         lastNA,         matchPcnt,         prettyPairwise {           positionLine,           refAALine,           alignedNAsLine,           mutationLine         },         mutations {           consensus,           position,           AAs,           triplet,           insertedNAs,           isInsertion,           isDeletion,           isIndel,           isAmbiguous,           isApobecMutation,           isApobecDRM,           hasStop,           isUnusual,           types,           primaryType,           comments {             triggeredAAs,             type,             text           },           text,           shortText         },         APOBEC: mutations(filterOptions: [APOBEC]) {           position,           AAs,           text         },         APOBEC_DRM: mutations(filterOptions: [APOBEC_DRM]) {           text         },         DRM: mutations(filterOptions: [DRM]) {           text         },         SDRM: mutations(filterOptions: [SDRM]) {           text         },         unusualMutations: mutations(filterOptions: [UNUSUAL]) {           text         },         treatmentSelectedMutations: mutations(           filterOptions: [PI_TSM, NRTI_TSM, NNRTI_TSM, INSTI_TSM]         ) {           text         },         frameShifts {           position,           isInsertion,           isDeletion,           size,           NAs,           text         }       },       firstTenCloseSubtypes: subtypesV2(first: 10) {         displayWithoutDistance,         distancePcnt,         referenceAccession       },       bestMatchingSubtype { display },       mixturePcnt,       mutations {         position,         AAs,         shortText       },       frameShifts {         text       },       drugResistance {         gene {           name,           consensus,           length,           drugClasses { name },           mutationTypes         },         drugScores {           drugClass {             name,             fullName,             drugs {               name,               displayAbbr,               fullName             }           },           drug { displayAbbr },           SIR,           score,           level,           text,           partialScores {             mutations {               text             },             score           }         },         mutationsByTypes {           mutationType,           mutations {             consensus,             position,             AAs,             triplet,             insertedNAs,             isInsertion,             isDeletion,             isIndel,             isAmbiguous,             isApobecMutation,             isApobecDRM,             hasStop,             isUnusual,             text,             shortText           }         }         commentsByTypes {           commentType,           comments {             type,             text,             highlightText           }         }       }         }   } }",
                variables: bodyFormatted
            };
        }
        else {
            bodyFormatted = { "mutations": JSON.parse(body.mutations) };
            query = {
                query: "query example($mutations:[String]!) {  viewer {    currentVersion { text, publishDate },    mutationsAnalysis(mutations: $mutations) {      validationResults {level,         message       },       drugResistance {         gene { name },         drugScores {           drugClass { name },           drug { name,displayAbbr,fullName},           SIR,           score,           level,           text,           partialScores {             mutations {               text             },             score           }         },         mutationsByTypes {           mutationType,           mutations {             text           }         }         commentsByTypes {           commentType,           comments {             text           }         }       }     }   } }",
                variables: bodyFormatted
            };
        }
        console.log(bodyFormatted);
        console.log(query);
        var theBody = JSON.stringify(query);
        var preditionRequest = {
            requestedBy: this.userId,
            request: theBody,
            response: 'PENDING',
            createdAt: new Date()
        };
        var predictionId = collections_1.Predictions.collection.insert(preditionRequest);
        console.log('Save Prediction ' + predictionId);
        console.log('Sending ' + theBody);
        var options = {
            host: getStanfordURL,
            path: '/graphql',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        };
        var fetch = require('node-fetch');
        var theResponse = '';
        promise_1.Promise.await(theResponse = fetch(options.host + options.path, {
            method: options.method,
            headers: { 'Content-Type': 'application/json' },
            body: theBody
        })
            .then(function (response) { return response.json(); })
            .then(function (response) { return response.data.viewer; })
            .then(function (response) {
            //update response
            collections_1.Predictions.collection.update(predictionId, { $set: { response: JSON.stringify(response) } });
            return response;
        })
            .catch(function (err) {
            return err;
        }));
        console.log(theResponse);
        return theResponse;
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"models.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/models.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_PICTURE_URL = '/assets/default-profile-pic.svg';
var MessageType;
(function (MessageType) {
    MessageType[MessageType["TEXT"] = 'text'] = "TEXT";
    MessageType[MessageType["LOCATION"] = 'location'] = "LOCATION";
    MessageType[MessageType["PICTURE"] = 'picture'] = "PICTURE";
})(MessageType = exports.MessageType || (exports.MessageType = {}));
var QuestionType;
(function (QuestionType) {
    QuestionType["OPEN_ENDED"] = "OPEN_ENDED";
    QuestionType["MULTIPLE_CHOICE"] = "MULTIPLE_CHOICE";
    QuestionType["BROKEN_PASSAGE"] = "BROKEN_PASSAGE";
    QuestionType["MATCHING"] = "MATCHING";
})(QuestionType = exports.QuestionType || (exports.QuestionType = {}));
var RolesEnum;
(function (RolesEnum) {
    RolesEnum["ADMIN"] = "ADMIN";
    RolesEnum["SUPER_ADMIN"] = "SUPER_ADMIN";
    RolesEnum["TUTOR"] = "TUTOR";
    RolesEnum["STUDENT"] = "STUDENT";
    RolesEnum["PARENT"] = "PARENT";
})(RolesEnum = exports.RolesEnum || (exports.RolesEnum = {}));
var ActionPermissionsEnum;
(function (ActionPermissionsEnum) {
    ActionPermissionsEnum["CREATE"] = "CREATE";
    ActionPermissionsEnum["VIEW"] = "VIEW";
    ActionPermissionsEnum["UPDATE"] = "UPDATE";
    ActionPermissionsEnum["DELETE"] = "DELETE";
})(ActionPermissionsEnum = exports.ActionPermissionsEnum || (exports.ActionPermissionsEnum = {}));
var TransactionType;
(function (TransactionType) {
    TransactionType["BALANCE_INQUIRY"] = "BALANCE_INQUIRY";
    TransactionType["FUNDS_TRANSFER"] = "FUNDS_TRANSFER";
})(TransactionType = exports.TransactionType || (exports.TransactionType = {}));
var TransactionDirection;
(function (TransactionDirection) {
    TransactionDirection["FORWARD"] = "FORWARD";
    TransactionDirection["REVERSAL"] = "REVERSAL";
})(TransactionDirection = exports.TransactionDirection || (exports.TransactionDirection = {}));
var TransactionStatus;
(function (TransactionStatus) {
    TransactionStatus["POSTED"] = "POSTED";
    TransactionStatus["PROCESSING"] = "PROCESSING";
    TransactionStatus["PROCESSED"] = "PROCESSED";
    TransactionStatus["FAILED"] = "FAILED";
})(TransactionStatus = exports.TransactionStatus || (exports.TransactionStatus = {}));

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
// Listen to incoming HTTP requests (can only be used on the server).
var webapp_1 = require("meteor/webapp");
var collections_1 = require("../collections");
var hivdb_1 = require("../collections/hivdb");
var ros_publish_counts_1 = require("meteor/ros:publish-counts");
Meteor.publish('predictions.count', function (_a) {
    ros_publish_counts_1.Counts.publish(this, 'predictions.count', hivdb_1.Predictions.find());
});
webapp_1.WebApp.connectHandlers.use('/hello', function (req, res, next) {
    res.writeHead(200);
    res.end("Hello world from: " + Meteor.release);
}).use('/courses', function (req, res, next) {
    res.writeHead(200);
    res.end(JSON.stringify(collections_1.Courses.collection.find({}).fetch()));
}).use('/courses/id', function (req, res, next) {
    res.writeHead(200);
    res.end(JSON.stringify(collections_1.Courses.collection.findOne({})));
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var accounts_base_1 = require("meteor/accounts-base");
var users_1 = require("../collections/users");
function countActive() {
    return 0;
}
function insert(tx) {
    console.log('custom method :tx insert simulated.' + tx.status);
    return true;
}
function exists() {
    console.log('custom method :tx insert simulated.');
    return true;
}
meteor_1.Meteor.startup(function () {
    //console.log(Accounts);
    //Accounts._bcryptRounds = 10;
    if (meteor_1.Meteor.settings) {
        //Object.assign(Accounts._options, Meteor.settings['accounts-phone']);
        // SMS.twilio = Meteor.settings['twilio'];
    }
    if (users_1.Users.collection.find().count() > 0) {
        return;
    }
    accounts_base_1.Accounts.createUser({
        username: "julius",
        email: "juliusgitonga56@gmail.com",
        password: "John2Home2",
        profile: {
            name: "Julius Muruthi"
        }
    });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts"
  ]
});

require("/both/methods/insert/invitations.js");
require("/both/methods/insert/users.js");
require("/both/methods/read/collection.js");
require("/both/methods/remove/invitations.js");
require("/both/methods/update/users.js");
require("/both/modules/_modules.js");
require("/both/modules/redirect-users.js");
require("/both/modules/startup.js");
require("/both/routes/authenticated.js");
require("/both/routes/configure.js");
require("/both/routes/public.js");
require("/collections/course/courses.js");
require("/collections/hivdb/index.js");
require("/collections/hivdb/predictions.js");
require("/collections/transactional/accounts.js");
require("/collections/transactional/index.js");
require("/collections/transactional/references.js");
require("/collections/transactional/transactions.js");
require("/collections/users/index.js");
require("/collections/users/invitations.js");
require("/collections/users/users.js");
require("/server/publications/chats.js");
require("/server/publications/courses.js");
require("/server/publications/invite.js");
require("/server/publications/messages.js");
require("/server/publications/predictions.js");
require("/server/publications/students.js");
require("/server/publications/transactions.js");
require("/server/publications/transactions_accounts.js");
require("/server/publications/users.js");
require("/both/startup.js");
require("/collections/chats.js");
require("/collections/index.js");
require("/collections/messages.js");
require("/collections/students.js");
require("/server/methods.js");
require("/server/models.js");
require("/server/publications.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvYm90aC9tZXRob2RzL2luc2VydC9pbnZpdGF0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9tZXRob2RzL2luc2VydC91c2Vycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9tZXRob2RzL3JlYWQvY29sbGVjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9tZXRob2RzL3JlbW92ZS9pbnZpdGF0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9tZXRob2RzL3VwZGF0ZS91c2Vycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9tb2R1bGVzL19tb2R1bGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9ib3RoL21vZHVsZXMvcmVkaXJlY3QtdXNlcnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvbW9kdWxlcy9zdGFydHVwLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9ib3RoL3JvdXRlcy9hdXRoZW50aWNhdGVkLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9ib3RoL3JvdXRlcy9jb25maWd1cmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvcm91dGVzL3B1YmxpYy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9zdGFydHVwLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy9jb3Vyc2UvY291cnNlcy50cyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvaGl2ZGIvaW5kZXgudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL2NvbGxlY3Rpb25zL2hpdmRiL3ByZWRpY3Rpb25zLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy90cmFuc2FjdGlvbmFsL2FjY291bnRzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy90cmFuc2FjdGlvbmFsL2luZGV4LnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy90cmFuc2FjdGlvbmFsL3JlZmVyZW5jZXMudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL2NvbGxlY3Rpb25zL3RyYW5zYWN0aW9uYWwvdHJhbnNhY3Rpb25zLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy91c2Vycy9pbmRleC50cyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvdXNlcnMvaW52aXRhdGlvbnMudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL2NvbGxlY3Rpb25zL3VzZXJzL3VzZXJzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy9jaGF0cy50cyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvaW5kZXgudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL2NvbGxlY3Rpb25zL21lc3NhZ2VzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy9zdHVkZW50cy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy9jaGF0cy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy9jb3Vyc2VzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcHVibGljYXRpb25zL2ludml0ZS50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy9tZXNzYWdlcy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy9wcmVkaWN0aW9ucy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy9zdHVkZW50cy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy90cmFuc2FjdGlvbnMudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wdWJsaWNhdGlvbnMvdHJhbnNhY3Rpb25zX2FjY291bnRzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcHVibGljYXRpb25zL3VzZXJzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kcy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21vZGVscy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4udHMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibWV0aG9kcyIsInNlbmRJbnZpdGF0aW9uIiwiaW52aXRhdGlvbiIsImNoZWNrIiwiZW1haWwiLCJTdHJpbmciLCJyb2xlIiwiTW9kdWxlcyIsInNlcnZlciIsInRva2VuIiwiUmFuZG9tIiwiaGV4U3RyaW5nIiwiZGF0ZSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsImV4Y2VwdGlvbiIsImFjY2VwdEludml0YXRpb24iLCJ1c2VyIiwicGFzc3dvcmQiLCJPYmplY3QiLCJ1c2VySWQiLCJyZWFkTWV0aG9kIiwiYXJndW1lbnQiLCJkb2N1bWVudCIsIkNvbGxlY3Rpb24iLCJmaW5kT25lIiwiRXJyb3IiLCJyZXZva2VJbnZpdGF0aW9uIiwiaW52aXRlSWQiLCJJbnZpdGF0aW9ucyIsInJlbW92ZSIsInNldFJvbGVPblVzZXIiLCJvcHRpb25zIiwiUm9sZXMiLCJzZXRVc2VyUm9sZXMiLCJib3RoIiwicm91dGUiLCJyZWRpcmVjdCIsIl9zZW5kVXNlclRvRGVmYXVsdCIsInJvbGVzIiwiX2dldEN1cnJlbnRVc2VyUm9sZXMiLCJfcmVkaXJlY3RVc2VyIiwiZ2V0Um9sZXNGb3JVc2VyIiwicGF0aCIsIkZsb3dSb3V0ZXIiLCJnbyIsInJlZGlyZWN0VXNlciIsInN0YXJ0dXAiLCJhdXRoZW50aWNhdGVkUmVkaXJlY3QiLCJsb2dnaW5nSW4iLCJibG9ja1VuYXV0aG9yaXplZEFkbWluIiwiY29udGV4dCIsInVzZXJJc0luUm9sZSIsImJsb2NrVW5hdXRob3JpemVkTWFuYWdlciIsImF1dGhlbnRpY2F0ZWRSb3V0ZXMiLCJncm91cCIsIm5hbWUiLCJ0cmlnZ2Vyc0VudGVyIiwiYWN0aW9uIiwiQmxhemVMYXlvdXQiLCJyZW5kZXIiLCJ5aWVsZCIsIm5vdEZvdW5kIiwiQWNjb3VudHMiLCJvbkxvZ2luIiwiY3VycmVudFJvdXRlIiwiY3VycmVudCIsImlzQ2xpZW50IiwiVHJhY2tlciIsImF1dG9ydW4iLCJwdWJsaWNSZWRpcmVjdCIsInB1YmxpY1JvdXRlcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxPQUFQLENBQWU7QUFDYkMsZ0JBQWMsQ0FBRUMsVUFBRixFQUFlO0FBQzNCQyxTQUFLLENBQUVELFVBQUYsRUFBYztBQUNqQkUsV0FBSyxFQUFFQyxNQURVO0FBRWpCQyxVQUFJLEVBQUVEO0FBRlcsS0FBZCxDQUFMOztBQUtBLFFBQUk7QUFDRkUsYUFBTyxDQUFDQyxNQUFSLENBQWVQLGNBQWYsQ0FBOEI7QUFDNUJHLGFBQUssRUFBRUYsVUFBVSxDQUFDRSxLQURVO0FBRTVCSyxhQUFLLEVBQUVDLE1BQU0sQ0FBQ0MsU0FBUCxDQUFrQixFQUFsQixDQUZxQjtBQUc1QkwsWUFBSSxFQUFFSixVQUFVLENBQUNJLElBSFc7QUFJNUJNLFlBQUksRUFBSSxJQUFJQyxJQUFKLEVBQUYsQ0FBZUMsV0FBZjtBQUpzQixPQUE5QjtBQU1ELEtBUEQsQ0FPRSxPQUFPQyxTQUFQLEVBQW1CO0FBQ25CLGFBQU9BLFNBQVA7QUFDRDtBQUNGOztBQWpCWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQUFoQixNQUFNLENBQUNDLE9BQVAsQ0FBZTtBQUNiZ0Isa0JBQWdCLENBQUVDLElBQUYsRUFBUztBQUN2QmQsU0FBSyxDQUFFYyxJQUFGLEVBQVE7QUFDWGIsV0FBSyxFQUFFQyxNQURJO0FBRVhhLGNBQVEsRUFBRUMsTUFGQztBQUdYVixXQUFLLEVBQUVKO0FBSEksS0FBUixDQUFMOztBQU1BLFFBQUk7QUFDRixVQUFJZSxNQUFNLEdBQUdiLE9BQU8sQ0FBQ0MsTUFBUixDQUFlUSxnQkFBZixDQUFpQ0MsSUFBakMsQ0FBYjtBQUNBLGFBQU9HLE1BQVA7QUFDRCxLQUhELENBR0UsT0FBT0wsU0FBUCxFQUFtQjtBQUNuQixhQUFPQSxTQUFQO0FBQ0Q7QUFDRjs7QUFkWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQUFoQixNQUFNLENBQUNDLE9BQVAsQ0FBZTtBQUNicUIsWUFBVSxDQUFFQyxRQUFGLEVBQWE7QUFDckJuQixTQUFLLENBQUVtQixRQUFGLEVBQVlqQixNQUFaLENBQUw7QUFFQSxRQUFJa0IsUUFBUSxHQUFHQyxVQUFVLENBQUNDLE9BQVgsQ0FBb0JILFFBQXBCLENBQWY7O0FBRUEsUUFBSyxDQUFDQyxRQUFOLEVBQWlCO0FBQ2YsWUFBTSxJQUFJeEIsTUFBTSxDQUFDMkIsS0FBWCxDQUFrQixvQkFBbEIsRUFBd0MseUNBQXhDLENBQU47QUFDRDs7QUFFRCxXQUFPSCxRQUFQO0FBQ0Q7O0FBWFksQ0FBZixFOzs7Ozs7Ozs7OztBQ0FBeEIsTUFBTSxDQUFDQyxPQUFQLENBQWU7QUFDYjJCLGtCQUFnQixDQUFFQyxRQUFGLEVBQWE7QUFDM0J6QixTQUFLLENBQUV5QixRQUFGLEVBQVl2QixNQUFaLENBQUw7O0FBRUEsUUFBSTtBQUNGd0IsaUJBQVcsQ0FBQ0MsTUFBWixDQUFvQkYsUUFBcEI7QUFDRCxLQUZELENBRUUsT0FBT2IsU0FBUCxFQUFtQjtBQUNuQixhQUFPQSxTQUFQO0FBQ0Q7QUFDRjs7QUFUWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQUFoQixNQUFNLENBQUNDLE9BQVAsQ0FBZTtBQUNiK0IsZUFBYSxDQUFFQyxPQUFGLEVBQVk7QUFDdkI3QixTQUFLLENBQUU2QixPQUFGLEVBQVc7QUFDZGYsVUFBSSxFQUFFWixNQURRO0FBRWRDLFVBQUksRUFBRUQ7QUFGUSxLQUFYLENBQUw7O0FBS0EsUUFBSTtBQUNGNEIsV0FBSyxDQUFDQyxZQUFOLENBQW9CRixPQUFPLENBQUNmLElBQTVCLEVBQWtDLENBQUVlLE9BQU8sQ0FBQzFCLElBQVYsQ0FBbEM7QUFDRCxLQUZELENBRUUsT0FBT1MsU0FBUCxFQUFtQjtBQUNuQixhQUFPQSxTQUFQO0FBQ0Q7QUFDRjs7QUFaWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQUFSLE9BQU8sR0FBUSxFQUFmO0FBQ0FBLE9BQU8sQ0FBQzRCLElBQVIsR0FBZSxFQUFmLEM7Ozs7Ozs7Ozs7O0FDREEsSUFBSUMsS0FBSyxHQUFLSixPQUFGLElBQWU7QUFDekIsU0FBT0EsT0FBTyxJQUFJQSxPQUFPLENBQUNLLFFBQW5CLEdBQThCQyxrQkFBa0IsQ0FBRU4sT0FBTyxDQUFDSyxRQUFWLENBQWhELEdBQXVFQyxrQkFBa0IsRUFBaEc7QUFDRCxDQUZEOztBQUlBLElBQUlBLGtCQUFrQixHQUFLRCxRQUFGLElBQWdCO0FBQ3ZDLE1BQUlFLEtBQUssR0FBR0Msb0JBQW9CLEVBQWhDOztBQUVBLE1BQUtELEtBQUssQ0FBQyxDQUFELENBQUwsS0FBYSxPQUFsQixFQUErQjtBQUM3QkUsaUJBQWEsQ0FBRSxPQUFGLEVBQVdKLFFBQVgsQ0FBYjtBQUNEOztBQUVELE1BQUtFLEtBQUssQ0FBQyxDQUFELENBQUwsS0FBYSxTQUFsQixFQUErQjtBQUM3QkUsaUJBQWEsQ0FBRSxVQUFGLEVBQWNKLFFBQWQsQ0FBYjtBQUNEOztBQUVELE1BQUtFLEtBQUssQ0FBQyxDQUFELENBQUwsS0FBYSxVQUFsQixFQUErQjtBQUM3QkUsaUJBQWEsQ0FBRSxXQUFGLEVBQWVKLFFBQWYsQ0FBYjtBQUNEO0FBQ0YsQ0FkRDs7QUFnQkEsSUFBSUcsb0JBQW9CLEdBQUcsTUFBTTtBQUMvQixTQUFPUCxLQUFLLENBQUNTLGVBQU4sQ0FBdUIzQyxNQUFNLENBQUNxQixNQUFQLEVBQXZCLENBQVA7QUFDRCxDQUZEOztBQUlBLElBQUlxQixhQUFhLEdBQUcsQ0FBRUUsSUFBRixFQUFRTixRQUFSLEtBQXNCO0FBQ3hDLE1BQUtBLFFBQUwsRUFBZ0I7QUFDZEEsWUFBUSxDQUFFTSxJQUFGLENBQVI7QUFDRCxHQUZELE1BRU87QUFDTEMsY0FBVSxDQUFDQyxFQUFYLENBQWVELFVBQVUsQ0FBQ0QsSUFBWCxDQUFpQkEsSUFBakIsQ0FBZjtBQUNEO0FBQ0YsQ0FORDs7QUFRQXBDLE9BQU8sQ0FBQzRCLElBQVIsQ0FBYVcsWUFBYixHQUE0QlYsS0FBNUIsQzs7Ozs7Ozs7Ozs7QUNoQ0EsSUFBSVcsT0FBTyxHQUFHLE1BQU0sQ0FBRSxDQUF0Qjs7QUFFQXhDLE9BQU8sQ0FBQzRCLElBQVIsQ0FBYVksT0FBYixHQUF1QkEsT0FBdkIsQzs7Ozs7Ozs7Ozs7QUNGQSxNQUFNQyxxQkFBcUIsR0FBRyxNQUFNO0FBQ2xDLE1BQUssQ0FBQ2pELE1BQU0sQ0FBQ2tELFNBQVAsRUFBRCxJQUF1QixDQUFDbEQsTUFBTSxDQUFDcUIsTUFBUCxFQUE3QixFQUErQztBQUM3Q3dCLGNBQVUsQ0FBQ0MsRUFBWCxDQUFlLE9BQWY7QUFDRDtBQUNGLENBSkQ7O0FBTUEsTUFBTUssc0JBQXNCLEdBQUcsQ0FBRUMsT0FBRixFQUFXZCxRQUFYLEtBQXlCO0FBQ3RELE1BQUt0QyxNQUFNLENBQUNxQixNQUFQLE1BQW1CLENBQUNhLEtBQUssQ0FBQ21CLFlBQU4sQ0FBb0JyRCxNQUFNLENBQUNxQixNQUFQLEVBQXBCLEVBQXFDLE9BQXJDLENBQXpCLEVBQTBFO0FBQ3hFYixXQUFPLENBQUM0QixJQUFSLENBQWFXLFlBQWIsQ0FBMkI7QUFBRVQsY0FBUSxFQUFFQTtBQUFaLEtBQTNCO0FBQ0Q7QUFDRixDQUpEOztBQU1BLE1BQU1nQix3QkFBd0IsR0FBRyxDQUFFRixPQUFGLEVBQVdkLFFBQVgsS0FBeUI7QUFDeEQsTUFBS3RDLE1BQU0sQ0FBQ3FCLE1BQVAsTUFBbUIsQ0FBQ2EsS0FBSyxDQUFDbUIsWUFBTixDQUFvQnJELE1BQU0sQ0FBQ3FCLE1BQVAsRUFBcEIsRUFBcUMsQ0FBRSxPQUFGLEVBQVcsU0FBWCxDQUFyQyxDQUF6QixFQUF5RjtBQUN2RmIsV0FBTyxDQUFDNEIsSUFBUixDQUFhVyxZQUFiLENBQTJCO0FBQUVULGNBQVEsRUFBRUE7QUFBWixLQUEzQjtBQUNEO0FBQ0YsQ0FKRDs7QUFNQSxNQUFNaUIsbUJBQW1CLEdBQUdWLFVBQVUsQ0FBQ1csS0FBWCxDQUFpQjtBQUMzQ0MsTUFBSSxFQUFFLGVBRHFDO0FBRTNDQyxlQUFhLEVBQUUsQ0FBRVQscUJBQUY7QUFGNEIsQ0FBakIsQ0FBNUI7QUFLQU0sbUJBQW1CLENBQUNsQixLQUFwQixDQUEyQixRQUEzQixFQUFxQztBQUNuQ29CLE1BQUksRUFBRSxPQUQ2QjtBQUVuQ0MsZUFBYSxFQUFFLENBQUVQLHNCQUFGLENBRm9COztBQUduQ1EsUUFBTSxHQUFHO0FBQ1BDLGVBQVcsQ0FBQ0MsTUFBWixDQUFvQixTQUFwQixFQUErQjtBQUFFQyxXQUFLLEVBQUU7QUFBVCxLQUEvQjtBQUNEOztBQUxrQyxDQUFyQztBQVFBUCxtQkFBbUIsQ0FBQ2xCLEtBQXBCLENBQTJCLFdBQTNCLEVBQXdDO0FBQ3RDb0IsTUFBSSxFQUFFLFVBRGdDO0FBRXRDQyxlQUFhLEVBQUUsQ0FBRUosd0JBQUYsQ0FGdUI7O0FBR3RDSyxRQUFNLEdBQUc7QUFDUEMsZUFBVyxDQUFDQyxNQUFaLENBQW9CLFNBQXBCLEVBQStCO0FBQUVDLFdBQUssRUFBRTtBQUFULEtBQS9CO0FBQ0Q7O0FBTHFDLENBQXhDO0FBUUFQLG1CQUFtQixDQUFDbEIsS0FBcEIsQ0FBMkIsWUFBM0IsRUFBeUM7QUFDdkNvQixNQUFJLEVBQUUsV0FEaUM7O0FBRXZDRSxRQUFNLEdBQUc7QUFDUEMsZUFBVyxDQUFDQyxNQUFaLENBQW9CLFNBQXBCLEVBQStCO0FBQUVDLFdBQUssRUFBRTtBQUFULEtBQS9CO0FBQ0Q7O0FBSnNDLENBQXpDLEU7Ozs7Ozs7Ozs7O0FDdkNBakIsVUFBVSxDQUFDa0IsUUFBWCxHQUFzQjtBQUNwQkosUUFBTSxHQUFHO0FBQ1BDLGVBQVcsQ0FBQ0MsTUFBWixDQUFvQixTQUFwQixFQUErQjtBQUFFQyxXQUFLLEVBQUU7QUFBVCxLQUEvQjtBQUNEOztBQUhtQixDQUF0QjtBQU1BRSxRQUFRLENBQUNDLE9BQVQsQ0FBa0IsTUFBTTtBQUN0QixNQUFJQyxZQUFZLEdBQUdyQixVQUFVLENBQUNzQixPQUFYLEVBQW5COztBQUNBLE1BQUtELFlBQVksSUFBSUEsWUFBWSxDQUFDN0IsS0FBYixDQUFtQm1CLEtBQW5CLENBQXlCQyxJQUF6QixLQUFrQyxRQUF2RCxFQUFrRTtBQUNoRWpELFdBQU8sQ0FBQzRCLElBQVIsQ0FBYVcsWUFBYjtBQUNEO0FBQ0YsQ0FMRDs7QUFPQSxJQUFLL0MsTUFBTSxDQUFDb0UsUUFBWixFQUF1QjtBQUNyQkMsU0FBTyxDQUFDQyxPQUFSLENBQWlCLE1BQU07QUFDckIsUUFBSyxDQUFDdEUsTUFBTSxDQUFDcUIsTUFBUCxFQUFELElBQW9Cd0IsVUFBVSxDQUFDc0IsT0FBWCxHQUFxQjlCLEtBQTlDLEVBQXNEO0FBQ3BEUSxnQkFBVSxDQUFDQyxFQUFYLENBQWUsT0FBZjtBQUNEO0FBQ0YsR0FKRDtBQUtELEM7Ozs7Ozs7Ozs7O0FDbkJELE1BQU15QixjQUFjLEdBQUcsQ0FBRW5CLE9BQUYsRUFBV2QsUUFBWCxLQUF5QjtBQUM5QyxNQUFLdEMsTUFBTSxDQUFDcUIsTUFBUCxFQUFMLEVBQXVCO0FBQ3JCYixXQUFPLENBQUM0QixJQUFSLENBQWFXLFlBQWIsQ0FBMkI7QUFBRVQsY0FBUSxFQUFFQTtBQUFaLEtBQTNCO0FBQ0Q7QUFDRixDQUpEOztBQU1BLE1BQU1rQyxZQUFZLEdBQUczQixVQUFVLENBQUNXLEtBQVgsQ0FBaUI7QUFDcENDLE1BQUksRUFBRSxRQUQ4QjtBQUVwQ0MsZUFBYSxFQUFFLENBQUVhLGNBQUY7QUFGcUIsQ0FBakIsQ0FBckI7QUFLQUMsWUFBWSxDQUFDbkMsS0FBYixDQUFvQixnQkFBcEIsRUFBc0M7QUFDcENvQixNQUFJLEVBQUUsUUFEOEI7O0FBRXBDRSxRQUFNLEdBQUc7QUFDUEMsZUFBVyxDQUFDQyxNQUFaLENBQW9CLFNBQXBCLEVBQStCO0FBQUVDLFdBQUssRUFBRTtBQUFULEtBQS9CO0FBQ0Q7O0FBSm1DLENBQXRDO0FBT0FVLFlBQVksQ0FBQ25DLEtBQWIsQ0FBb0IsUUFBcEIsRUFBOEI7QUFDNUJvQixNQUFJLEVBQUUsT0FEc0I7O0FBRTVCRSxRQUFNLEdBQUc7QUFDUEMsZUFBVyxDQUFDQyxNQUFaLENBQW9CLFNBQXBCLEVBQStCO0FBQUVDLFdBQUssRUFBRTtBQUFULEtBQS9CO0FBQ0Q7O0FBSjJCLENBQTlCO0FBT0FVLFlBQVksQ0FBQ25DLEtBQWIsQ0FBb0IsbUJBQXBCLEVBQXlDO0FBQ3ZDb0IsTUFBSSxFQUFFLGtCQURpQzs7QUFFdkNFLFFBQU0sR0FBRztBQUNQQyxlQUFXLENBQUNDLE1BQVosQ0FBb0IsU0FBcEIsRUFBK0I7QUFBRUMsV0FBSyxFQUFFO0FBQVQsS0FBL0I7QUFDRDs7QUFKc0MsQ0FBekM7QUFPQVUsWUFBWSxDQUFDbkMsS0FBYixDQUFvQix3QkFBcEIsRUFBOEM7QUFDNUNvQixNQUFJLEVBQUUsZ0JBRHNDOztBQUU1Q0UsUUFBTSxHQUFHO0FBQ1BDLGVBQVcsQ0FBQ0MsTUFBWixDQUFvQixTQUFwQixFQUErQjtBQUFFQyxXQUFLLEVBQUU7QUFBVCxLQUEvQjtBQUNEOztBQUoyQyxDQUE5QyxFOzs7Ozs7Ozs7OztBQ2hDQTlELE1BQU0sQ0FBQ2dELE9BQVAsQ0FBZ0IsTUFBTXhDLE9BQU8sQ0FBQzRCLElBQVIsQ0FBYVksT0FBYixFQUF0QixFOzs7Ozs7Ozs7Ozs7QUNBQSwyQ0FBOEM7QUFHakMsZUFBTyxHQUFHLElBQUksNkJBQWUsQ0FBQyxVQUFVLENBQVMsU0FBUyxDQUFDLENBQUM7QUFDNUQsc0JBQWMsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFnQixpQkFBaUIsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FDSi9GLDZDQUE0QztBQUFuQywrQ0FBVzs7Ozs7Ozs7Ozs7OztBQ0FwQiwyQ0FBOEM7QUFHakMsbUJBQVcsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFZLGFBQWEsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FDSHBGLDJDQUE4QztBQUdqQywyQkFBbUIsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFxQixzQkFBc0IsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7O0FDSDlHLG9DQUErQjtBQUMvQix3REFBMkI7QUFDM0Isa0NBQTZCOzs7Ozs7Ozs7Ozs7O0FDRjdCLDJDQUE4QztBQUdqQyw2QkFBcUIsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUF1QixZQUFZLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ0h4RywyQ0FBOEM7QUFHakMsb0JBQVksR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFjLGNBQWMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7O0FDSHhGLDZCQUF3QjtBQUN4QixtQ0FBOEI7Ozs7Ozs7Ozs7Ozs7QUNEOUIsK0RBQTREO0FBRS9DLG1CQUFXLEdBQVEsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFFLGFBQWEsQ0FBRSxDQUFDO0FBRXRFLG1CQUFXLENBQUMsS0FBSyxDQUFDO0lBQ2hCLE1BQU0sRUFBRSxjQUFNLFlBQUssRUFBTCxDQUFLO0lBQ25CLE1BQU0sRUFBRSxjQUFNLFlBQUssRUFBTCxDQUFLO0lBQ25CLE1BQU0sRUFBRSxjQUFNLFlBQUssRUFBTCxDQUFLO0NBQ3BCLENBQUMsQ0FBQztBQUVILG1CQUFXLENBQUMsSUFBSSxDQUFDO0lBQ2YsTUFBTSxFQUFFLGNBQU0sV0FBSSxFQUFKLENBQUk7SUFDbEIsTUFBTSxFQUFFLGNBQU0sV0FBSSxFQUFKLENBQUk7SUFDbEIsTUFBTSxFQUFFLGNBQU0sV0FBSSxFQUFKLENBQUk7Q0FDbkIsQ0FBQyxDQUFDO0FBRUgsSUFBTSxpQkFBaUIsR0FBRyxJQUFJLDJCQUFZLENBQUM7SUFDekMsS0FBSyxFQUFFO1FBQ0wsSUFBSSxFQUFFLE1BQU07UUFDWixLQUFLLEVBQUUsOEJBQThCO0tBQ3RDO0lBQ0QsS0FBSyxFQUFFO1FBQ0wsSUFBSSxFQUFFLE1BQU07UUFDWixLQUFLLEVBQUUsbUJBQW1CO0tBQzNCO0lBQ0QsSUFBSSxFQUFFO1FBQ0osSUFBSSxFQUFFLE1BQU07UUFDWixLQUFLLEVBQUUsNEJBQTRCO0tBQ3BDO0lBQ0QsSUFBSSxFQUFFO1FBQ0osSUFBSSxFQUFFLE1BQU07UUFDWixLQUFLLEVBQUUsaUJBQWlCO0tBQ3pCO0NBQ0YsQ0FBQyxDQUFDO0FBRUgsbUJBQVcsQ0FBQyxZQUFZLENBQUUsaUJBQWlCLENBQUUsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ25DOUMsMkNBQThDO0FBQzlDLHdDQUF1QztBQUd2QyxlQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztJQUNqQixNQUFNLEVBQUUsY0FBTSxZQUFLLEVBQUwsQ0FBSztJQUNuQixNQUFNLEVBQUUsY0FBTSxZQUFLLEVBQUwsQ0FBSztJQUNuQixNQUFNLEVBQUUsY0FBTSxZQUFLLEVBQUwsQ0FBSztDQUNwQixDQUFDLENBQUM7QUFFSCxlQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztJQUNoQixNQUFNLEVBQUUsY0FBTSxXQUFJLEVBQUosQ0FBSTtJQUNsQixNQUFNLEVBQUUsY0FBTSxXQUFJLEVBQUosQ0FBSTtJQUNsQixNQUFNLEVBQUUsY0FBTSxXQUFJLEVBQUosQ0FBSTtDQUNuQixDQUFDLENBQUM7QUFFVSxhQUFLLEdBQUcsNkJBQWUsQ0FBQyxZQUFZLENBQU8sZUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FDaEJ0RSwyQ0FBOEM7QUFHakMsYUFBSyxHQUFHLElBQUksNkJBQWUsQ0FBQyxVQUFVLENBQU8sT0FBTyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNIbkUsdUNBQXdCO0FBQ3hCLGdDQUEyQjtBQUMzQixzREFBeUQ7QUFBakQsbUNBQU87QUFBRSxpREFBYztBQUMvQixxREFBc0M7QUFDdEMsZ0NBQTJCO0FBRzNCLGlEQUEyQztBQUFuQyw2QkFBSztBQUFFLHlDQUFXO0FBQzFCLDZDQUF3Qjs7Ozs7Ozs7Ozs7OztBQ1J4QiwyQ0FBOEM7QUFHakMsZ0JBQVEsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFVLFVBQVUsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FDSDVFLDJDQUE4QztBQUdqQyxvQkFBWSxHQUFHLElBQUksNkJBQWUsQ0FBQyxVQUFVLENBQWMsY0FBYyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUNGeEYsaURBQXlEO0FBR3pELE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sRUFBRTtJQUFBLGlCQThCbkM7SUE3QkMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7UUFDaEIsT0FBTztLQUNSO0lBRUQsT0FBTztRQUNMLElBQUksRUFBRTtZQUNKLE9BQU8sbUJBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQzNELENBQUM7UUFFRCxRQUFRLEVBQUU7WUFDaUM7Z0JBQ3ZDLElBQUksRUFBRSxVQUFDLElBQUk7b0JBQ1QsT0FBTyxzQkFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO3dCQUNwRCxJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUU7d0JBQ3ZCLEtBQUssRUFBRSxDQUFDO3FCQUNULENBQUMsQ0FBQztnQkFDTCxDQUFDO2FBQ0Y7WUFDcUM7Z0JBQ3BDLElBQUksRUFBRSxVQUFDLElBQUk7b0JBQ1QsT0FBTyxtQkFBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7d0JBQzNCLEdBQUcsRUFBRSxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFO3FCQUM3QixFQUFFO3dCQUNELE1BQU0sRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7cUJBQ3ZCLENBQUMsQ0FBQztnQkFDTCxDQUFDO2FBQ0Y7U0FDRjtLQUNGLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ2xDSCx3REFBNEM7QUFDNUMsaURBQTJFO0FBRzNFLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLFNBQVMsRUFBRTtJQUFBLGlCQTZCbkM7SUE1QkQsSUFBTSxZQUFZLEdBQUcsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ25DLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ2hCLE9BQU87S0FDUjtJQUVELElBQUksQ0FBQyxZQUFZLEVBQUU7UUFDakIsTUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLHVCQUF1QixDQUFDLENBQUM7S0FDdEQ7SUFDRCxJQUFJLENBQUMsc0JBQUssQ0FBQyxZQUFZLENBQUMsWUFBWSxFQUFFLENBQUMsT0FBTyxFQUFFLGdCQUFnQixFQUFFLGNBQWMsRUFBRSxPQUFPLEVBQUUsYUFBYSxDQUFDLEVBQUUsc0JBQUssQ0FBQyxZQUFZLENBQUMsRUFBRTtRQUM5SCxNQUFNLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsZUFBZSxDQUFDO0tBQzdDO0lBRUMsT0FBTztRQUNMLElBQUksRUFBRTtZQUNKLE9BQU8scUJBQU8sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQzdELENBQUM7UUFFRCxRQUFRLEVBQUU7WUFDUjtnQkFDRSxJQUFJLEVBQUUsVUFBQyxNQUFNO29CQUNYLE9BQU8sNEJBQWMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUMsUUFBUSxFQUFHLE1BQU0sQ0FBQyxHQUFHLEVBQUUsRUFBRTt3QkFDOUQsSUFBSSxFQUFFLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFFO3dCQUN2QixLQUFLLEVBQUUsQ0FBQztxQkFDVCxDQUFDLENBQUM7Z0JBQ0wsQ0FBQzthQUNGO1NBQ0E7S0FDTjtBQUNELENBQUMsQ0FBQyxDQUFDO0FBR0wsTUFBTSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUU7SUFDekIsSUFBTSxZQUFZLEdBQUcsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO0lBRW5DLElBQUksQ0FBQyxZQUFZO1FBQ2YsQ0FBQyxzQkFBSyxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsY0FBYyxFQUFFLE9BQU8sRUFBRSxhQUFhLENBQUMsRUFBRSxTQUFTLENBQUMsRUFBRTtRQUNuSCxNQUFNLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsZUFBZSxDQUFDO0tBQzdDO0lBQ0QsT0FBTyw0QkFBYyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBQyxRQUFRLEVBQUUsWUFBWSxDQUFDLEdBQUcsRUFBQyxDQUFDLENBQUM7QUFDdEUsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUM1Q0gsbUVBQWdFO0FBRWhFLE1BQU0sQ0FBQyxPQUFPLENBQUUsUUFBUSxFQUFFLFVBQVUsS0FBSztJQUN2QyxLQUFLLENBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBRSxDQUFDO0lBQ3ZCLE9BQU8seUJBQVcsQ0FBQyxJQUFJLENBQUUsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLENBQUUsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ0pILGlEQUEyQztBQUUzQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxVQUN6QixNQUFjLEVBQ2Qsb0JBQTRCO0lBQzVCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQzNCLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUMvQixPQUFPO0tBQ1I7SUFDRCxPQUFPLHNCQUFRLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztRQUM5QixNQUFNO0tBQ1AsRUFBRTtRQUNELElBQUksRUFBRSxFQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztRQUNyQixLQUFLLEVBQUUsRUFBRSxHQUFHLG9CQUFvQjtLQUNqQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ2hCSCxpREFBOEM7QUFFOUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUU7SUFDN0IscUVBQXFFO0lBQ25FLE9BQU8seUJBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7QUFFL0IsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUNOSCxpREFBK0M7QUFFL0MsTUFBTSxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUU7SUFDN0IsT0FBTywwQkFBWSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ0pILGlEQUErQztBQUcvQyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRTtJQUM3QixPQUFPLDBCQUFZLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7O0FDSkgsZ0JBQWdCOztBQUdoQixpREFBc0Q7QUFFdEQsTUFBTSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsRUFBRTtJQUNyQyxPQUFPLGlDQUFtQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRSxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ1JILGlEQUFxRDtBQUVyRCxNQUFNLENBQUMsT0FBTyxDQUFFLE9BQU8sRUFBRTtJQUN2QixJQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsWUFBWSxDQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFFckYsSUFBSyxPQUFPLEVBQUc7UUFDYixPQUFPO1lBQ0wsbUJBQUssQ0FBQyxJQUFJLENBQUUsRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLEVBQUUsZ0JBQWdCLEVBQUUsQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFFO1lBQ2pFLHlCQUFXLENBQUMsSUFBSSxDQUFFLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBRTtTQUN6RSxDQUFDO0tBQ0g7U0FBTTtRQUNMLE9BQU8sSUFBSSxDQUFDO0tBQ2I7QUFDSCxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ2JILHFFQUFxRTtBQUNyRSw4Q0FBMkQ7QUFDM0QsOENBQTBDO0FBQzFDLG1DQUFnRDtBQUNoRCxzQ0FBNEM7QUFDNUMsMENBQXlDO0FBRXpDLElBQU0sY0FBYyxHQUFHLGFBQUssQ0FBQyxLQUFLLENBQUMsVUFBQyxHQUFHO0lBQ3JDLGFBQUssQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDbkIsT0FBTyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQztBQUVILElBQU0sY0FBYyxHQUFHLDRCQUE0QixDQUFDO0FBQ3BELElBQU0sT0FBTyxHQUFRLEtBQUssQ0FBQztBQUUzQixNQUFNLENBQUMsT0FBTyxDQUFDO0lBQ2IsT0FBTyxFQUFQLFVBQVEsVUFBa0I7UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsTUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUNuQyw2Q0FBNkMsQ0FBQyxDQUFDO1NBQ2xEO1FBRUQsYUFBSyxDQUFDLFVBQVUsRUFBRSxjQUFjLENBQUMsQ0FBQztRQUVsQyxJQUFJLFVBQVUsS0FBSyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQzlCLE1BQU0sSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLGtCQUFrQixFQUN2Qyw0REFBNEQsQ0FBQyxDQUFDO1NBQ2pFO1FBRUQsSUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLG1CQUFLLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztZQUN6QyxTQUFTLEVBQUUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxFQUFFO1NBQy9DLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUVYLElBQUksVUFBVSxFQUFFO1lBQ2QsTUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUNsQyxxQkFBcUIsQ0FBQyxDQUFDO1NBQzFCO1FBRUQsSUFBTSxJQUFJLEdBQUc7WUFDWCxTQUFTLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQztTQUNyQyxDQUFDO1FBRUYsbUJBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDckIsQ0FBQztJQUNELFVBQVUsRUFBVixVQUFXLE1BQWM7UUFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsTUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUNuQyx1Q0FBdUMsQ0FBQyxDQUFDO1NBQzVDO1FBQ0QsYUFBSyxDQUFDLE1BQU0sRUFBRSxjQUFjLENBQUMsQ0FBQztRQUM5QixJQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsbUJBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDO1FBRTNELElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDZixNQUFNLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFDdEMscUJBQXFCLENBQUMsQ0FBQztTQUMxQjtRQUVELG1CQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3ZCLENBQUM7SUFDRCxhQUFhLEVBQWIsVUFBYyxPQUFnQjtRQUM1QixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUFFLE1BQU0sSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFDdkQsNkNBQTZDLENBQUMsQ0FBQztTQUNoRDtRQUNELGFBQUssQ0FBQyxPQUFPLEVBQUU7WUFDYixJQUFJLEVBQUUsY0FBYztTQUNyQixDQUFDLENBQUM7UUFFSCxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQy9CLElBQUksRUFBRSxFQUFDLE9BQU8sV0FBQztTQUNoQixDQUFDLENBQUM7SUFDTCxDQUFDO0lBQ0QsYUFBYSxZQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSztRQUMvQixJQUFJLEtBQUssRUFBRTtZQUNULEtBQUssQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztTQUM1QzthQUFNO1lBQ0wsS0FBSyxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDckM7SUFDSCxDQUFDO0lBQ0Qsa0JBQWtCLFlBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFNO1FBQ3JDLElBQUksS0FBSyxFQUFFO1lBQ1QsS0FBSyxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQzVDO2FBQU07WUFDTCxLQUFLLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztTQUNyQztJQUNILENBQUM7SUFDRCxTQUFTLFlBQUMsVUFBVSxFQUFFLGlCQUFpQjtRQUNyQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUFFLE1BQU0sSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFDdkQsK0NBQStDLENBQUMsQ0FBQztTQUNsRDtRQUVELGFBQUssQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDMUIsYUFBSyxDQUFDLGlCQUFpQixFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBRWpDLE9BQU87WUFDTCxNQUFNLEVBQUUscUJBQU8sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO2dCQUNoQyxJQUFJLEVBQUUsVUFBVTtnQkFDaEIsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNO2dCQUN0QixXQUFXLEVBQUUsaUJBQWlCO2FBQy9CLENBQUM7U0FDSCxDQUFDO0lBQ0osQ0FBQztJQUNELFVBQVUsWUFBQyxJQUFpQixFQUFFLE1BQWMsRUFBRSxPQUFlO1FBQzNELElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQUUsTUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUN2RCw2Q0FBNkMsQ0FBQyxDQUFDO1NBQ2hEO1FBRUQsYUFBSyxDQUFDLElBQUksRUFBRSxhQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFFLG9CQUFXLENBQUMsSUFBSSxDQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3ZELGFBQUssQ0FBQyxNQUFNLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDOUIsYUFBSyxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUMsQ0FBQztRQUUvQixJQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsbUJBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDO1FBRTNELElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDZixNQUFNLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFDdEMscUJBQXFCLENBQUMsQ0FBQztTQUMxQjtRQUVELE9BQU87WUFDTCxTQUFTLEVBQUUsc0JBQVEsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO2dCQUNwQyxNQUFNLEVBQUUsTUFBTTtnQkFDZCxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU07Z0JBQ3JCLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7Z0JBQ3JCLElBQUksRUFBRSxJQUFJO2FBQ1gsQ0FBQztTQUNILENBQUM7SUFDSixDQUFDO0lBQ0QsYUFBYSxFQUFiO1FBQ0UsT0FBTyxzQkFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUM1QyxDQUFDO0lBQ0QsZ0JBQWdCLFlBQUUsS0FBSyxFQUFFLFFBQVE7UUFDL0IsUUFBUSxDQUFDLFVBQVUsQ0FBQyxFQUFDLEtBQUssRUFBRSxRQUFRLEVBQUMsQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRCxPQUFPLFlBQUMsSUFBUyxFQUFFLFVBQXFCO1FBQ3RDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2hCLE1BQU0sSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFDbkMsZ0RBQWdELENBQUMsQ0FBQztTQUNyRDtRQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzFCLElBQUksYUFBYSxHQUFHLEVBQUUsQ0FBQztRQUN2QixJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7UUFFZixJQUFHLFVBQVUsRUFBRTtZQUNiLGFBQWEsR0FBRyxFQUFFLFdBQVcsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUUsRUFBRSxDQUFDO1lBRTdELE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDM0IsS0FBSyxHQUFHO2dCQUNOLGFBQWEsRUFBQyxTQUFTO2dCQUV0QixLQUFLLEVBQUcscWhIQUFxaEg7Z0JBRTloSCxTQUFTLEVBQUcsYUFBYTthQUMxQixDQUFDO1NBRUg7YUFBTTtZQUNMLGFBQWEsR0FBRyxFQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUUsRUFBQyxDQUFDO1lBRTFELEtBQUssR0FBRztnQkFDUCxLQUFLLEVBQUUsNnZCQUE2dkI7Z0JBRXB3QixTQUFTLEVBQUcsYUFBYTthQUMxQixDQUFDO1NBRUo7UUFFQSxPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzNCLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFbkIsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUVwQyxJQUFNLGdCQUFnQixHQUFHO1lBQ3ZCLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTTtZQUN4QixPQUFPLEVBQUUsT0FBTztZQUNoQixRQUFRLEVBQUUsU0FBUztZQUNuQixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdEIsQ0FBQztRQUVGLElBQUksWUFBWSxHQUFHLHlCQUFXLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRW5FLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEdBQUcsWUFBWSxDQUFDLENBQUM7UUFDL0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDLENBQUM7UUFFbEMsSUFBSSxPQUFPLEdBQUc7WUFDWixJQUFJLEVBQUUsY0FBYztZQUNwQixJQUFJLEVBQUUsVUFBVTtZQUNoQixNQUFNLEVBQUUsTUFBTTtZQUNkLE9BQU8sRUFBRTtnQkFDUCxjQUFjLEVBQUUsa0JBQWtCO2FBQ25DO1NBQ0YsQ0FBQztRQUNGLElBQUksS0FBSyxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUVsQyxJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7UUFFckIsaUJBQU8sQ0FBQyxLQUFLLENBQ1osV0FBVyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJLEVBQUU7WUFDaEQsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNO1lBQ3RCLE9BQU8sRUFBRSxFQUFDLGNBQWMsRUFBRSxrQkFBa0IsRUFBQztZQUM3QyxJQUFJLEVBQUUsT0FBTztTQUNkLENBQUM7YUFDRCxJQUFJLENBQUMsa0JBQVEsSUFBSSxlQUFRLENBQUMsSUFBSSxFQUFFLEVBQWYsQ0FBZSxDQUFDO2FBQ2pDLElBQUksQ0FBQyxrQkFBUSxJQUFJLGVBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFwQixDQUFvQixDQUFDO2FBQ3RDLElBQUksQ0FBQyxrQkFBUTtZQUVaLGlCQUFpQjtZQUNsQix5QkFBVyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLEVBQUMsSUFBSSxFQUFFLEVBQUMsUUFBUSxFQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLEVBQUMsRUFBRSxDQUFDLENBQUM7WUFDM0YsT0FBTyxRQUFRLENBQUM7UUFFbEIsQ0FBQyxDQUFDO2FBQ0QsS0FBSyxDQUFDLGFBQUc7WUFDUixPQUFPLEdBQUcsQ0FBQztRQUViLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFSixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXpCLE9BQU8sV0FBVyxDQUFDO0lBQ3JCLENBQUM7Q0FHRixDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUM3TlUsMkJBQW1CLEdBQUcsaUNBQWlDLENBQUM7QUFjckUsSUFBWSxXQUlYO0FBSkQsV0FBWSxXQUFXO0lBQ3JCLGtDQUFZLE1BQU07SUFDbEIsc0NBQWdCLFVBQVU7SUFDMUIscUNBQWUsU0FBUztBQUMxQixDQUFDLEVBSlcsV0FBVyxHQUFYLG1CQUFXLEtBQVgsbUJBQVcsUUFJdEI7QUFpQ0QsSUFBWSxZQUtYO0FBTEQsV0FBWSxZQUFZO0lBQ3RCLHlDQUF5QjtJQUN6QixtREFBbUM7SUFDbkMsaURBQWlDO0lBQ2pDLHFDQUFxQjtBQUN2QixDQUFDLEVBTFcsWUFBWSxHQUFaLG9CQUFZLEtBQVosb0JBQVksUUFLdkI7QUFzQkQsSUFBWSxTQU1YO0FBTkQsV0FBWSxTQUFTO0lBQ25CLDRCQUFlO0lBQ2Ysd0NBQTJCO0lBQzNCLDRCQUFlO0lBQ2YsZ0NBQW1CO0lBQ25CLDhCQUFtQjtBQUNyQixDQUFDLEVBTlcsU0FBUyxHQUFULGlCQUFTLEtBQVQsaUJBQVMsUUFNcEI7QUFFRCxJQUFZLHFCQUtYO0FBTEQsV0FBWSxxQkFBcUI7SUFDM0IsMENBQWdCO0lBQ2hCLHNDQUFZO0lBQ1osMENBQWdCO0lBQ2hCLDBDQUFnQjtBQUN0QixDQUFDLEVBTFcscUJBQXFCLEdBQXJCLDZCQUFxQixLQUFyQiw2QkFBcUIsUUFLaEM7QUF3Q0QsSUFBWSxlQUdYO0FBSEQsV0FBWSxlQUFlO0lBQ3pCLHNEQUFtQztJQUNuQyxvREFBaUM7QUFDbkMsQ0FBQyxFQUhXLGVBQWUsR0FBZix1QkFBZSxLQUFmLHVCQUFlLFFBRzFCO0FBRUQsSUFBWSxvQkFHWDtBQUhELFdBQVksb0JBQW9CO0lBQzlCLDJDQUFrQjtJQUNsQiw2Q0FBb0I7QUFDdEIsQ0FBQyxFQUhXLG9CQUFvQixHQUFwQiw0QkFBb0IsS0FBcEIsNEJBQW9CLFFBRy9CO0FBUUQsSUFBWSxpQkFLWDtBQUxELFdBQVksaUJBQWlCO0lBQzNCLHNDQUFpQjtJQUNqQiw4Q0FBeUI7SUFDekIsNENBQXVCO0lBQ3ZCLHNDQUFpQjtBQUNuQixDQUFDLEVBTFcsaUJBQWlCLEdBQWpCLHlCQUFpQixLQUFqQix5QkFBaUIsUUFLNUI7Ozs7Ozs7Ozs7Ozs7QUN4SkQscUVBQXFFO0FBQ3JFLHdDQUFxQztBQUNyQyw4Q0FBdUM7QUFDdkMsOENBQWlEO0FBQ2pELGdFQUFpRDtBQUVqRCxNQUFNLENBQUMsT0FBTyxDQUFDLG1CQUFtQixFQUFFLFVBQVMsRUFBRztJQUU5QywyQkFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsbUJBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDO0FBRUgsZUFBTSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLFVBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxJQUFJO0lBQ2xELEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbkIsR0FBRyxDQUFDLEdBQUcsQ0FBQyx1QkFBcUIsTUFBTSxDQUFDLE9BQVMsQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsVUFBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLElBQUk7SUFFaEMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNuQixHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMscUJBQU8sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLFVBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxJQUFJO0lBR25DLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbkIsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLHFCQUFPLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUQsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUN2Qkgsd0NBQXVDO0FBQ3ZDLHNEQUFnRDtBQUNoRCw4Q0FBMkM7QUFDM0M7SUFDRSxPQUFPLENBQUMsQ0FBQztBQUNYLENBQUM7QUFDRCxnQkFBaUIsRUFBRTtJQUNqQixPQUFPLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUMvRCxPQUFPLElBQUksQ0FBQztBQUNkLENBQUM7QUFDRDtJQUNFLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQXFDLENBQUMsQ0FBQztJQUNuRCxPQUFPLElBQUksQ0FBQztBQUNkLENBQUM7QUFFRCxlQUFNLENBQUMsT0FBTyxDQUFDO0lBQ2Isd0JBQXdCO0lBQ3hCLDhCQUE4QjtJQUU5QixJQUFJLGVBQU0sQ0FBQyxRQUFRLEVBQUU7UUFDbkIsc0VBQXNFO1FBQ3RFLDBDQUEwQztLQUMzQztJQUVELElBQUksYUFBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLEVBQUU7UUFDdkMsT0FBTztLQUNSO0lBRUQsd0JBQVEsQ0FBQyxVQUFVLENBQUM7UUFDbEIsUUFBUSxFQUFFLFFBQVE7UUFDbEIsS0FBSyxFQUFHLDJCQUEyQjtRQUNuQyxRQUFRLEVBQUcsWUFBWTtRQUN2QixPQUFPLEVBQUU7WUFDUCxJQUFJLEVBQUcsZ0JBQWdCO1NBQ3hCO0tBQ0YsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIk1ldGVvci5tZXRob2RzKHtcbiAgc2VuZEludml0YXRpb24oIGludml0YXRpb24gKSB7XG4gICAgY2hlY2soIGludml0YXRpb24sIHtcbiAgICAgIGVtYWlsOiBTdHJpbmcsXG4gICAgICByb2xlOiBTdHJpbmdcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICBNb2R1bGVzLnNlcnZlci5zZW5kSW52aXRhdGlvbih7XG4gICAgICAgIGVtYWlsOiBpbnZpdGF0aW9uLmVtYWlsLFxuICAgICAgICB0b2tlbjogUmFuZG9tLmhleFN0cmluZyggMTYgKSxcbiAgICAgICAgcm9sZTogaW52aXRhdGlvbi5yb2xlLFxuICAgICAgICBkYXRlOiAoIG5ldyBEYXRlKCkgKS50b0lTT1N0cmluZygpXG4gICAgICB9KTtcbiAgICB9IGNhdGNoKCBleGNlcHRpb24gKSB7XG4gICAgICByZXR1cm4gZXhjZXB0aW9uO1xuICAgIH1cbiAgfVxufSk7XG4iLCJNZXRlb3IubWV0aG9kcyh7XG4gIGFjY2VwdEludml0YXRpb24oIHVzZXIgKSB7XG4gICAgY2hlY2soIHVzZXIsIHtcbiAgICAgIGVtYWlsOiBTdHJpbmcsXG4gICAgICBwYXNzd29yZDogT2JqZWN0LFxuICAgICAgdG9rZW46IFN0cmluZ1xuICAgIH0pO1xuXG4gICAgdHJ5IHtcbiAgICAgIHZhciB1c2VySWQgPSBNb2R1bGVzLnNlcnZlci5hY2NlcHRJbnZpdGF0aW9uKCB1c2VyICk7XG4gICAgICByZXR1cm4gdXNlcklkO1xuICAgIH0gY2F0Y2goIGV4Y2VwdGlvbiApIHtcbiAgICAgIHJldHVybiBleGNlcHRpb247XG4gICAgfVxuICB9XG59KTtcbiIsIk1ldGVvci5tZXRob2RzKHtcbiAgcmVhZE1ldGhvZCggYXJndW1lbnQgKSB7XG4gICAgY2hlY2soIGFyZ3VtZW50LCBTdHJpbmcgKTtcblxuICAgIHZhciBkb2N1bWVudCA9IENvbGxlY3Rpb24uZmluZE9uZSggYXJndW1lbnQgKTtcblxuICAgIGlmICggIWRvY3VtZW50ICkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvciggJ2RvY3VtZW50LW5vdC1mb3VuZCcsICdObyBkb2N1bWVudHMgZm91bmQgbWF0Y2hpbmcgdGhpcyBxdWVyeS4nICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGRvY3VtZW50O1xuICB9XG59KTtcbiIsIk1ldGVvci5tZXRob2RzKHtcbiAgcmV2b2tlSW52aXRhdGlvbiggaW52aXRlSWQgKSB7XG4gICAgY2hlY2soIGludml0ZUlkLCBTdHJpbmcgKTtcblxuICAgIHRyeSB7XG4gICAgICBJbnZpdGF0aW9ucy5yZW1vdmUoIGludml0ZUlkICk7XG4gICAgfSBjYXRjaCggZXhjZXB0aW9uICkge1xuICAgICAgcmV0dXJuIGV4Y2VwdGlvbjtcbiAgICB9XG4gIH1cbn0pO1xuIiwiTWV0ZW9yLm1ldGhvZHMoe1xuICBzZXRSb2xlT25Vc2VyKCBvcHRpb25zICkge1xuICAgIGNoZWNrKCBvcHRpb25zLCB7XG4gICAgICB1c2VyOiBTdHJpbmcsXG4gICAgICByb2xlOiBTdHJpbmdcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICBSb2xlcy5zZXRVc2VyUm9sZXMoIG9wdGlvbnMudXNlciwgWyBvcHRpb25zLnJvbGUgXSApO1xuICAgIH0gY2F0Y2goIGV4Y2VwdGlvbiApIHtcbiAgICAgIHJldHVybiBleGNlcHRpb247XG4gICAgfVxuICB9XG59KTtcbiIsIk1vZHVsZXMgICAgICA9IHt9O1xuTW9kdWxlcy5ib3RoID0ge307XG4iLCJsZXQgcm91dGUgPSAoIG9wdGlvbnMgKSA9PiB7XG4gIHJldHVybiBvcHRpb25zICYmIG9wdGlvbnMucmVkaXJlY3QgPyBfc2VuZFVzZXJUb0RlZmF1bHQoIG9wdGlvbnMucmVkaXJlY3QgKSA6IF9zZW5kVXNlclRvRGVmYXVsdCgpO1xufTtcblxubGV0IF9zZW5kVXNlclRvRGVmYXVsdCA9ICggcmVkaXJlY3QgKSA9PiB7XG4gIGxldCByb2xlcyA9IF9nZXRDdXJyZW50VXNlclJvbGVzKCk7XG5cbiAgaWYgKCByb2xlc1swXSA9PT0gJ2FkbWluJyApICAgIHtcbiAgICBfcmVkaXJlY3RVc2VyKCAndXNlcnMnLCByZWRpcmVjdCApO1xuICB9XG5cbiAgaWYgKCByb2xlc1swXSA9PT0gJ21hbmFnZXInICkgIHtcbiAgICBfcmVkaXJlY3RVc2VyKCAnbWFuYWdlcnMnLCByZWRpcmVjdCApO1xuICB9XG5cbiAgaWYgKCByb2xlc1swXSA9PT0gJ2VtcGxveWVlJyApIHtcbiAgICBfcmVkaXJlY3RVc2VyKCAnZW1wbG95ZWVzJywgcmVkaXJlY3QgKTtcbiAgfVxufTtcblxubGV0IF9nZXRDdXJyZW50VXNlclJvbGVzID0gKCkgPT4ge1xuICByZXR1cm4gUm9sZXMuZ2V0Um9sZXNGb3JVc2VyKCBNZXRlb3IudXNlcklkKCkgKTtcbn07XG5cbmxldCBfcmVkaXJlY3RVc2VyID0gKCBwYXRoLCByZWRpcmVjdCApID0+IHtcbiAgaWYgKCByZWRpcmVjdCApIHtcbiAgICByZWRpcmVjdCggcGF0aCApO1xuICB9IGVsc2Uge1xuICAgIEZsb3dSb3V0ZXIuZ28oIEZsb3dSb3V0ZXIucGF0aCggcGF0aCApICk7XG4gIH1cbn07XG5cbk1vZHVsZXMuYm90aC5yZWRpcmVjdFVzZXIgPSByb3V0ZTtcbiIsImxldCBzdGFydHVwID0gKCkgPT4ge307XG5cbk1vZHVsZXMuYm90aC5zdGFydHVwID0gc3RhcnR1cDtcbiIsImNvbnN0IGF1dGhlbnRpY2F0ZWRSZWRpcmVjdCA9ICgpID0+IHtcbiAgaWYgKCAhTWV0ZW9yLmxvZ2dpbmdJbigpICYmICFNZXRlb3IudXNlcklkKCkgKSB7XG4gICAgRmxvd1JvdXRlci5nbyggJ2xvZ2luJyApO1xuICB9XG59O1xuXG5jb25zdCBibG9ja1VuYXV0aG9yaXplZEFkbWluID0gKCBjb250ZXh0LCByZWRpcmVjdCApID0+IHtcbiAgaWYgKCBNZXRlb3IudXNlcklkKCkgJiYgIVJvbGVzLnVzZXJJc0luUm9sZSggTWV0ZW9yLnVzZXJJZCgpLCAnYWRtaW4nICkgKSB7XG4gICAgTW9kdWxlcy5ib3RoLnJlZGlyZWN0VXNlciggeyByZWRpcmVjdDogcmVkaXJlY3QgfSApO1xuICB9XG59O1xuXG5jb25zdCBibG9ja1VuYXV0aG9yaXplZE1hbmFnZXIgPSAoIGNvbnRleHQsIHJlZGlyZWN0ICkgPT4ge1xuICBpZiAoIE1ldGVvci51c2VySWQoKSAmJiAhUm9sZXMudXNlcklzSW5Sb2xlKCBNZXRlb3IudXNlcklkKCksIFsgJ2FkbWluJywgJ21hbmFnZXInIF0gKSApIHtcbiAgICBNb2R1bGVzLmJvdGgucmVkaXJlY3RVc2VyKCB7IHJlZGlyZWN0OiByZWRpcmVjdCB9ICk7XG4gIH1cbn07XG5cbmNvbnN0IGF1dGhlbnRpY2F0ZWRSb3V0ZXMgPSBGbG93Um91dGVyLmdyb3VwKHtcbiAgbmFtZTogJ2F1dGhlbnRpY2F0ZWQnLFxuICB0cmlnZ2Vyc0VudGVyOiBbIGF1dGhlbnRpY2F0ZWRSZWRpcmVjdCBdXG59KTtcblxuYXV0aGVudGljYXRlZFJvdXRlcy5yb3V0ZSggJy91c2VycycsIHtcbiAgbmFtZTogJ3VzZXJzJyxcbiAgdHJpZ2dlcnNFbnRlcjogWyBibG9ja1VuYXV0aG9yaXplZEFkbWluIF0sXG4gIGFjdGlvbigpIHtcbiAgICBCbGF6ZUxheW91dC5yZW5kZXIoICdkZWZhdWx0JywgeyB5aWVsZDogJ3VzZXJzJyB9ICk7XG4gIH1cbn0pO1xuXG5hdXRoZW50aWNhdGVkUm91dGVzLnJvdXRlKCAnL21hbmFnZXJzJywge1xuICBuYW1lOiAnbWFuYWdlcnMnLFxuICB0cmlnZ2Vyc0VudGVyOiBbIGJsb2NrVW5hdXRob3JpemVkTWFuYWdlciBdLFxuICBhY3Rpb24oKSB7XG4gICAgQmxhemVMYXlvdXQucmVuZGVyKCAnZGVmYXVsdCcsIHsgeWllbGQ6ICdtYW5hZ2VycycgfSApO1xuICB9XG59KTtcblxuYXV0aGVudGljYXRlZFJvdXRlcy5yb3V0ZSggJy9lbXBsb3llZXMnLCB7XG4gIG5hbWU6ICdlbXBsb3llZXMnLFxuICBhY3Rpb24oKSB7XG4gICAgQmxhemVMYXlvdXQucmVuZGVyKCAnZGVmYXVsdCcsIHsgeWllbGQ6ICdlbXBsb3llZXMnIH0gKTtcbiAgfVxufSk7XG4iLCJGbG93Um91dGVyLm5vdEZvdW5kID0ge1xuICBhY3Rpb24oKSB7XG4gICAgQmxhemVMYXlvdXQucmVuZGVyKCAnZGVmYXVsdCcsIHsgeWllbGQ6ICdub3RGb3VuZCcgfSApO1xuICB9XG59O1xuXG5BY2NvdW50cy5vbkxvZ2luKCAoKSA9PiB7XG4gIGxldCBjdXJyZW50Um91dGUgPSBGbG93Um91dGVyLmN1cnJlbnQoKTtcbiAgaWYgKCBjdXJyZW50Um91dGUgJiYgY3VycmVudFJvdXRlLnJvdXRlLmdyb3VwLm5hbWUgPT09ICdwdWJsaWMnICkge1xuICAgIE1vZHVsZXMuYm90aC5yZWRpcmVjdFVzZXIoKTtcbiAgfVxufSk7XG5cbmlmICggTWV0ZW9yLmlzQ2xpZW50ICkge1xuICBUcmFja2VyLmF1dG9ydW4oICgpID0+IHtcbiAgICBpZiAoICFNZXRlb3IudXNlcklkKCkgJiYgRmxvd1JvdXRlci5jdXJyZW50KCkucm91dGUgKSB7XG4gICAgICBGbG93Um91dGVyLmdvKCAnbG9naW4nICk7XG4gICAgfVxuICB9KTtcbn1cbiIsImNvbnN0IHB1YmxpY1JlZGlyZWN0ID0gKCBjb250ZXh0LCByZWRpcmVjdCApID0+IHtcbiAgaWYgKCBNZXRlb3IudXNlcklkKCkgKSB7XG4gICAgTW9kdWxlcy5ib3RoLnJlZGlyZWN0VXNlciggeyByZWRpcmVjdDogcmVkaXJlY3QgfSApO1xuICB9XG59O1xuXG5jb25zdCBwdWJsaWNSb3V0ZXMgPSBGbG93Um91dGVyLmdyb3VwKHtcbiAgbmFtZTogJ3B1YmxpYycsXG4gIHRyaWdnZXJzRW50ZXI6IFsgcHVibGljUmVkaXJlY3QgXVxufSk7XG5cbnB1YmxpY1JvdXRlcy5yb3V0ZSggJy9pbnZpdGUvOnRva2VuJywge1xuICBuYW1lOiAnaW52aXRlJyxcbiAgYWN0aW9uKCkge1xuICAgIEJsYXplTGF5b3V0LnJlbmRlciggJ2RlZmF1bHQnLCB7IHlpZWxkOiAnaW52aXRlJyB9ICk7XG4gIH1cbn0pO1xuXG5wdWJsaWNSb3V0ZXMucm91dGUoICcvbG9naW4nLCB7XG4gIG5hbWU6ICdsb2dpbicsXG4gIGFjdGlvbigpIHtcbiAgICBCbGF6ZUxheW91dC5yZW5kZXIoICdkZWZhdWx0JywgeyB5aWVsZDogJ2xvZ2luJyB9ICk7XG4gIH1cbn0pO1xuXG5wdWJsaWNSb3V0ZXMucm91dGUoICcvcmVjb3Zlci1wYXNzd29yZCcsIHtcbiAgbmFtZTogJ3JlY292ZXItcGFzc3dvcmQnLFxuICBhY3Rpb24oKSB7XG4gICAgQmxhemVMYXlvdXQucmVuZGVyKCAnZGVmYXVsdCcsIHsgeWllbGQ6ICdyZWNvdmVyUGFzc3dvcmQnIH0gKTtcbiAgfVxufSk7XG5cbnB1YmxpY1JvdXRlcy5yb3V0ZSggJy9yZXNldC1wYXNzd29yZC86dG9rZW4nLCB7XG4gIG5hbWU6ICdyZXNldC1wYXNzd29yZCcsXG4gIGFjdGlvbigpIHtcbiAgICBCbGF6ZUxheW91dC5yZW5kZXIoICdkZWZhdWx0JywgeyB5aWVsZDogJ3Jlc2V0UGFzc3dvcmQnIH0gKTtcbiAgfVxufSk7XG4iLCJNZXRlb3Iuc3RhcnR1cCggKCkgPT4gTW9kdWxlcy5ib3RoLnN0YXJ0dXAoKSApO1xuIiwiaW1wb3J0IHsgTW9uZ29PYnNlcnZhYmxlIH0gZnJvbSAnbWV0ZW9yLXJ4anMnO1xyXG5pbXBvcnQge0NvdXJzZSwgQ291cnNlU3ViamVjdH0gZnJvbSAnLi4vLi4vc2VydmVyL21vZGVscyc7XHJcblxyXG5leHBvcnQgY29uc3QgQ291cnNlcyA9IG5ldyBNb25nb09ic2VydmFibGUuQ29sbGVjdGlvbjxDb3Vyc2U+KCdjb3Vyc2VzJyk7XHJcbmV4cG9ydCBjb25zdCBDb3Vyc2VTdWJqZWN0cyA9IG5ldyBNb25nb09ic2VydmFibGUuQ29sbGVjdGlvbjxDb3Vyc2VTdWJqZWN0PignY291cnNlX3N1YmplY3RzJyk7XHJcbiIsImV4cG9ydCB7IFByZWRpY3Rpb25zIH0gZnJvbSAnLi9wcmVkaWN0aW9ucyc7XHJcbiIsImltcG9ydCB7IE1vbmdvT2JzZXJ2YWJsZSB9IGZyb20gJ21ldGVvci1yeGpzJztcclxuaW1wb3J0IHtQcmVkaXRpb259IGZyb20gJy4uLy4uL3NlcnZlci9tb2RlbHMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IFByZWRpY3Rpb25zID0gbmV3IE1vbmdvT2JzZXJ2YWJsZS5Db2xsZWN0aW9uPFByZWRpdGlvbj4oJ3ByZWRpY3Rpb25zJyk7IiwiaW1wb3J0IHsgTW9uZ29PYnNlcnZhYmxlIH0gZnJvbSAnbWV0ZW9yLXJ4anMnO1xyXG5pbXBvcnQgeyBUcmFuc2FjdGlvbkFjY291bnQgfSBmcm9tICcuLi8uLi9zZXJ2ZXIvbW9kZWxzJztcclxuXHJcbmV4cG9ydCBjb25zdCBUcmFuc2FjdGlvbkFjY291bnRzID0gbmV3IE1vbmdvT2JzZXJ2YWJsZS5Db2xsZWN0aW9uPFRyYW5zYWN0aW9uQWNjb3VudD4oJ3RyYW5zYWN0aW9uX2FjY291bnRzJyk7XHJcbiIsImV4cG9ydCAqIGZyb20gJy4vdHJhbnNhY3Rpb25zJztcclxuZXhwb3J0ICogZnJvbSAnLi9hY2NvdW50cyc7XHJcbmV4cG9ydCAqIGZyb20gJy4vcmVmZXJlbmNlcyc7XHJcbiIsImltcG9ydCB7IE1vbmdvT2JzZXJ2YWJsZSB9IGZyb20gJ21ldGVvci1yeGpzJztcclxuaW1wb3J0IHsgVHJhbnNhY3Rpb25SZWZlcmVuY2UgfSBmcm9tICcuLi8uLi9zZXJ2ZXIvbW9kZWxzJztcclxuXHJcbmV4cG9ydCBjb25zdCBUcmFuc2FjdGlvblJlZmVyZW5jZXMgPSBuZXcgTW9uZ29PYnNlcnZhYmxlLkNvbGxlY3Rpb248VHJhbnNhY3Rpb25SZWZlcmVuY2U+KCdyZWZlcmVuY2VzJyk7XHJcbiIsImltcG9ydCB7IE1vbmdvT2JzZXJ2YWJsZSB9IGZyb20gJ21ldGVvci1yeGpzJztcclxuaW1wb3J0IHsgVHJhbnNhY3Rpb24gfSBmcm9tICcuLi8uLi9zZXJ2ZXIvbW9kZWxzJztcclxuXHJcbmV4cG9ydCBjb25zdCBUcmFuc2FjdGlvbnMgPSBuZXcgTW9uZ29PYnNlcnZhYmxlLkNvbGxlY3Rpb248VHJhbnNhY3Rpb24+KCd0cmFuc2FjdGlvbnMnKTtcclxuIiwiZXhwb3J0ICogZnJvbSAnLi91c2Vycyc7XG5leHBvcnQgKiBmcm9tICcuL2ludml0YXRpb25zJztcbiIsImltcG9ydCB7U2ltcGxlU2NoZW1hfSBmcm9tICdzaW1wbC1zY2hlbWEvZGlzdC9TaW1wbGVTY2hlbWEnO1xuXG5leHBvcnQgY29uc3QgSW52aXRhdGlvbnM6IGFueSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCAnaW52aXRhdGlvbnMnICk7XG5cbkludml0YXRpb25zLmFsbG93KHtcbiAgaW5zZXJ0OiAoKSA9PiBmYWxzZSxcbiAgdXBkYXRlOiAoKSA9PiBmYWxzZSxcbiAgcmVtb3ZlOiAoKSA9PiBmYWxzZVxufSk7XG5cbkludml0YXRpb25zLmRlbnkoe1xuICBpbnNlcnQ6ICgpID0+IHRydWUsXG4gIHVwZGF0ZTogKCkgPT4gdHJ1ZSxcbiAgcmVtb3ZlOiAoKSA9PiB0cnVlXG59KTtcblxuY29uc3QgSW52aXRhdGlvbnNTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgZW1haWw6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdFbWFpbCB0byBzZW5kIGludml0YXRpb24gdG8uJ1xuICB9LFxuICB0b2tlbjoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ0ludml0YXRpb24gdG9rZW4uJ1xuICB9LFxuICByb2xlOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnUm9sZSB0byBhcHBseSB0byB0aGUgdXNlci4nXG4gIH0sXG4gIGRhdGU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdJbnZpdGF0aW9uIERhdGUnXG4gIH1cbn0pO1xuXG5JbnZpdGF0aW9ucy5hdHRhY2hTY2hlbWEoIEludml0YXRpb25zU2NoZW1hICk7XG4iLCJpbXBvcnQgeyBNb25nb09ic2VydmFibGUgfSBmcm9tICdtZXRlb3Itcnhqcyc7XG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFVzZXIgfSBmcm9tICcuLi8uLi9zZXJ2ZXIvbW9kZWxzJztcblxuTWV0ZW9yLnVzZXJzLmFsbG93KHtcbiAgaW5zZXJ0OiAoKSA9PiBmYWxzZSxcbiAgdXBkYXRlOiAoKSA9PiBmYWxzZSxcbiAgcmVtb3ZlOiAoKSA9PiBmYWxzZVxufSk7XG5cbk1ldGVvci51c2Vycy5kZW55KHtcbiAgaW5zZXJ0OiAoKSA9PiB0cnVlLFxuICB1cGRhdGU6ICgpID0+IHRydWUsXG4gIHJlbW92ZTogKCkgPT4gdHJ1ZVxufSk7XG5cbmV4cG9ydCBjb25zdCBVc2VycyA9IE1vbmdvT2JzZXJ2YWJsZS5mcm9tRXhpc3Rpbmc8VXNlcj4oTWV0ZW9yLnVzZXJzKTtcbiIsImltcG9ydCB7IE1vbmdvT2JzZXJ2YWJsZSB9IGZyb20gJ21ldGVvci1yeGpzJztcbmltcG9ydCB7IENoYXQgfSBmcm9tICcuLi9zZXJ2ZXIvbW9kZWxzJztcblxuZXhwb3J0IGNvbnN0IENoYXRzID0gbmV3IE1vbmdvT2JzZXJ2YWJsZS5Db2xsZWN0aW9uPENoYXQ+KCdjaGF0cycpO1xuIiwiZXhwb3J0ICogZnJvbSAnLi9jaGF0cyc7XG5leHBvcnQgKiBmcm9tICcuL21lc3NhZ2VzJztcbmV4cG9ydCB7Q291cnNlcywgQ291cnNlU3ViamVjdHN9IGZyb20gJy4vY291cnNlL2NvdXJzZXMnO1xuZXhwb3J0ICogZnJvbSAnLi90cmFuc2FjdGlvbmFsL2luZGV4JztcbmV4cG9ydCAqIGZyb20gJy4vc3R1ZGVudHMnO1xuXG5cbmV4cG9ydCB7VXNlcnMsIEludml0YXRpb25zfSBmcm9tICcuL3VzZXJzJztcbmV4cG9ydCAqIGZyb20gJy4vaGl2ZGInO1xuIiwiaW1wb3J0IHsgTW9uZ29PYnNlcnZhYmxlIH0gZnJvbSAnbWV0ZW9yLXJ4anMnO1xuaW1wb3J0IHsgTWVzc2FnZSB9IGZyb20gJy4uL3NlcnZlci9tb2RlbHMnO1xuXG5leHBvcnQgY29uc3QgTWVzc2FnZXMgPSBuZXcgTW9uZ29PYnNlcnZhYmxlLkNvbGxlY3Rpb248TWVzc2FnZT4oJ21lc3NhZ2VzJyk7XG4iLCJpbXBvcnQgeyBNb25nb09ic2VydmFibGUgfSBmcm9tICdtZXRlb3Itcnhqcyc7XG5pbXBvcnQgeyBTdHVkZW50RGF0YSB9IGZyb20gJy4uL3NlcnZlci9tb2RlbHMnO1xuXG5leHBvcnQgY29uc3QgU3R1ZGVudHNEYXRhID0gbmV3IE1vbmdvT2JzZXJ2YWJsZS5Db2xsZWN0aW9uPFN0dWRlbnREYXRhPignc3R1ZGVudHNEYXRhJyk7XG5cbiIsImltcG9ydCB7Q2hhdCwgTWVzc2FnZSwgVXNlcn0gZnJvbSAnLi4vbW9kZWxzJztcclxuaW1wb3J0IHtDaGF0cywgTWVzc2FnZXMsIFVzZXJzfSBmcm9tICcuLi8uLi9jb2xsZWN0aW9ucyc7XHJcblxyXG5cclxuTWV0ZW9yWydwdWJsaXNoQ29tcG9zaXRlJ10oJ2NoYXRzJywgZnVuY3Rpb24oKTogUHVibGlzaENvbXBvc2l0ZUNvbmZpZzxDaGF0PiB7XHJcbiAgaWYgKCF0aGlzLnVzZXJJZCkge1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIGZpbmQ6ICgpID0+IHtcclxuICAgICAgcmV0dXJuIENoYXRzLmNvbGxlY3Rpb24uZmluZCh7IG1lbWJlcklkczogdGhpcy51c2VySWQgfSk7XHJcbiAgICB9LFxyXG5cclxuICAgIGNoaWxkcmVuOiBbXHJcbiAgICAgIDxQdWJsaXNoQ29tcG9zaXRlQ29uZmlnMTxDaGF0LCBNZXNzYWdlPj4ge1xyXG4gICAgICAgIGZpbmQ6IChjaGF0KSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gTWVzc2FnZXMuY29sbGVjdGlvbi5maW5kKHsgY2hhdElkOiBjaGF0Ll9pZCB9LCB7XHJcbiAgICAgICAgICAgIHNvcnQ6IHsgY3JlYXRlZEF0OiAtMSB9LFxyXG4gICAgICAgICAgICBsaW1pdDogMVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICA8UHVibGlzaENvbXBvc2l0ZUNvbmZpZzE8Q2hhdCwgVXNlcj4+IHtcclxuICAgICAgICBmaW5kOiAoY2hhdCkgPT4ge1xyXG4gICAgICAgICAgcmV0dXJuIFVzZXJzLmNvbGxlY3Rpb24uZmluZCh7XHJcbiAgICAgICAgICAgIF9pZDogeyAkaW46IGNoYXQubWVtYmVySWRzIH1cclxuICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgZmllbGRzOiB7IHByb2ZpbGU6IDEgfVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICBdXHJcbiAgfTtcclxufSk7XHJcblxyXG4iLCJpbXBvcnQge1JvbGVzfSBmcm9tICdtZXRlb3IvYWxhbm5pbmc6cm9sZXMnO1xyXG5pbXBvcnQge0NoYXRzLCBDb3Vyc2VzLCBDb3Vyc2VTdWJqZWN0cywgTWVzc2FnZXN9IGZyb20gJy4uLy4uL2NvbGxlY3Rpb25zJztcclxuaW1wb3J0IHtDb3Vyc2UsIENvdXJzZVN1YmplY3R9IGZyb20gJy4uL21vZGVscyc7XHJcblxyXG5NZXRlb3JbJ3B1Ymxpc2hDb21wb3NpdGUnXSgnY291cnNlcycsIGZ1bmN0aW9uICgpOiBQdWJsaXNoQ29tcG9zaXRlQ29uZmlnPENvdXJzZT4ge1xyXG4gIGNvbnN0IGxvZ2dlZEluVXNlciA9IE1ldGVvci51c2VyKCk7XHJcbiAgaWYgKCF0aGlzLnVzZXJJZCkge1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgaWYgKCFsb2dnZWRJblVzZXIpIHtcclxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCAnQXV0aGVudGljYXRpb24gZmFpbGVkJyk7XHJcbiAgfVxyXG4gIGlmICghUm9sZXMudXNlcklzSW5Sb2xlKGxvZ2dlZEluVXNlciwgWyd0dXRvcicsICdtYW5hZ2UtY291cnNlcycsICd2aWV3LWNvdXJzZXMnLCAnYWRtaW4nLCAnc3VwZXItYWRtaW4nXSwgUm9sZXMuR0xPQkFMX0dST1VQKSkge1xyXG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsICdBY2Nlc3MgZGVuaWVkJylcclxuICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgZmluZDogKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBDb3Vyc2VzLmNvbGxlY3Rpb24uZmluZCh7IG93bmVyc2hpcDogdGhpcy51c2VySWQgfSk7XHJcbiAgICAgIH0sXHJcblxyXG4gICAgICBjaGlsZHJlbjogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGZpbmQ6IChjb3Vyc2UpID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIENvdXJzZVN1YmplY3RzLmNvbGxlY3Rpb24uZmluZCh7Y291cnNlSWQgOiBjb3Vyc2UuX2lkIH0sIHtcclxuICAgICAgICAgICAgICBzb3J0OiB7IGNyZWF0ZWRBdDogLTEgfSxcclxuICAgICAgICAgICAgICBsaW1pdDogMVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgXVxyXG4gIH1cclxuICB9KTtcclxuXHJcblxyXG5NZXRlb3IucHVibGlzaCgnc3ViamVjdHMnLCBmdW5jdGlvbiAoKTogTW9uZ28uQ3Vyc29yPENvdXJzZVN1YmplY3Q+IHtcclxuICBjb25zdCBsb2dnZWRJblVzZXIgPSBNZXRlb3IudXNlcigpO1xyXG5cclxuICBpZiAoIWxvZ2dlZEluVXNlciB8fFxyXG4gICAgIVJvbGVzLnVzZXJJc0luUm9sZShsb2dnZWRJblVzZXIsIFsndHV0b3InLCAnbWFuYWdlLWNvdXJzZXMnLCAndmlldy1jb3Vyc2VzJywgJ2FkbWluJywgJ3N1cGVyLWFkbWluJ10sICdjb3Vyc2VzJykpIHtcclxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCAnQWNjZXNzIGRlbmllZCcpXHJcbiAgfVxyXG4gIHJldHVybiBDb3Vyc2VTdWJqZWN0cy5jb2xsZWN0aW9uLmZpbmQoe2NvdXJzZUlkOiBsb2dnZWRJblVzZXIuX2lkfSk7XHJcbn0pO1xyXG5cclxuXHJcbiIsImltcG9ydCB7SW52aXRhdGlvbnN9IGZyb20gJy4uLy4uL2NvbGxlY3Rpb25zL3VzZXJzL2ludml0YXRpb25zJztcblxuTWV0ZW9yLnB1Ymxpc2goICdpbnZpdGUnLCBmdW5jdGlvbiggdG9rZW4gKSB7XG4gIGNoZWNrKCB0b2tlbiwgU3RyaW5nICk7XG4gIHJldHVybiBJbnZpdGF0aW9ucy5maW5kKCB7ICd0b2tlbic6IHRva2VuIH0gKTtcbn0pO1xuIiwiaW1wb3J0IHtNZXNzYWdlfSBmcm9tICcuLi9tb2RlbHMnO1xyXG5pbXBvcnQge01lc3NhZ2VzfSBmcm9tICcuLi8uLi9jb2xsZWN0aW9ucyc7XHJcblxyXG5NZXRlb3IucHVibGlzaCgnbWVzc2FnZXMnLCBmdW5jdGlvbiAoXHJcbiAgY2hhdElkOiBzdHJpbmcsXHJcbiAgbWVzc2FnZXNCYXRjaENvdW50ZXI6IG51bWJlcik6IE1vbmdvLkN1cnNvcjxNZXNzYWdlPiB7XHJcbiAgaWYgKCF0aGlzLnVzZXJJZCB8fCAhY2hhdElkKSB7XHJcbiAgICBjb25zb2xlLmxvZygnSW52YWxpZCBVc2VyISEhJyk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIHJldHVybiBNZXNzYWdlcy5jb2xsZWN0aW9uLmZpbmQoe1xyXG4gICAgY2hhdElkXHJcbiAgfSwge1xyXG4gICAgc29ydDoge2NyZWF0ZWRBdDogLTF9LFxyXG4gICAgbGltaXQ6IDMwICogbWVzc2FnZXNCYXRjaENvdW50ZXJcclxuICB9KTtcclxufSk7XHJcbiIsImltcG9ydCB7UHJlZGljdGlvbnN9IGZyb20gJy4uLy4uL2NvbGxlY3Rpb25zJztcclxuXHJcbk1ldGVvci5wdWJsaXNoKCdwcmVkaWN0aW9ucycsIGZ1bmN0aW9uICgpe1xyXG5cdC8vUHJlZGljdGlvbnMucHVibGlzaCh0aGlzLCAndG90YWwtcHJlZGljdGlvbnMnLCBQcmVkaWN0aW9ucy5maW5kKCkpO1xyXG4gIFx0cmV0dXJuIFByZWRpY3Rpb25zLmZpbmQoe30pO1xyXG5cclxufSk7XHJcbiIsImltcG9ydCB7U3R1ZGVudHNEYXRhfSBmcm9tICcuLi8uLi9jb2xsZWN0aW9ucyc7XHJcblxyXG5NZXRlb3IucHVibGlzaCgnc3R1ZGVudHNEYXRhJywgZnVuY3Rpb24gKCl7XHJcbiAgcmV0dXJuIFN0dWRlbnRzRGF0YS5jb2xsZWN0aW9uLmZpbmQoKTtcclxufSk7XHJcbiIsImltcG9ydCB7VHJhbnNhY3Rpb25zfSBmcm9tICcuLi8uLi9jb2xsZWN0aW9ucyc7XG5cblxuTWV0ZW9yLnB1Ymxpc2goJ3RyYW5zYWN0aW9ucycsIGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIFRyYW5zYWN0aW9ucy5jb2xsZWN0aW9uLmZpbmQoe30pO1xufSk7XG4iLCJcbi8vIFRyYW5zYWN0aW9uYWxcblxuaW1wb3J0IHtUcmFuc2FjdGlvbkFjY291bnR9IGZyb20gJy4uL21vZGVscyc7XG5pbXBvcnQge1RyYW5zYWN0aW9uQWNjb3VudHN9IGZyb20gJy4uLy4uL2NvbGxlY3Rpb25zJztcblxuTWV0ZW9yLnB1Ymxpc2goJ3RyYW5zYWN0aW9uX2FjY291bnRzJywgZnVuY3Rpb24gKCk6IE1vbmdvLkN1cnNvcjxUcmFuc2FjdGlvbkFjY291bnQ+IHtcbiAgcmV0dXJuIFRyYW5zYWN0aW9uQWNjb3VudHMuY29sbGVjdGlvbi5maW5kKHtvd25lcklkOiBNZXRlb3IudXNlcklkKCkgfSk7XG59KTtcbiIsImltcG9ydCB7SW52aXRhdGlvbnMsIFVzZXJzfSBmcm9tICcuLi8uLi9jb2xsZWN0aW9ucyc7XG5cbk1ldGVvci5wdWJsaXNoKCAndXNlcnMnLCBmdW5jdGlvbigpIHtcbiAgY29uc3QgaXNBZG1pbiA9IFJvbGVzLnVzZXJJc0luUm9sZSggdGhpcy51c2VySWQsIFsnbWFuYWdlLXVzZXJzJywgJ2FkbWluJ10sICd1c2VycycpO1xuXG4gIGlmICggaXNBZG1pbiApIHtcbiAgICByZXR1cm4gW1xuICAgICAgVXNlcnMuZmluZCgge30sIHsgZmllbGRzOiB7ICdlbWFpbHMuYWRkcmVzcyc6IDEsICdyb2xlcyc6IDEgfSB9ICksXG4gICAgICBJbnZpdGF0aW9ucy5maW5kKCB7fSwgeyBmaWVsZHM6IHsgJ2VtYWlsJzogMSwgJ3JvbGUnOiAxLCAnZGF0ZSc6IDEgfSB9IClcbiAgICBdO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59KTtcblxuXG4iLCIvLy88cmVmZXJlbmNlIHBhdGg9XCIuLi9ub2RlX21vZHVsZXMvQHR5cGVzL21ldGVvci1yb2xlcy9pbmRleC5kLnRzXCIvPlxuaW1wb3J0IHtDaGF0cywgQ291cnNlcywgUHJlZGljdGlvbnN9IGZyb20gJy4uL2NvbGxlY3Rpb25zJztcbmltcG9ydCB7IE1lc3NhZ2VzIH0gZnJvbSAnLi4vY29sbGVjdGlvbnMnO1xuaW1wb3J0IHsgTWVzc2FnZVR5cGUsIFByb2ZpbGUgfSBmcm9tICcuL21vZGVscyc7XG5pbXBvcnQgeyBjaGVjaywgTWF0Y2ggfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IHsgUHJvbWlzZSB9IGZyb20gJ21ldGVvci9wcm9taXNlJztcblxuY29uc3Qgbm9uRW1wdHlTdHJpbmcgPSBNYXRjaC5XaGVyZSgoc3RyKSA9PiB7XG4gIGNoZWNrKHN0ciwgU3RyaW5nKTtcbiAgcmV0dXJuIHN0ci5sZW5ndGggPiAwO1xufSk7XG5cbmNvbnN0IGdldFN0YW5mb3JkVVJMID0gXCJodHRwczovL2hpdmRiLnN0YW5mb3JkLmVkdVwiO1xuY29uc3QgdGltZW91dDogYW55ID0gNTAwMDA7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgYWRkQ2hhdChyZWNlaXZlcklkOiBzdHJpbmcpOiB2b2lkIHtcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1bmF1dGhvcml6ZWQnLFxuICAgICAgICAnVXNlciBtdXN0IGJlIGxvZ2dlZC1pbiB0byBjcmVhdGUgYSBuZXcgY2hhdCcpO1xuICAgIH1cblxuICAgIGNoZWNrKHJlY2VpdmVySWQsIG5vbkVtcHR5U3RyaW5nKTtcblxuICAgIGlmIChyZWNlaXZlcklkID09PSB0aGlzLnVzZXJJZCkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignaWxsZWdhbC1yZWNlaXZlcicsXG4gICAgICAgICdSZWNlaXZlciBtdXN0IGJlIGRpZmZlcmVudCB0aGFuIHRoZSBjdXJyZW50IGxvZ2dlZCBpbiB1c2VyJyk7XG4gICAgfVxuXG4gICAgY29uc3QgY2hhdEV4aXN0cyA9ICEhQ2hhdHMuY29sbGVjdGlvbi5maW5kKHtcbiAgICAgIG1lbWJlcklkczogeyAkYWxsOiBbdGhpcy51c2VySWQsIHJlY2VpdmVySWRdIH1cbiAgICB9KS5jb3VudCgpO1xuXG4gICAgaWYgKGNoYXRFeGlzdHMpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2NoYXQtZXhpc3RzJyxcbiAgICAgICAgJ0NoYXQgYWxyZWFkeSBleGlzdHMnKTtcbiAgICB9XG5cbiAgICBjb25zdCBjaGF0ID0ge1xuICAgICAgbWVtYmVySWRzOiBbdGhpcy51c2VySWQsIHJlY2VpdmVySWRdXG4gICAgfTtcblxuICAgIENoYXRzLmluc2VydChjaGF0KTtcbiAgfSxcbiAgcmVtb3ZlQ2hhdChjaGF0SWQ6IHN0cmluZyk6IHZvaWQge1xuICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3VuYXV0aG9yaXplZCcsXG4gICAgICAgICdVc2VyIG11c3QgYmUgbG9nZ2VkLWluIHRvIHJlbW92ZSBjaGF0Jyk7XG4gICAgfVxuICAgIGNoZWNrKGNoYXRJZCwgbm9uRW1wdHlTdHJpbmcpO1xuICAgIGNvbnN0IGNoYXRFeGlzdHMgPSAhIUNoYXRzLmNvbGxlY3Rpb24uZmluZChjaGF0SWQpLmNvdW50KCk7XG5cbiAgICBpZiAoIWNoYXRFeGlzdHMpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2NoYXQtbm90LWV4aXN0cycsXG4gICAgICAgICdDaGF0IGRvZXNuXFwndCBleGlzdCcpO1xuICAgIH1cblxuICAgIENoYXRzLnJlbW92ZShjaGF0SWQpO1xuICB9LFxuICB1cGRhdGVQcm9maWxlKHByb2ZpbGU6IFByb2ZpbGUpOiB2b2lkIHtcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7IHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3VuYXV0aG9yaXplZCcsXG4gICAgICAnVXNlciBtdXN0IGJlIGxvZ2dlZC1pbiB0byBjcmVhdGUgYSBuZXcgY2hhdCcpO1xuICAgIH1cbiAgICBjaGVjayhwcm9maWxlLCB7XG4gICAgICBuYW1lOiBub25FbXB0eVN0cmluZ1xuICAgIH0pO1xuXG4gICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh0aGlzLnVzZXJJZCwge1xuICAgICAgJHNldDoge3Byb2ZpbGV9XG4gICAgfSk7XG4gIH0sXG4gIGFkZFJvbGVUb1VzZXIodXNlcklkLCByb2xlLCBncm91cCkge1xuICAgIGlmIChncm91cCkge1xuICAgICAgUm9sZXMuYWRkVXNlcnNUb1JvbGVzKHVzZXJJZCwgcm9sZSwgZ3JvdXApO1xuICAgIH0gZWxzZSB7XG4gICAgICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXModXNlcklkLCByb2xlKTtcbiAgICB9XG4gIH0sXG4gIHJlbW92ZVJvbGVGcm9tVXNlcih1c2VySWQsIHJvbGUsIGdyb3VwPykge1xuICAgIGlmIChncm91cCkge1xuICAgICAgUm9sZXMuYWRkVXNlcnNUb1JvbGVzKHVzZXJJZCwgcm9sZSwgZ3JvdXApO1xuICAgIH0gZWxzZSB7XG4gICAgICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXModXNlcklkLCByb2xlKTtcbiAgICB9XG4gIH0sXG4gIGFkZENvdXJzZShjb3Vyc2VOYW1lLCBjb3Vyc2VEZXNjcmlwdGlvbikge1xuICAgIGlmICghdGhpcy51c2VySWQpIHsgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndW5hdXRob3JpemVkJyxcbiAgICAgICdVc2VyIG11c3QgYmUgbG9nZ2VkLWluIHRvIGNyZWF0ZSBhIG5ldyBjb3Vyc2UnKTtcbiAgICB9XG5cbiAgICBjaGVjayhjb3Vyc2VOYW1lLCBTdHJpbmcpO1xuICAgIGNoZWNrKGNvdXJzZURlc2NyaXB0aW9uLCBTdHJpbmcpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIGNvdXJzZTogQ291cnNlcy5jb2xsZWN0aW9uLmluc2VydCh7XG4gICAgICAgIG5hbWU6IGNvdXJzZU5hbWUsXG4gICAgICAgIG93bmVyc2hpcDogdGhpcy51c2VySWQsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBjb3Vyc2VEZXNjcmlwdGlvblxuICAgICAgfSlcbiAgICB9O1xuICB9LFxuICBhZGRNZXNzYWdlKHR5cGU6IE1lc3NhZ2VUeXBlLCBjaGF0SWQ6IHN0cmluZywgY29udGVudDogc3RyaW5nKSB7XG4gICAgaWYgKCF0aGlzLnVzZXJJZCkgeyB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1bmF1dGhvcml6ZWQnLFxuICAgICAgJ1VzZXIgbXVzdCBiZSBsb2dnZWQtaW4gdG8gY3JlYXRlIGEgbmV3IGNoYXQnKTtcbiAgICB9XG5cbiAgICBjaGVjayh0eXBlLCBNYXRjaC5PbmVPZihTdHJpbmcsIFsgTWVzc2FnZVR5cGUuVEVYVCBdKSk7XG4gICAgY2hlY2soY2hhdElkLCBub25FbXB0eVN0cmluZyk7XG4gICAgY2hlY2soY29udGVudCwgbm9uRW1wdHlTdHJpbmcpO1xuXG4gICAgY29uc3QgY2hhdEV4aXN0cyA9ICEhQ2hhdHMuY29sbGVjdGlvbi5maW5kKGNoYXRJZCkuY291bnQoKTtcblxuICAgIGlmICghY2hhdEV4aXN0cykge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignY2hhdC1ub3QtZXhpc3RzJyxcbiAgICAgICAgJ0NoYXQgZG9lc25cXCd0IGV4aXN0Jyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG1lc3NhZ2VJZDogTWVzc2FnZXMuY29sbGVjdGlvbi5pbnNlcnQoe1xuICAgICAgICBjaGF0SWQ6IGNoYXRJZCxcbiAgICAgICAgc2VuZGVySWQ6IHRoaXMudXNlcklkLFxuICAgICAgICBjb250ZW50OiBjb250ZW50LFxuICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgICAgIHR5cGU6IHR5cGVcbiAgICAgIH0pXG4gICAgfTtcbiAgfSxcbiAgY291bnRNZXNzYWdlcygpOiBudW1iZXIge1xuICAgIHJldHVybiBNZXNzYWdlcy5jb2xsZWN0aW9uLmZpbmQoKS5jb3VudCgpO1xuICB9LFxuICBjcmVhdGVTeXN0ZW1Vc2VyIChlbWFpbCwgcGFzc3dvcmQpIHtcbiAgICBBY2NvdW50cy5jcmVhdGVVc2VyKHtlbWFpbDogcGFzc3dvcmR9KTtcbiAgfSxcblxuICBwcmVkaWN0KGJvZHk6IGFueSwgaXNTZXF1ZW5jZT8gOiBib29sZWFuKSB7XG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndW5hdXRob3JpemVkJyxcbiAgICAgICAgJ1VzZXIgbXVzdCBiZSBsb2dnZWQtaW4gdG8gY3JlYXRlIGEgbmV3IHJlcXVlc3QnKTtcbiAgICB9XG4gICAgY29uc29sZS5sb2coJ2JvZHknLCBib2R5KTtcbiAgICBsZXQgYm9keUZvcm1hdHRlZCA9IHt9O1xuICAgIGxldCBxdWVyeSA9IHt9O1xuXG4gICAgaWYoaXNTZXF1ZW5jZSkge1xuICAgICAgYm9keUZvcm1hdHRlZCA9IHsgXCJzZXF1ZW5jZXNcIjogSlNPTi5wYXJzZShib2R5LnNlcXVlbmNlcyApIH07ICAgXG5cbiAgICAgIGNvbnNvbGUubG9nKGJvZHlGb3JtYXR0ZWQpO1xuICAgICAgcXVlcnkgPSB7XG4gICAgICAgIG9wZXJhdGlvbk5hbWU6XCJleGFtcGxlXCJcbiAgICAgICAgLFxuICAgICAgICAgcXVlcnkgOiBcInF1ZXJ5IGV4YW1wbGUoJHNlcXVlbmNlczogW1VuYWxpZ25lZFNlcXVlbmNlSW5wdXRdISkgeyAgIHZpZXdlciB7ICAgICBjdXJyZW50VmVyc2lvbiB7IHRleHQsIHB1Ymxpc2hEYXRlIH0sICAgICBzZXF1ZW5jZUFuYWx5c2lzKHNlcXVlbmNlczogJHNlcXVlbmNlcykgeyAgICAgICAgIGlucHV0U2VxdWVuY2UgeyAgICAgICAgIGhlYWRlciwgICAgICAgICBzZXF1ZW5jZSwgICAgICAgICBNRDUsICAgICAgICAgU0hBNTEyICAgICAgIH0sICAgICAgIHZhbGlkYXRpb25SZXN1bHRzIHsgICAgICAgICBsZXZlbCwgICAgICAgICBtZXNzYWdlICAgICAgIH0sICAgICAgIGFic29sdXRlRmlyc3ROQSwgICAgICAgYWxpZ25lZEdlbmVTZXF1ZW5jZXMgeyAgICAgICAgIGdlbmUgeyAgICAgICAgICAgbmFtZSwgICAgICAgICAgIGNvbnNlbnN1cywgICAgICAgICAgIGxlbmd0aCwgICAgICAgICAgIGRydWdDbGFzc2VzIHsgICAgICAgICAgICAgbmFtZSwgICAgICAgICAgICAgZnVsbE5hbWUsICAgICAgICAgICAgIGRydWdzIHsgICAgICAgICAgICAgICBuYW1lLCAgICAgICAgICAgICAgIGRpc3BsYXlBYmJyLCAgICAgICAgICAgICAgIGZ1bGxOYW1lICAgICAgICAgICAgIH0gICAgICAgICAgIH0sICAgICAgICAgICBtdXRhdGlvblR5cGVzICAgICAgICAgfSwgICAgICAgICBmaXJzdEFBLCAgICAgICAgIGxhc3RBQSwgICAgICAgICBmaXJzdE5BLCAgICAgICAgIGxhc3ROQSwgICAgICAgICBtYXRjaFBjbnQsICAgICAgICAgcHJldHR5UGFpcndpc2UgeyAgICAgICAgICAgcG9zaXRpb25MaW5lLCAgICAgICAgICAgcmVmQUFMaW5lLCAgICAgICAgICAgYWxpZ25lZE5Bc0xpbmUsICAgICAgICAgICBtdXRhdGlvbkxpbmUgICAgICAgICB9LCAgICAgICAgIG11dGF0aW9ucyB7ICAgICAgICAgICBjb25zZW5zdXMsICAgICAgICAgICBwb3NpdGlvbiwgICAgICAgICAgIEFBcywgICAgICAgICAgIHRyaXBsZXQsICAgICAgICAgICBpbnNlcnRlZE5BcywgICAgICAgICAgIGlzSW5zZXJ0aW9uLCAgICAgICAgICAgaXNEZWxldGlvbiwgICAgICAgICAgIGlzSW5kZWwsICAgICAgICAgICBpc0FtYmlndW91cywgICAgICAgICAgIGlzQXBvYmVjTXV0YXRpb24sICAgICAgICAgICBpc0Fwb2JlY0RSTSwgICAgICAgICAgIGhhc1N0b3AsICAgICAgICAgICBpc1VudXN1YWwsICAgICAgICAgICB0eXBlcywgICAgICAgICAgIHByaW1hcnlUeXBlLCAgICAgICAgICAgY29tbWVudHMgeyAgICAgICAgICAgICB0cmlnZ2VyZWRBQXMsICAgICAgICAgICAgIHR5cGUsICAgICAgICAgICAgIHRleHQgICAgICAgICAgIH0sICAgICAgICAgICB0ZXh0LCAgICAgICAgICAgc2hvcnRUZXh0ICAgICAgICAgfSwgICAgICAgICBBUE9CRUM6IG11dGF0aW9ucyhmaWx0ZXJPcHRpb25zOiBbQVBPQkVDXSkgeyAgICAgICAgICAgcG9zaXRpb24sICAgICAgICAgICBBQXMsICAgICAgICAgICB0ZXh0ICAgICAgICAgfSwgICAgICAgICBBUE9CRUNfRFJNOiBtdXRhdGlvbnMoZmlsdGVyT3B0aW9uczogW0FQT0JFQ19EUk1dKSB7ICAgICAgICAgICB0ZXh0ICAgICAgICAgfSwgICAgICAgICBEUk06IG11dGF0aW9ucyhmaWx0ZXJPcHRpb25zOiBbRFJNXSkgeyAgICAgICAgICAgdGV4dCAgICAgICAgIH0sICAgICAgICAgU0RSTTogbXV0YXRpb25zKGZpbHRlck9wdGlvbnM6IFtTRFJNXSkgeyAgICAgICAgICAgdGV4dCAgICAgICAgIH0sICAgICAgICAgdW51c3VhbE11dGF0aW9uczogbXV0YXRpb25zKGZpbHRlck9wdGlvbnM6IFtVTlVTVUFMXSkgeyAgICAgICAgICAgdGV4dCAgICAgICAgIH0sICAgICAgICAgdHJlYXRtZW50U2VsZWN0ZWRNdXRhdGlvbnM6IG11dGF0aW9ucyggICAgICAgICAgIGZpbHRlck9wdGlvbnM6IFtQSV9UU00sIE5SVElfVFNNLCBOTlJUSV9UU00sIElOU1RJX1RTTV0gICAgICAgICApIHsgICAgICAgICAgIHRleHQgICAgICAgICB9LCAgICAgICAgIGZyYW1lU2hpZnRzIHsgICAgICAgICAgIHBvc2l0aW9uLCAgICAgICAgICAgaXNJbnNlcnRpb24sICAgICAgICAgICBpc0RlbGV0aW9uLCAgICAgICAgICAgc2l6ZSwgICAgICAgICAgIE5BcywgICAgICAgICAgIHRleHQgICAgICAgICB9ICAgICAgIH0sICAgICAgIGZpcnN0VGVuQ2xvc2VTdWJ0eXBlczogc3VidHlwZXNWMihmaXJzdDogMTApIHsgICAgICAgICBkaXNwbGF5V2l0aG91dERpc3RhbmNlLCAgICAgICAgIGRpc3RhbmNlUGNudCwgICAgICAgICByZWZlcmVuY2VBY2Nlc3Npb24gICAgICAgfSwgICAgICAgYmVzdE1hdGNoaW5nU3VidHlwZSB7IGRpc3BsYXkgfSwgICAgICAgbWl4dHVyZVBjbnQsICAgICAgIG11dGF0aW9ucyB7ICAgICAgICAgcG9zaXRpb24sICAgICAgICAgQUFzLCAgICAgICAgIHNob3J0VGV4dCAgICAgICB9LCAgICAgICBmcmFtZVNoaWZ0cyB7ICAgICAgICAgdGV4dCAgICAgICB9LCAgICAgICBkcnVnUmVzaXN0YW5jZSB7ICAgICAgICAgZ2VuZSB7ICAgICAgICAgICBuYW1lLCAgICAgICAgICAgY29uc2Vuc3VzLCAgICAgICAgICAgbGVuZ3RoLCAgICAgICAgICAgZHJ1Z0NsYXNzZXMgeyBuYW1lIH0sICAgICAgICAgICBtdXRhdGlvblR5cGVzICAgICAgICAgfSwgICAgICAgICBkcnVnU2NvcmVzIHsgICAgICAgICAgIGRydWdDbGFzcyB7ICAgICAgICAgICAgIG5hbWUsICAgICAgICAgICAgIGZ1bGxOYW1lLCAgICAgICAgICAgICBkcnVncyB7ICAgICAgICAgICAgICAgbmFtZSwgICAgICAgICAgICAgICBkaXNwbGF5QWJiciwgICAgICAgICAgICAgICBmdWxsTmFtZSAgICAgICAgICAgICB9ICAgICAgICAgICB9LCAgICAgICAgICAgZHJ1ZyB7IGRpc3BsYXlBYmJyIH0sICAgICAgICAgICBTSVIsICAgICAgICAgICBzY29yZSwgICAgICAgICAgIGxldmVsLCAgICAgICAgICAgdGV4dCwgICAgICAgICAgIHBhcnRpYWxTY29yZXMgeyAgICAgICAgICAgICBtdXRhdGlvbnMgeyAgICAgICAgICAgICAgIHRleHQgICAgICAgICAgICAgfSwgICAgICAgICAgICAgc2NvcmUgICAgICAgICAgIH0gICAgICAgICB9LCAgICAgICAgIG11dGF0aW9uc0J5VHlwZXMgeyAgICAgICAgICAgbXV0YXRpb25UeXBlLCAgICAgICAgICAgbXV0YXRpb25zIHsgICAgICAgICAgICAgY29uc2Vuc3VzLCAgICAgICAgICAgICBwb3NpdGlvbiwgICAgICAgICAgICAgQUFzLCAgICAgICAgICAgICB0cmlwbGV0LCAgICAgICAgICAgICBpbnNlcnRlZE5BcywgICAgICAgICAgICAgaXNJbnNlcnRpb24sICAgICAgICAgICAgIGlzRGVsZXRpb24sICAgICAgICAgICAgIGlzSW5kZWwsICAgICAgICAgICAgIGlzQW1iaWd1b3VzLCAgICAgICAgICAgICBpc0Fwb2JlY011dGF0aW9uLCAgICAgICAgICAgICBpc0Fwb2JlY0RSTSwgICAgICAgICAgICAgaGFzU3RvcCwgICAgICAgICAgICAgaXNVbnVzdWFsLCAgICAgICAgICAgICB0ZXh0LCAgICAgICAgICAgICBzaG9ydFRleHQgICAgICAgICAgIH0gICAgICAgICB9ICAgICAgICAgY29tbWVudHNCeVR5cGVzIHsgICAgICAgICAgIGNvbW1lbnRUeXBlLCAgICAgICAgICAgY29tbWVudHMgeyAgICAgICAgICAgICB0eXBlLCAgICAgICAgICAgICB0ZXh0LCAgICAgICAgICAgICBoaWdobGlnaHRUZXh0ICAgICAgICAgICB9ICAgICAgICAgfSAgICAgICB9ICAgICAgICAgfSAgIH0gfVwiXG4gICAgICAgICxcbiAgICAgICAgdmFyaWFibGVzIDogYm9keUZvcm1hdHRlZFxuICAgICAgfTtcblxuICAgIH0gZWxzZSB7XG4gICAgICBib2R5Rm9ybWF0dGVkID0ge1wibXV0YXRpb25zXCI6IEpTT04ucGFyc2UoYm9keS5tdXRhdGlvbnMgKX07XG5cbiAgICAgICBxdWVyeSA9IHtcbiAgICAgICAgcXVlcnk6IFwicXVlcnkgZXhhbXBsZSgkbXV0YXRpb25zOltTdHJpbmddISkgeyAgdmlld2VyIHsgICAgY3VycmVudFZlcnNpb24geyB0ZXh0LCBwdWJsaXNoRGF0ZSB9LCAgICBtdXRhdGlvbnNBbmFseXNpcyhtdXRhdGlvbnM6ICRtdXRhdGlvbnMpIHsgICAgICB2YWxpZGF0aW9uUmVzdWx0cyB7bGV2ZWwsICAgICAgICAgbWVzc2FnZSAgICAgICB9LCAgICAgICBkcnVnUmVzaXN0YW5jZSB7ICAgICAgICAgZ2VuZSB7IG5hbWUgfSwgICAgICAgICBkcnVnU2NvcmVzIHsgICAgICAgICAgIGRydWdDbGFzcyB7IG5hbWUgfSwgICAgICAgICAgIGRydWcgeyBuYW1lLGRpc3BsYXlBYmJyLGZ1bGxOYW1lfSwgICAgICAgICAgIFNJUiwgICAgICAgICAgIHNjb3JlLCAgICAgICAgICAgbGV2ZWwsICAgICAgICAgICB0ZXh0LCAgICAgICAgICAgcGFydGlhbFNjb3JlcyB7ICAgICAgICAgICAgIG11dGF0aW9ucyB7ICAgICAgICAgICAgICAgdGV4dCAgICAgICAgICAgICB9LCAgICAgICAgICAgICBzY29yZSAgICAgICAgICAgfSAgICAgICAgIH0sICAgICAgICAgbXV0YXRpb25zQnlUeXBlcyB7ICAgICAgICAgICBtdXRhdGlvblR5cGUsICAgICAgICAgICBtdXRhdGlvbnMgeyAgICAgICAgICAgICB0ZXh0ICAgICAgICAgICB9ICAgICAgICAgfSAgICAgICAgIGNvbW1lbnRzQnlUeXBlcyB7ICAgICAgICAgICBjb21tZW50VHlwZSwgICAgICAgICAgIGNvbW1lbnRzIHsgICAgICAgICAgICAgdGV4dCAgICAgICAgICAgfSAgICAgICAgIH0gICAgICAgfSAgICAgfSAgIH0gfVwiXG4gICAgICAgICxcbiAgICAgICAgdmFyaWFibGVzOiAgYm9keUZvcm1hdHRlZCBcbiAgICAgIH07XG5cbiAgIH1cblxuICAgIGNvbnNvbGUubG9nKGJvZHlGb3JtYXR0ZWQpO1xuICAgIGNvbnNvbGUubG9nKHF1ZXJ5KTtcblxuICAgIGxldCB0aGVCb2R5ID0gSlNPTi5zdHJpbmdpZnkocXVlcnkpO1xuXG4gICAgY29uc3QgcHJlZGl0aW9uUmVxdWVzdCA9IHtcbiAgICAgIHJlcXVlc3RlZEJ5OiB0aGlzLnVzZXJJZCxcbiAgICAgIHJlcXVlc3Q6IHRoZUJvZHksXG4gICAgICByZXNwb25zZTogJ1BFTkRJTkcnLFxuICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpXG4gICAgfTtcblxuICAgIGxldCBwcmVkaWN0aW9uSWQgPSBQcmVkaWN0aW9ucy5jb2xsZWN0aW9uLmluc2VydChwcmVkaXRpb25SZXF1ZXN0KTtcblxuICAgIGNvbnNvbGUubG9nKCdTYXZlIFByZWRpY3Rpb24gJyArIHByZWRpY3Rpb25JZCk7XG4gICAgY29uc29sZS5sb2coJ1NlbmRpbmcgJyArIHRoZUJvZHkpO1xuXG4gICAgdmFyIG9wdGlvbnMgPSB7XG4gICAgICBob3N0OiBnZXRTdGFuZm9yZFVSTCxcbiAgICAgIHBhdGg6ICcvZ3JhcGhxbCcsXG4gICAgICBtZXRob2Q6ICdQT1NUJywgXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbidcbiAgICAgIH1cbiAgICB9O1xuICAgIGxldCBmZXRjaCA9IHJlcXVpcmUoJ25vZGUtZmV0Y2gnKTtcblxuICAgIGxldCB0aGVSZXNwb25zZSA9ICcnO1xuXG4gICAgUHJvbWlzZS5hd2FpdChcbiAgICAgdGhlUmVzcG9uc2UgPSBmZXRjaChvcHRpb25zLmhvc3QgKyBvcHRpb25zLnBhdGgsIHtcbiAgICAgIG1ldGhvZDogb3B0aW9ucy5tZXRob2QsXG4gICAgICBoZWFkZXJzOiB7J0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJ30sXG4gICAgICBib2R5OiB0aGVCb2R5XG4gICAgfSlcbiAgICAudGhlbihyZXNwb25zZSA9PiByZXNwb25zZS5qc29uKCkpXG4gICAgLnRoZW4ocmVzcG9uc2UgPT4gcmVzcG9uc2UuZGF0YS52aWV3ZXIpXG4gICAgLnRoZW4ocmVzcG9uc2UgPT4ge1xuXG4gICAgICAvL3VwZGF0ZSByZXNwb25zZVxuICAgICBQcmVkaWN0aW9ucy5jb2xsZWN0aW9uLnVwZGF0ZShwcmVkaWN0aW9uSWQsIHskc2V0OiB7cmVzcG9uc2UgOiBKU09OLnN0cmluZ2lmeShyZXNwb25zZSl9IH0pO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuXG4gICAgfSlcbiAgICAuY2F0Y2goZXJyID0+IHtcbiAgICAgIHJldHVybiBlcnI7XG5cbiAgICB9KSk7XG4gICAgXG4gICAgY29uc29sZS5sb2codGhlUmVzcG9uc2UpO1xuXG4gICAgcmV0dXJuIHRoZVJlc3BvbnNlO1xuICB9XG5cblxufSk7XG5cbiIsImV4cG9ydCBjb25zdCBERUZBVUxUX1BJQ1RVUkVfVVJMID0gJy9hc3NldHMvZGVmYXVsdC1wcm9maWxlLXBpYy5zdmcnO1xuXG5leHBvcnQgaW50ZXJmYWNlIFByb2ZpbGUge1xuICBuYW1lPzogc3RyaW5nO1xuICBwaWN0dXJlPzogc3RyaW5nO1xuICBwaWN0dXJlSWQ/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgU3R1ZGVudERhdGEge1xuICBfaWQ/OiBzdHJpbmc7XG4gIG5hbWU/OiBzdHJpbmc7XG4gIHVzZXJuYW1lPzogc3RyaW5nO1xufVxuXG5leHBvcnQgZW51bSBNZXNzYWdlVHlwZSB7XG4gIFRFWFQgPSA8YW55Pid0ZXh0JyxcbiAgTE9DQVRJT04gPSA8YW55Pidsb2NhdGlvbicsXG4gIFBJQ1RVUkUgPSA8YW55PidwaWN0dXJlJ1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENoYXQge1xuICBfaWQ/OiBzdHJpbmc7XG4gIHRpdGxlPzogc3RyaW5nO1xuICBwaWN0dXJlPzogc3RyaW5nO1xuICBsYXN0TWVzc2FnZT86IE1lc3NhZ2U7XG4gIG1lbWJlcklkcz86IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE1lc3NhZ2Uge1xuICBfaWQ/OiBzdHJpbmc7XG4gIGNoYXRJZD86IHN0cmluZztcbiAgc2VuZGVySWQ/OiBzdHJpbmc7XG4gIGNvbnRlbnQ/OiBzdHJpbmc7XG4gIGNyZWF0ZWRBdD86IERhdGU7XG4gIHR5cGU/OiBNZXNzYWdlVHlwZVxuICBvd25lcnNoaXA/OiBzdHJpbmc7XG59XG5leHBvcnQgaW50ZXJmYWNlIENvdXJzZSB7XG4gIF9pZD86IHN0cmluZztcbiAgbmFtZT86IHN0cmluZztcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gIG93bmVyc2hpcD86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb3Vyc2VTdWJqZWN0IHtcbiAgX2lkPzogc3RyaW5nO1xuICBuYW1lPzogc3RyaW5nO1xuICBkZXNjcmlwdGlvbj86IHN0cmluZztcbiAgY291cnNlSWQ/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBlbnVtIFF1ZXN0aW9uVHlwZSB7XG4gIE9QRU5fRU5ERUQgPSAnT1BFTl9FTkRFRCcsXG4gIE1VTFRJUExFX0NIT0lDRSA9ICdNVUxUSVBMRV9DSE9JQ0UnLFxuICBCUk9LRU5fUEFTU0FHRSA9ICdCUk9LRU5fUEFTU0FHRScsXG4gIE1BVENISU5HID0gJ01BVENISU5HJ1xufVxuXG5pbnRlcmZhY2UgUXVlc3Rpb24ge1xuICBpZD86IHN0cmluZztcbiAgdHlwZT86IFF1ZXN0aW9uVHlwZTtcbiAgcXVlcnk/OiBhbnk7XG4gIGFuc3dlcj86IGFueTtcbiAgcGF5bG9hZD86IGFueTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBRdWVzdGlvbkNob2ljZSB7XG4gIGlkPzogc3RyaW5nO1xuICBjaG9pY2U/OiBzdHJpbmc7XG4gIGlzQ29ycmVjdD86IGJvb2xlYW47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQXNzaWdubWVudCB7XG4gIGlkPzogc3RyaW5nO1xuICB0aXRsZT86IHN0cmluZztcbiAgcXVlc3Rpb25zPzogUXVlc3Rpb25bXTtcbn1cblxuZXhwb3J0IGVudW0gUm9sZXNFbnVtIHtcbiAgQURNSU4gPSAnQURNSU4nLFxuICBTVVBFUl9BRE1JTiA9ICdTVVBFUl9BRE1JTicsXG4gIFRVVE9SID0gJ1RVVE9SJyxcbiAgU1RVREVOVCA9ICdTVFVERU5UJyxcbiAgJ1BBUkVOVCcgPSAnUEFSRU5UJ1xufVxuXG5leHBvcnQgZW51bSBBY3Rpb25QZXJtaXNzaW9uc0VudW0ge1xuICAgICAgQ1JFQVRFPSAnQ1JFQVRFJyxcbiAgICAgIFZJRVc9ICdWSUVXJyxcbiAgICAgIFVQREFURT0gJ1VQREFURScsXG4gICAgICBERUxFVEU9ICdERUxFVEUnXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUm9sZSB7XG4gIF9pZD86IHN0cmluZztcbiAgbmFtZT86IFJvbGVzRW51bSxcbiAgcGVybWlzc2lvbnM/OiBBY3Rpb25QZXJtaXNzaW9uXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQWN0aW9uUGVybWlzc2lvbiB7XG4gIF9pZD86IHN0cmluZztcbiAgcGVybWlzc2lvbj86IEFjdGlvblBlcm1pc3Npb25zRW51bVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIFVzZXIgZXh0ZW5kcyBNZXRlb3IuVXNlciB7XG4gIHByb2ZpbGU/OiBQcm9maWxlLFxuICByb2xlSWQ/OiBbc3RyaW5nXVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIExvY2F0aW9uIHtcbiAgbGF0OiBudW1iZXI7XG4gIGxuZzogbnVtYmVyO1xuICB6b29tOiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUGljdHVyZSB7XG4gIF9pZD86IHN0cmluZztcbiAgY29tcGxldGU/OiBib29sZWFuO1xuICBleHRlbnNpb24/OiBzdHJpbmc7XG4gIG5hbWU/OiBzdHJpbmc7XG4gIHByb2dyZXNzPzogbnVtYmVyO1xuICBzaXplPzogbnVtYmVyO1xuICBzdG9yZT86IHN0cmluZztcbiAgdG9rZW4/OiBzdHJpbmc7XG4gIHR5cGU/OiBzdHJpbmc7XG4gIHVwbG9hZGVkQXQ/OiBEYXRlO1xuICB1cGxvYWRpbmc/OiBib29sZWFuO1xuICB1cmw/OiBzdHJpbmc7XG4gIHVzZXJJZD86IHN0cmluZztcbn1cblxuZXhwb3J0IGVudW0gVHJhbnNhY3Rpb25UeXBlIHtcbiAgQkFMQU5DRV9JTlFVSVJZID0gJ0JBTEFOQ0VfSU5RVUlSWScsXG4gIEZVTkRTX1RSQU5TRkVSID0gJ0ZVTkRTX1RSQU5TRkVSJ1xufVxuXG5leHBvcnQgZW51bSBUcmFuc2FjdGlvbkRpcmVjdGlvbiB7XG4gIEZPUldBUkQ9ICdGT1JXQVJEJyxcbiAgUkVWRVJTQUw9ICdSRVZFUlNBTCdcbn1cblxuaW50ZXJmYWNlIFRyYW5zYWN0aW9uSGVhZGVyIHtcbiAgZGlyZWN0aW9uPzogVHJhbnNhY3Rpb25EaXJlY3Rpb24sXG4gIGlzUmV0cnk/OiBib29sZWFuLFxuICByZXRyeUNvdW50PzogbnVtYmVyXG59XG5cbmV4cG9ydCBlbnVtIFRyYW5zYWN0aW9uU3RhdHVzIHtcbiAgUE9TVEVEID0gJ1BPU1RFRCcsXG4gIFBST0NFU1NJTkcgPSAnUFJPQ0VTU0lORycsXG4gIFBST0NFU1NFRCA9ICdQUk9DRVNTRUQnLFxuICBGQUlMRUQgPSAnRkFJTEVEJ1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRyYW5zYWN0aW9uIHtcbiAgX2lkPzogc3RyaW5nO1xuICBpbml0aWF0b3JJZD86IHN0cmluZztcbiAgcmVmSWQ/OiBzdHJpbmc7XG4gIGhlYWRlcj86IFRyYW5zYWN0aW9uSGVhZGVyO1xuICBwYXlsb2FkPzogYW55O1xuICB0eXBlOiBUcmFuc2FjdGlvblR5cGUsXG4gIHN0YXR1czogVHJhbnNhY3Rpb25TdGF0dXNcbn1cblxuZXhwb3J0IGludGVyZmFjZSBUcmFuc2FjdGlvblJlZmVyZW5jZSB7XG4gIF9pZD86IHN0cmluZyxcbiAgY3JlYXRlZEF0OiBEYXRlXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVHJhbnNhY3Rpb25BY2NvdW50IHtcbiAgX2lkPzogc3RyaW5nLFxuICBvd25lcklkOiBzdHJpbmcsXG4gIGFjY291bnROdW1iZXI/OiBzdHJpbmcsXG4gIGFjdHVhbEJhbGFuY2U/OiBudW1iZXIsXG4gIGF2YWlsYWJsZUJhbGFuY2U/OiBudW1iZXJcbn1cblxuXG5cbi8qXG5ISVYgREJcbiovXG5leHBvcnQgaW50ZXJmYWNlIFByZWRpdGlvbiB7XG4gIF9pZD86IHN0cmluZyxcbiAgcmVxdWVzdGVkQnk6IHN0cmluZyxcbiAgcmVxdWVzdDogYW55LFxuICByZXNwb25zZTogYW55LFxuICBjcmVhdGVkQXQ6IERhdGVcblxufVxuIiwiLy8gTGlzdGVuIHRvIGluY29taW5nIEhUVFAgcmVxdWVzdHMgKGNhbiBvbmx5IGJlIHVzZWQgb24gdGhlIHNlcnZlcikuXHJcbmltcG9ydCB7V2ViQXBwfSBmcm9tICdtZXRlb3Ivd2ViYXBwJztcclxuaW1wb3J0IHtDb3Vyc2VzfSBmcm9tICcuLi9jb2xsZWN0aW9ucyc7XHJcbmltcG9ydCB7UHJlZGljdGlvbnN9IGZyb20gXCIuLi9jb2xsZWN0aW9ucy9oaXZkYlwiO1xyXG5pbXBvcnQge0NvdW50c30gZnJvbSAnbWV0ZW9yL3JvczpwdWJsaXNoLWNvdW50cyc7XHJcblxyXG5NZXRlb3IucHVibGlzaCgncHJlZGljdGlvbnMuY291bnQnLCBmdW5jdGlvbih7IH0pIHtcclxuXHJcbiAgQ291bnRzLnB1Ymxpc2godGhpcywgJ3ByZWRpY3Rpb25zLmNvdW50JywgUHJlZGljdGlvbnMuZmluZCgpKTtcclxufSk7XHJcblxyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL2hlbGxvJywgKHJlcSwgcmVzLCBuZXh0KSA9PiB7XHJcbiAgcmVzLndyaXRlSGVhZCgyMDApO1xyXG4gIHJlcy5lbmQoYEhlbGxvIHdvcmxkIGZyb206ICR7TWV0ZW9yLnJlbGVhc2V9YCk7XHJcbn0pLnVzZSgnL2NvdXJzZXMnLCAocmVxLCByZXMsIG5leHQpID0+IHtcclxuXHJcbiAgcmVzLndyaXRlSGVhZCgyMDApO1xyXG4gIHJlcy5lbmQoSlNPTi5zdHJpbmdpZnkoQ291cnNlcy5jb2xsZWN0aW9uLmZpbmQoe30pLmZldGNoKCkpKTtcclxufSkudXNlKCcvY291cnNlcy9pZCcsIChyZXEsIHJlcywgbmV4dCkgPT4ge1xyXG5cclxuXHJcbiAgcmVzLndyaXRlSGVhZCgyMDApO1xyXG4gIHJlcy5lbmQoSlNPTi5zdHJpbmdpZnkoQ291cnNlcy5jb2xsZWN0aW9uLmZpbmRPbmUoe30pKSk7XHJcbn0pO1xyXG5cclxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJztcbmltcG9ydCB7VXNlcnN9IGZyb20gXCIuLi9jb2xsZWN0aW9ucy91c2Vyc1wiO1xuZnVuY3Rpb24gY291bnRBY3RpdmUgKCkge1xuICByZXR1cm4gMDtcbn1cbmZ1bmN0aW9uIGluc2VydCAodHgpIHtcbiAgY29uc29sZS5sb2coJ2N1c3RvbSBtZXRob2QgOnR4IGluc2VydCBzaW11bGF0ZWQuJyArIHR4LnN0YXR1cyk7XG4gIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gZXhpc3RzICgpIHtcbiAgY29uc29sZS5sb2coJ2N1c3RvbSBtZXRob2QgOnR4IGluc2VydCBzaW11bGF0ZWQuJyk7XG4gIHJldHVybiB0cnVlO1xufVxuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIC8vY29uc29sZS5sb2coQWNjb3VudHMpO1xuICAvL0FjY291bnRzLl9iY3J5cHRSb3VuZHMgPSAxMDtcblxuICBpZiAoTWV0ZW9yLnNldHRpbmdzKSB7XG4gICAgLy9PYmplY3QuYXNzaWduKEFjY291bnRzLl9vcHRpb25zLCBNZXRlb3Iuc2V0dGluZ3NbJ2FjY291bnRzLXBob25lJ10pO1xuICAgIC8vIFNNUy50d2lsaW8gPSBNZXRlb3Iuc2V0dGluZ3NbJ3R3aWxpbyddO1xuICB9XG5cbiAgaWYgKFVzZXJzLmNvbGxlY3Rpb24uZmluZCgpLmNvdW50KCkgPiAwKSB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gICAgdXNlcm5hbWU6IFwianVsaXVzXCIsXG4gICAgZW1haWwgOiBcImp1bGl1c2dpdG9uZ2E1NkBnbWFpbC5jb21cIixcbiAgICBwYXNzd29yZCA6IFwiSm9objJIb21lMlwiLFxuICAgIHByb2ZpbGU6IHtcbiAgICAgIG5hbWUgOiBcIkp1bGl1cyBNdXJ1dGhpXCJcbiAgICB9XG4gIH0pO1xufSk7XG5cbiJdfQ==
