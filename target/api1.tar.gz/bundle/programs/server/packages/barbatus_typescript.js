(function () {



/* Exports */
Package._define("barbatus:typescript");

})();
