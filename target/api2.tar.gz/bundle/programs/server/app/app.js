var require = meteorInstall({"both":{"methods":{"insert":{"invitations.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/methods/insert/invitations.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
  sendInvitation(invitation) {
    check(invitation, {
      email: String,
      role: String
    });

    try {
      Modules.server.sendInvitation({
        email: invitation.email,
        token: Random.hexString(16),
        role: invitation.role,
        date: new Date().toISOString()
      });
    } catch (exception) {
      return exception;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/methods/insert/users.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
  acceptInvitation(user) {
    check(user, {
      email: String,
      password: Object,
      token: String
    });

    try {
      var userId = Modules.server.acceptInvitation(user);
      return userId;
    } catch (exception) {
      return exception;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"read":{"collection.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/methods/read/collection.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
  readMethod(argument) {
    check(argument, String);
    var document = Collection.findOne(argument);

    if (!document) {
      throw new Meteor.Error('document-not-found', 'No documents found matching this query.');
    }

    return document;
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"remove":{"invitations.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/methods/remove/invitations.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
  revokeInvitation(inviteId) {
    check(inviteId, String);

    try {
      Invitations.remove(inviteId);
    } catch (exception) {
      return exception;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"update":{"users.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/methods/update/users.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
  setRoleOnUser(options) {
    check(options, {
      user: String,
      role: String
    });

    try {
      Roles.setUserRoles(options.user, [options.role]);
    } catch (exception) {
      return exception;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"modules":{"_modules.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/modules/_modules.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Modules = {};
Modules.both = {};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"redirect-users.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/modules/redirect-users.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let route = options => {
  return options && options.redirect ? _sendUserToDefault(options.redirect) : _sendUserToDefault();
};

let _sendUserToDefault = redirect => {
  let roles = _getCurrentUserRoles();

  if (roles[0] === 'admin') {
    _redirectUser('users', redirect);
  }

  if (roles[0] === 'manager') {
    _redirectUser('managers', redirect);
  }

  if (roles[0] === 'employee') {
    _redirectUser('employees', redirect);
  }
};

let _getCurrentUserRoles = () => {
  return Roles.getRolesForUser(Meteor.userId());
};

let _redirectUser = (path, redirect) => {
  if (redirect) {
    redirect(path);
  } else {
    FlowRouter.go(FlowRouter.path(path));
  }
};

Modules.both.redirectUser = route;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"startup.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/modules/startup.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let startup = () => {};

Modules.both.startup = startup;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"routes":{"authenticated.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/routes/authenticated.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
const authenticatedRedirect = () => {
  if (!Meteor.loggingIn() && !Meteor.userId()) {
    FlowRouter.go('login');
  }
};

const blockUnauthorizedAdmin = (context, redirect) => {
  if (Meteor.userId() && !Roles.userIsInRole(Meteor.userId(), 'admin')) {
    Modules.both.redirectUser({
      redirect: redirect
    });
  }
};

const blockUnauthorizedManager = (context, redirect) => {
  if (Meteor.userId() && !Roles.userIsInRole(Meteor.userId(), ['admin', 'manager'])) {
    Modules.both.redirectUser({
      redirect: redirect
    });
  }
};

const authenticatedRoutes = FlowRouter.group({
  name: 'authenticated',
  triggersEnter: [authenticatedRedirect]
});
authenticatedRoutes.route('/users', {
  name: 'users',
  triggersEnter: [blockUnauthorizedAdmin],

  action() {
    BlazeLayout.render('default', {
      yield: 'users'
    });
  }

});
authenticatedRoutes.route('/managers', {
  name: 'managers',
  triggersEnter: [blockUnauthorizedManager],

  action() {
    BlazeLayout.render('default', {
      yield: 'managers'
    });
  }

});
authenticatedRoutes.route('/employees', {
  name: 'employees',

  action() {
    BlazeLayout.render('default', {
      yield: 'employees'
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"configure.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/routes/configure.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
FlowRouter.notFound = {
  action() {
    BlazeLayout.render('default', {
      yield: 'notFound'
    });
  }

};
Accounts.onLogin(() => {
  let currentRoute = FlowRouter.current();

  if (currentRoute && currentRoute.route.group.name === 'public') {
    Modules.both.redirectUser();
  }
});

if (Meteor.isClient) {
  Tracker.autorun(() => {
    if (!Meteor.userId() && FlowRouter.current().route) {
      FlowRouter.go('login');
    }
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"public.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/routes/public.js                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
const publicRedirect = (context, redirect) => {
  if (Meteor.userId()) {
    Modules.both.redirectUser({
      redirect: redirect
    });
  }
};

const publicRoutes = FlowRouter.group({
  name: 'public',
  triggersEnter: [publicRedirect]
});
publicRoutes.route('/invite/:token', {
  name: 'invite',

  action() {
    BlazeLayout.render('default', {
      yield: 'invite'
    });
  }

});
publicRoutes.route('/login', {
  name: 'login',

  action() {
    BlazeLayout.render('default', {
      yield: 'login'
    });
  }

});
publicRoutes.route('/recover-password', {
  name: 'recover-password',

  action() {
    BlazeLayout.render('default', {
      yield: 'recoverPassword'
    });
  }

});
publicRoutes.route('/reset-password/:token', {
  name: 'reset-password',

  action() {
    BlazeLayout.render('default', {
      yield: 'resetPassword'
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"startup.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/startup.js                                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(() => Modules.both.startup());
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"course":{"courses.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/course/courses.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.Courses = new meteor_rxjs_1.MongoObservable.Collection('courses');
exports.CourseSubjects = new meteor_rxjs_1.MongoObservable.Collection('course_subjects');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"hivdb":{"index.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/hivdb/index.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var predictions_1 = require("./predictions");
exports.Predictions = predictions_1.Predictions;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"predictions.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/hivdb/predictions.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.Predictions = new meteor_rxjs_1.MongoObservable.Collection('predictions');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactional":{"accounts.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/transactional/accounts.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.TransactionAccounts = new meteor_rxjs_1.MongoObservable.Collection('transaction_accounts');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/transactional/index.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./transactions"));
__export(require("/collections/transactional/accounts"));
__export(require("./references"));

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"references.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/transactional/references.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.TransactionReferences = new meteor_rxjs_1.MongoObservable.Collection('references');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"transactions.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/transactional/transactions.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.Transactions = new meteor_rxjs_1.MongoObservable.Collection('transactions');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"users":{"index.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/users/index.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./users"));
__export(require("./invitations"));

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"invitations.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/users/invitations.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var SimpleSchema_1 = require("simpl-schema/dist/SimpleSchema");
exports.Invitations = new Mongo.Collection('invitations');
exports.Invitations.allow({
    insert: function () { return false; },
    update: function () { return false; },
    remove: function () { return false; }
});
exports.Invitations.deny({
    insert: function () { return true; },
    update: function () { return true; },
    remove: function () { return true; }
});
var InvitationsSchema = new SimpleSchema_1.SimpleSchema({
    email: {
        type: String,
        label: 'Email to send invitation to.'
    },
    token: {
        type: String,
        label: 'Invitation token.'
    },
    role: {
        type: String,
        label: 'Role to apply to the user.'
    },
    date: {
        type: String,
        label: 'Invitation Date'
    }
});
exports.Invitations.attachSchema(InvitationsSchema);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/users/users.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
var meteor_1 = require("meteor/meteor");
meteor_1.Meteor.users.allow({
    insert: function () { return false; },
    update: function () { return false; },
    remove: function () { return false; }
});
meteor_1.Meteor.users.deny({
    insert: function () { return true; },
    update: function () { return true; },
    remove: function () { return true; }
});
exports.Users = meteor_rxjs_1.MongoObservable.fromExisting(meteor_1.Meteor.users);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chats.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/chats.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.Chats = new meteor_rxjs_1.MongoObservable.Collection('chats');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/index.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("/collections/chats"));
__export(require("./messages"));
var courses_1 = require("/collections/course/courses");
exports.Courses = courses_1.Courses;
exports.CourseSubjects = courses_1.CourseSubjects;
__export(require("/collections/transactional/index"));
__export(require("./students"));
var users_1 = require("/collections/users/index");
exports.Users = users_1.Users;
exports.Invitations = users_1.Invitations;
__export(require("/collections/hivdb/index"));

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"messages.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/messages.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.Messages = new meteor_rxjs_1.MongoObservable.Collection('messages');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"students.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// collections/students.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_rxjs_1 = require("meteor-rxjs");
exports.StudentsData = new meteor_rxjs_1.MongoObservable.Collection('studentsData');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"publications":{"chats.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/chats.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor['publishComposite']('chats', function () {
    var _this = this;
    if (!this.userId) {
        return;
    }
    return {
        find: function () {
            return collections_1.Chats.collection.find({ memberIds: _this.userId });
        },
        children: [
            {
                find: function (chat) {
                    return collections_1.Messages.collection.find({ chatId: chat._id }, {
                        sort: { createdAt: -1 },
                        limit: 1
                    });
                }
            },
            {
                find: function (chat) {
                    return collections_1.Users.collection.find({
                        _id: { $in: chat.memberIds }
                    }, {
                        fields: { profile: 1 }
                    });
                }
            }
        ]
    };
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"courses.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/courses.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var alanning_roles_1 = require("meteor/alanning:roles");
var collections_1 = require("../../collections");
Meteor['publishComposite']('courses', function () {
    var _this = this;
    var loggedInUser = Meteor.user();
    if (!this.userId) {
        return;
    }
    if (!loggedInUser) {
        throw new Meteor.Error(403, 'Authentication failed');
    }
    if (!alanning_roles_1.Roles.userIsInRole(loggedInUser, ['tutor', 'manage-courses', 'view-courses', 'admin', 'super-admin'], alanning_roles_1.Roles.GLOBAL_GROUP)) {
        throw new Meteor.Error(403, 'Access denied');
    }
    return {
        find: function () {
            return collections_1.Courses.collection.find({ ownership: _this.userId });
        },
        children: [
            {
                find: function (course) {
                    return collections_1.CourseSubjects.collection.find({ courseId: course._id }, {
                        sort: { createdAt: -1 },
                        limit: 1
                    });
                }
            }
        ]
    };
});
Meteor.publish('subjects', function () {
    var loggedInUser = Meteor.user();
    if (!loggedInUser ||
        !alanning_roles_1.Roles.userIsInRole(loggedInUser, ['tutor', 'manage-courses', 'view-courses', 'admin', 'super-admin'], 'courses')) {
        throw new Meteor.Error(403, 'Access denied');
    }
    return collections_1.CourseSubjects.collection.find({ courseId: loggedInUser._id });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"invite.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/invite.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var invitations_1 = require("../../collections/users/invitations");
Meteor.publish('invite', function (token) {
    check(token, String);
    return invitations_1.Invitations.find({ 'token': token });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"messages.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/messages.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor.publish('messages', function (chatId, messagesBatchCounter) {
    if (!this.userId || !chatId) {
        console.log('Invalid User!!!');
        return;
    }
    return collections_1.Messages.collection.find({
        chatId: chatId
    }, {
        sort: { createdAt: -1 },
        limit: 30 * messagesBatchCounter
    });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"predictions.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/predictions.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor.publish('predictions', function () {
    //Predictions.publish(this, 'total-predictions', Predictions.find());
    return collections_1.Predictions.find({});
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"students.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/students.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor.publish('studentsData', function () {
    return collections_1.StudentsData.collection.find();
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"transactions.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/transactions.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor.publish('transactions', function () {
    return collections_1.Transactions.collection.find({});
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"transactions_accounts.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/transactions_accounts.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Transactional
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor.publish('transaction_accounts', function () {
    return collections_1.TransactionAccounts.collection.find({ ownerId: Meteor.userId() });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/users.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var collections_1 = require("../../collections");
Meteor.publish('users', function () {
    var isAdmin = Roles.userIsInRole(this.userId, ['manage-users', 'admin'], 'users');
    if (isAdmin) {
        return [
            collections_1.Users.find({}, { fields: { 'emails.address': 1, 'roles': 1 } }),
            collections_1.Invitations.find({}, { fields: { 'email': 1, 'role': 1, 'date': 1 } })
        ];
    }
    else {
        return null;
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
///<reference path="../node_modules/@types/meteor-roles/index.d.ts"/>
var collections_1 = require("../collections");
var collections_2 = require("../collections");
var models_1 = require("./models");
var check_1 = require("meteor/check");
var promise_1 = require("meteor/promise");
var nonEmptyString = check_1.Match.Where(function (str) {
    check_1.check(str, String);
    return str.length > 0;
});
var getStanfordURL = "https://hivdb.stanford.edu";
var timeout = 50000;
Meteor.methods({
    addChat: function (receiverId) {
        if (!this.userId) {
            throw new Meteor.Error('unauthorized', 'User must be logged-in to create a new chat');
        }
        check_1.check(receiverId, nonEmptyString);
        if (receiverId === this.userId) {
            throw new Meteor.Error('illegal-receiver', 'Receiver must be different than the current logged in user');
        }
        var chatExists = !!collections_1.Chats.collection.find({
            memberIds: { $all: [this.userId, receiverId] }
        }).count();
        if (chatExists) {
            throw new Meteor.Error('chat-exists', 'Chat already exists');
        }
        var chat = {
            memberIds: [this.userId, receiverId]
        };
        collections_1.Chats.insert(chat);
    },
    signup: function (username, password, email, fname, lname, imsi) {
        check_1.check(username, nonEmptyString);
        check_1.check(password, nonEmptyString);
        check_1.check(email, nonEmptyString);
        check_1.check(fname, nonEmptyString);
        check_1.check(lname, nonEmptyString);
        var user = {
            username: username,
            email: email,
            password: password,
            profile: {
                name: fname + " " + lname
            }
        };
        return Accounts.createUser(user);
    },
    removeChat: function (chatId) {
        if (!this.userId) {
            throw new Meteor.Error('unauthorized', 'User must be logged-in to remove chat');
        }
        check_1.check(chatId, nonEmptyString);
        var chatExists = !!collections_1.Chats.collection.find(chatId).count();
        if (!chatExists) {
            throw new Meteor.Error('chat-not-exists', 'Chat doesn\'t exist');
        }
        collections_1.Chats.remove(chatId);
    },
    updateProfile: function (profile) {
        if (!this.userId) {
            throw new Meteor.Error('unauthorized', 'User must be logged-in to create a new chat');
        }
        check_1.check(profile, {
            name: nonEmptyString
        });
        Meteor.users.update(this.userId, {
            $set: { profile: profile }
        });
    },
    addRoleToUser: function (userId, role, group) {
        if (group) {
            Roles.addUsersToRoles(userId, role, group);
        }
        else {
            Roles.addUsersToRoles(userId, role);
        }
    },
    removeRoleFromUser: function (userId, role, group) {
        if (group) {
            Roles.addUsersToRoles(userId, role, group);
        }
        else {
            Roles.addUsersToRoles(userId, role);
        }
    },
    addCourse: function (courseName, courseDescription) {
        if (!this.userId) {
            throw new Meteor.Error('unauthorized', 'User must be logged-in to create a new course');
        }
        check_1.check(courseName, String);
        check_1.check(courseDescription, String);
        return {
            course: collections_1.Courses.collection.insert({
                name: courseName,
                ownership: this.userId,
                description: courseDescription
            })
        };
    },
    addMessage: function (type, chatId, content) {
        if (!this.userId) {
            throw new Meteor.Error('unauthorized', 'User must be logged-in to create a new chat');
        }
        check_1.check(type, check_1.Match.OneOf(String, [models_1.MessageType.TEXT]));
        check_1.check(chatId, nonEmptyString);
        check_1.check(content, nonEmptyString);
        var chatExists = !!collections_1.Chats.collection.find(chatId).count();
        if (!chatExists) {
            throw new Meteor.Error('chat-not-exists', 'Chat doesn\'t exist');
        }
        return {
            messageId: collections_2.Messages.collection.insert({
                chatId: chatId,
                senderId: this.userId,
                content: content,
                createdAt: new Date(),
                type: type
            })
        };
    },
    countMessages: function () {
        return collections_2.Messages.collection.find().count();
    },
    createSystemUser: function (email, password) {
        Accounts.createUser({ email: password });
    },
    predict: function (body, isSequence) {
        if (!this.userId) {
            throw new Meteor.Error('unauthorized', 'User must be logged-in to create a new request');
        }
        console.log('body', body);
        var bodyFormatted = {};
        var query = {};
        if (isSequence) {
            bodyFormatted = { "sequences": JSON.parse(body.sequences) };
            console.log(bodyFormatted);
            query = {
                operationName: "example",
                query: "query example($sequences: [UnalignedSequenceInput]!) {   viewer {     currentVersion { text, publishDate },     sequenceAnalysis(sequences: $sequences) {         inputSequence {         header,         sequence,         MD5,         SHA512       },       validationResults {         level,         message       },       absoluteFirstNA,       alignedGeneSequences {         gene {           name,           consensus,           length,           drugClasses {             name,             fullName,             drugs {               name,               displayAbbr,               fullName             }           },           mutationTypes         },         firstAA,         lastAA,         firstNA,         lastNA,         matchPcnt,         prettyPairwise {           positionLine,           refAALine,           alignedNAsLine,           mutationLine         },         mutations {           consensus,           position,           AAs,           triplet,           insertedNAs,           isInsertion,           isDeletion,           isIndel,           isAmbiguous,           isApobecMutation,           isApobecDRM,           hasStop,           isUnusual,           types,           primaryType,           comments {             triggeredAAs,             type,             text           },           text,           shortText         },         APOBEC: mutations(filterOptions: [APOBEC]) {           position,           AAs,           text         },         APOBEC_DRM: mutations(filterOptions: [APOBEC_DRM]) {           text         },         DRM: mutations(filterOptions: [DRM]) {           text         },         SDRM: mutations(filterOptions: [SDRM]) {           text         },         unusualMutations: mutations(filterOptions: [UNUSUAL]) {           text         },         treatmentSelectedMutations: mutations(           filterOptions: [PI_TSM, NRTI_TSM, NNRTI_TSM, INSTI_TSM]         ) {           text         },         frameShifts {           position,           isInsertion,           isDeletion,           size,           NAs,           text         }       },       firstTenCloseSubtypes: subtypesV2(first: 10) {         displayWithoutDistance,         distancePcnt,         referenceAccession       },       bestMatchingSubtype { display },       mixturePcnt,       mutations {         position,         AAs,         shortText       },       frameShifts {         text       },       drugResistance {         gene {           name,           consensus,           length,           drugClasses { name },           mutationTypes         },         drugScores {           drugClass {             name,             fullName,             drugs {               name,               displayAbbr,               fullName             }           },           drug { displayAbbr },           SIR,           score,           level,           text,           partialScores {             mutations {               text             },             score           }         },         mutationsByTypes {           mutationType,           mutations {             consensus,             position,             AAs,             triplet,             insertedNAs,             isInsertion,             isDeletion,             isIndel,             isAmbiguous,             isApobecMutation,             isApobecDRM,             hasStop,             isUnusual,             text,             shortText           }         }         commentsByTypes {           commentType,           comments {             type,             text,             highlightText           }         }       }         }   } }",
                variables: bodyFormatted
            };
        }
        else {
            bodyFormatted = { "mutations": JSON.parse(body.mutations) };
            query = {
                query: "query example($mutations:[String]!) {  viewer {    currentVersion { text, publishDate },    mutationsAnalysis(mutations: $mutations) {      validationResults {level,         message       },       drugResistance {         gene { name },         drugScores {           drugClass { name },           drug { name,displayAbbr,fullName},           SIR,           score,           level,           text,           partialScores {             mutations {               text             },             score           }         },         mutationsByTypes {           mutationType,           mutations {             text           }         }         commentsByTypes {           commentType,           comments {             text           }         }       }     }   } }",
                variables: bodyFormatted
            };
        }
        console.log(bodyFormatted);
        console.log(query);
        var theBody = JSON.stringify(query);
        var preditionRequest = {
            requestedBy: this.userId,
            request: theBody,
            response: 'PENDING',
            createdAt: new Date()
        };
        var predictionId = collections_1.Predictions.collection.insert(preditionRequest);
        console.log('Save Prediction ' + predictionId);
        console.log('Sending ' + theBody);
        var options = {
            host: getStanfordURL,
            path: '/graphql',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        };
        var fetch = require('node-fetch');
        var theResponse = '';
        promise_1.Promise.await(theResponse = fetch(options.host + options.path, {
            method: options.method,
            headers: { 'Content-Type': 'application/json' },
            body: theBody
        })
            .then(function (response) { return response.json(); })
            .then(function (response) { return response.data.viewer; })
            .then(function (response) {
            //update response
            collections_1.Predictions.collection.update(predictionId, { $set: { response: JSON.stringify(response) } });
            return response;
        })
            .catch(function (err) {
            return err;
        }));
        console.log(theResponse);
        return theResponse;
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"models.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/models.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_PICTURE_URL = '/assets/default-profile-pic.svg';
var MessageType;
(function (MessageType) {
    MessageType[MessageType["TEXT"] = 'text'] = "TEXT";
    MessageType[MessageType["LOCATION"] = 'location'] = "LOCATION";
    MessageType[MessageType["PICTURE"] = 'picture'] = "PICTURE";
})(MessageType = exports.MessageType || (exports.MessageType = {}));
var QuestionType;
(function (QuestionType) {
    QuestionType["OPEN_ENDED"] = "OPEN_ENDED";
    QuestionType["MULTIPLE_CHOICE"] = "MULTIPLE_CHOICE";
    QuestionType["BROKEN_PASSAGE"] = "BROKEN_PASSAGE";
    QuestionType["MATCHING"] = "MATCHING";
})(QuestionType = exports.QuestionType || (exports.QuestionType = {}));
var RolesEnum;
(function (RolesEnum) {
    RolesEnum["ADMIN"] = "ADMIN";
    RolesEnum["SUPER_ADMIN"] = "SUPER_ADMIN";
    RolesEnum["TUTOR"] = "TUTOR";
    RolesEnum["STUDENT"] = "STUDENT";
    RolesEnum["PARENT"] = "PARENT";
})(RolesEnum = exports.RolesEnum || (exports.RolesEnum = {}));
var ActionPermissionsEnum;
(function (ActionPermissionsEnum) {
    ActionPermissionsEnum["CREATE"] = "CREATE";
    ActionPermissionsEnum["VIEW"] = "VIEW";
    ActionPermissionsEnum["UPDATE"] = "UPDATE";
    ActionPermissionsEnum["DELETE"] = "DELETE";
})(ActionPermissionsEnum = exports.ActionPermissionsEnum || (exports.ActionPermissionsEnum = {}));
var TransactionType;
(function (TransactionType) {
    TransactionType["BALANCE_INQUIRY"] = "BALANCE_INQUIRY";
    TransactionType["FUNDS_TRANSFER"] = "FUNDS_TRANSFER";
})(TransactionType = exports.TransactionType || (exports.TransactionType = {}));
var TransactionDirection;
(function (TransactionDirection) {
    TransactionDirection["FORWARD"] = "FORWARD";
    TransactionDirection["REVERSAL"] = "REVERSAL";
})(TransactionDirection = exports.TransactionDirection || (exports.TransactionDirection = {}));
var TransactionStatus;
(function (TransactionStatus) {
    TransactionStatus["POSTED"] = "POSTED";
    TransactionStatus["PROCESSING"] = "PROCESSING";
    TransactionStatus["PROCESSED"] = "PROCESSED";
    TransactionStatus["FAILED"] = "FAILED";
})(TransactionStatus = exports.TransactionStatus || (exports.TransactionStatus = {}));

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
// Listen to incoming HTTP requests (can only be used on the server).
var webapp_1 = require("meteor/webapp");
var collections_1 = require("../collections");
var hivdb_1 = require("../collections/hivdb");
var ros_publish_counts_1 = require("meteor/ros:publish-counts");
Meteor.publish('predictions.count', function (_a) {
    ros_publish_counts_1.Counts.publish(this, 'predictions.count', hivdb_1.Predictions.find());
});
webapp_1.WebApp.connectHandlers.use('/hello', function (req, res, next) {
    res.writeHead(200);
    res.end("Hello world from: " + Meteor.release);
}).use('/courses', function (req, res, next) {
    res.writeHead(200);
    res.end(JSON.stringify(collections_1.Courses.collection.find({}).fetch()));
}).use('/courses/id', function (req, res, next) {
    res.writeHead(200);
    res.end(JSON.stringify(collections_1.Courses.collection.findOne({})));
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Object.defineProperty(exports, "__esModule", { value: true });
var meteor_1 = require("meteor/meteor");
var users_1 = require("../collections/users");
function countActive() {
    return 0;
}
function insert(tx) {
    console.log('custom method :tx insert simulated.' + tx.status);
    return true;
}
function exists() {
    console.log('custom method :tx insert simulated.');
    return true;
}
meteor_1.Meteor.startup(function () {
    //console.log(Accounts);
    //Accounts._bcryptRounds = 10;
    if (meteor_1.Meteor.settings) {
        //Object.assign(Accounts._options, Meteor.settings['accounts-phone']);
        // SMS.twilio = Meteor.settings['twilio'];
    }
    if (users_1.Users.collection.find().count() > 0) {
        return;
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts"
  ]
});

require("/both/methods/insert/invitations.js");
require("/both/methods/insert/users.js");
require("/both/methods/read/collection.js");
require("/both/methods/remove/invitations.js");
require("/both/methods/update/users.js");
require("/both/modules/_modules.js");
require("/both/modules/redirect-users.js");
require("/both/modules/startup.js");
require("/both/routes/authenticated.js");
require("/both/routes/configure.js");
require("/both/routes/public.js");
require("/collections/course/courses.js");
require("/collections/hivdb/index.js");
require("/collections/hivdb/predictions.js");
require("/collections/transactional/accounts.js");
require("/collections/transactional/index.js");
require("/collections/transactional/references.js");
require("/collections/transactional/transactions.js");
require("/collections/users/index.js");
require("/collections/users/invitations.js");
require("/collections/users/users.js");
require("/server/publications/chats.js");
require("/server/publications/courses.js");
require("/server/publications/invite.js");
require("/server/publications/messages.js");
require("/server/publications/predictions.js");
require("/server/publications/students.js");
require("/server/publications/transactions.js");
require("/server/publications/transactions_accounts.js");
require("/server/publications/users.js");
require("/both/startup.js");
require("/collections/chats.js");
require("/collections/index.js");
require("/collections/messages.js");
require("/collections/students.js");
require("/server/methods.js");
require("/server/models.js");
require("/server/publications.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvYm90aC9tZXRob2RzL2luc2VydC9pbnZpdGF0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9tZXRob2RzL2luc2VydC91c2Vycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9tZXRob2RzL3JlYWQvY29sbGVjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9tZXRob2RzL3JlbW92ZS9pbnZpdGF0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9tZXRob2RzL3VwZGF0ZS91c2Vycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9tb2R1bGVzL19tb2R1bGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9ib3RoL21vZHVsZXMvcmVkaXJlY3QtdXNlcnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvbW9kdWxlcy9zdGFydHVwLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9ib3RoL3JvdXRlcy9hdXRoZW50aWNhdGVkLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9ib3RoL3JvdXRlcy9jb25maWd1cmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvcm91dGVzL3B1YmxpYy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9zdGFydHVwLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy9jb3Vyc2UvY291cnNlcy50cyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvaGl2ZGIvaW5kZXgudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL2NvbGxlY3Rpb25zL2hpdmRiL3ByZWRpY3Rpb25zLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy90cmFuc2FjdGlvbmFsL2FjY291bnRzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy90cmFuc2FjdGlvbmFsL2luZGV4LnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy90cmFuc2FjdGlvbmFsL3JlZmVyZW5jZXMudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL2NvbGxlY3Rpb25zL3RyYW5zYWN0aW9uYWwvdHJhbnNhY3Rpb25zLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy91c2Vycy9pbmRleC50cyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvdXNlcnMvaW52aXRhdGlvbnMudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL2NvbGxlY3Rpb25zL3VzZXJzL3VzZXJzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy9jaGF0cy50cyIsIm1ldGVvcjovL/CfkrthcHAvY29sbGVjdGlvbnMvaW5kZXgudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL2NvbGxlY3Rpb25zL21lc3NhZ2VzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9jb2xsZWN0aW9ucy9zdHVkZW50cy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy9jaGF0cy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy9jb3Vyc2VzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcHVibGljYXRpb25zL2ludml0ZS50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy9tZXNzYWdlcy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy9wcmVkaWN0aW9ucy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy9zdHVkZW50cy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy90cmFuc2FjdGlvbnMudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wdWJsaWNhdGlvbnMvdHJhbnNhY3Rpb25zX2FjY291bnRzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcHVibGljYXRpb25zL3VzZXJzLnRzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kcy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21vZGVscy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy50cyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4udHMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibWV0aG9kcyIsInNlbmRJbnZpdGF0aW9uIiwiaW52aXRhdGlvbiIsImNoZWNrIiwiZW1haWwiLCJTdHJpbmciLCJyb2xlIiwiTW9kdWxlcyIsInNlcnZlciIsInRva2VuIiwiUmFuZG9tIiwiaGV4U3RyaW5nIiwiZGF0ZSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsImV4Y2VwdGlvbiIsImFjY2VwdEludml0YXRpb24iLCJ1c2VyIiwicGFzc3dvcmQiLCJPYmplY3QiLCJ1c2VySWQiLCJyZWFkTWV0aG9kIiwiYXJndW1lbnQiLCJkb2N1bWVudCIsIkNvbGxlY3Rpb24iLCJmaW5kT25lIiwiRXJyb3IiLCJyZXZva2VJbnZpdGF0aW9uIiwiaW52aXRlSWQiLCJJbnZpdGF0aW9ucyIsInJlbW92ZSIsInNldFJvbGVPblVzZXIiLCJvcHRpb25zIiwiUm9sZXMiLCJzZXRVc2VyUm9sZXMiLCJib3RoIiwicm91dGUiLCJyZWRpcmVjdCIsIl9zZW5kVXNlclRvRGVmYXVsdCIsInJvbGVzIiwiX2dldEN1cnJlbnRVc2VyUm9sZXMiLCJfcmVkaXJlY3RVc2VyIiwiZ2V0Um9sZXNGb3JVc2VyIiwicGF0aCIsIkZsb3dSb3V0ZXIiLCJnbyIsInJlZGlyZWN0VXNlciIsInN0YXJ0dXAiLCJhdXRoZW50aWNhdGVkUmVkaXJlY3QiLCJsb2dnaW5nSW4iLCJibG9ja1VuYXV0aG9yaXplZEFkbWluIiwiY29udGV4dCIsInVzZXJJc0luUm9sZSIsImJsb2NrVW5hdXRob3JpemVkTWFuYWdlciIsImF1dGhlbnRpY2F0ZWRSb3V0ZXMiLCJncm91cCIsIm5hbWUiLCJ0cmlnZ2Vyc0VudGVyIiwiYWN0aW9uIiwiQmxhemVMYXlvdXQiLCJyZW5kZXIiLCJ5aWVsZCIsIm5vdEZvdW5kIiwiQWNjb3VudHMiLCJvbkxvZ2luIiwiY3VycmVudFJvdXRlIiwiY3VycmVudCIsImlzQ2xpZW50IiwiVHJhY2tlciIsImF1dG9ydW4iLCJwdWJsaWNSZWRpcmVjdCIsInB1YmxpY1JvdXRlcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxPQUFQLENBQWU7QUFDYkMsZ0JBQWMsQ0FBRUMsVUFBRixFQUFlO0FBQzNCQyxTQUFLLENBQUVELFVBQUYsRUFBYztBQUNqQkUsV0FBSyxFQUFFQyxNQURVO0FBRWpCQyxVQUFJLEVBQUVEO0FBRlcsS0FBZCxDQUFMOztBQUtBLFFBQUk7QUFDRkUsYUFBTyxDQUFDQyxNQUFSLENBQWVQLGNBQWYsQ0FBOEI7QUFDNUJHLGFBQUssRUFBRUYsVUFBVSxDQUFDRSxLQURVO0FBRTVCSyxhQUFLLEVBQUVDLE1BQU0sQ0FBQ0MsU0FBUCxDQUFrQixFQUFsQixDQUZxQjtBQUc1QkwsWUFBSSxFQUFFSixVQUFVLENBQUNJLElBSFc7QUFJNUJNLFlBQUksRUFBSSxJQUFJQyxJQUFKLEVBQUYsQ0FBZUMsV0FBZjtBQUpzQixPQUE5QjtBQU1ELEtBUEQsQ0FPRSxPQUFPQyxTQUFQLEVBQW1CO0FBQ25CLGFBQU9BLFNBQVA7QUFDRDtBQUNGOztBQWpCWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQUFoQixNQUFNLENBQUNDLE9BQVAsQ0FBZTtBQUNiZ0Isa0JBQWdCLENBQUVDLElBQUYsRUFBUztBQUN2QmQsU0FBSyxDQUFFYyxJQUFGLEVBQVE7QUFDWGIsV0FBSyxFQUFFQyxNQURJO0FBRVhhLGNBQVEsRUFBRUMsTUFGQztBQUdYVixXQUFLLEVBQUVKO0FBSEksS0FBUixDQUFMOztBQU1BLFFBQUk7QUFDRixVQUFJZSxNQUFNLEdBQUdiLE9BQU8sQ0FBQ0MsTUFBUixDQUFlUSxnQkFBZixDQUFpQ0MsSUFBakMsQ0FBYjtBQUNBLGFBQU9HLE1BQVA7QUFDRCxLQUhELENBR0UsT0FBT0wsU0FBUCxFQUFtQjtBQUNuQixhQUFPQSxTQUFQO0FBQ0Q7QUFDRjs7QUFkWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQUFoQixNQUFNLENBQUNDLE9BQVAsQ0FBZTtBQUNicUIsWUFBVSxDQUFFQyxRQUFGLEVBQWE7QUFDckJuQixTQUFLLENBQUVtQixRQUFGLEVBQVlqQixNQUFaLENBQUw7QUFFQSxRQUFJa0IsUUFBUSxHQUFHQyxVQUFVLENBQUNDLE9BQVgsQ0FBb0JILFFBQXBCLENBQWY7O0FBRUEsUUFBSyxDQUFDQyxRQUFOLEVBQWlCO0FBQ2YsWUFBTSxJQUFJeEIsTUFBTSxDQUFDMkIsS0FBWCxDQUFrQixvQkFBbEIsRUFBd0MseUNBQXhDLENBQU47QUFDRDs7QUFFRCxXQUFPSCxRQUFQO0FBQ0Q7O0FBWFksQ0FBZixFOzs7Ozs7Ozs7OztBQ0FBeEIsTUFBTSxDQUFDQyxPQUFQLENBQWU7QUFDYjJCLGtCQUFnQixDQUFFQyxRQUFGLEVBQWE7QUFDM0J6QixTQUFLLENBQUV5QixRQUFGLEVBQVl2QixNQUFaLENBQUw7O0FBRUEsUUFBSTtBQUNGd0IsaUJBQVcsQ0FBQ0MsTUFBWixDQUFvQkYsUUFBcEI7QUFDRCxLQUZELENBRUUsT0FBT2IsU0FBUCxFQUFtQjtBQUNuQixhQUFPQSxTQUFQO0FBQ0Q7QUFDRjs7QUFUWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQUFoQixNQUFNLENBQUNDLE9BQVAsQ0FBZTtBQUNiK0IsZUFBYSxDQUFFQyxPQUFGLEVBQVk7QUFDdkI3QixTQUFLLENBQUU2QixPQUFGLEVBQVc7QUFDZGYsVUFBSSxFQUFFWixNQURRO0FBRWRDLFVBQUksRUFBRUQ7QUFGUSxLQUFYLENBQUw7O0FBS0EsUUFBSTtBQUNGNEIsV0FBSyxDQUFDQyxZQUFOLENBQW9CRixPQUFPLENBQUNmLElBQTVCLEVBQWtDLENBQUVlLE9BQU8sQ0FBQzFCLElBQVYsQ0FBbEM7QUFDRCxLQUZELENBRUUsT0FBT1MsU0FBUCxFQUFtQjtBQUNuQixhQUFPQSxTQUFQO0FBQ0Q7QUFDRjs7QUFaWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQUFSLE9BQU8sR0FBUSxFQUFmO0FBQ0FBLE9BQU8sQ0FBQzRCLElBQVIsR0FBZSxFQUFmLEM7Ozs7Ozs7Ozs7O0FDREEsSUFBSUMsS0FBSyxHQUFLSixPQUFGLElBQWU7QUFDekIsU0FBT0EsT0FBTyxJQUFJQSxPQUFPLENBQUNLLFFBQW5CLEdBQThCQyxrQkFBa0IsQ0FBRU4sT0FBTyxDQUFDSyxRQUFWLENBQWhELEdBQXVFQyxrQkFBa0IsRUFBaEc7QUFDRCxDQUZEOztBQUlBLElBQUlBLGtCQUFrQixHQUFLRCxRQUFGLElBQWdCO0FBQ3ZDLE1BQUlFLEtBQUssR0FBR0Msb0JBQW9CLEVBQWhDOztBQUVBLE1BQUtELEtBQUssQ0FBQyxDQUFELENBQUwsS0FBYSxPQUFsQixFQUErQjtBQUM3QkUsaUJBQWEsQ0FBRSxPQUFGLEVBQVdKLFFBQVgsQ0FBYjtBQUNEOztBQUVELE1BQUtFLEtBQUssQ0FBQyxDQUFELENBQUwsS0FBYSxTQUFsQixFQUErQjtBQUM3QkUsaUJBQWEsQ0FBRSxVQUFGLEVBQWNKLFFBQWQsQ0FBYjtBQUNEOztBQUVELE1BQUtFLEtBQUssQ0FBQyxDQUFELENBQUwsS0FBYSxVQUFsQixFQUErQjtBQUM3QkUsaUJBQWEsQ0FBRSxXQUFGLEVBQWVKLFFBQWYsQ0FBYjtBQUNEO0FBQ0YsQ0FkRDs7QUFnQkEsSUFBSUcsb0JBQW9CLEdBQUcsTUFBTTtBQUMvQixTQUFPUCxLQUFLLENBQUNTLGVBQU4sQ0FBdUIzQyxNQUFNLENBQUNxQixNQUFQLEVBQXZCLENBQVA7QUFDRCxDQUZEOztBQUlBLElBQUlxQixhQUFhLEdBQUcsQ0FBRUUsSUFBRixFQUFRTixRQUFSLEtBQXNCO0FBQ3hDLE1BQUtBLFFBQUwsRUFBZ0I7QUFDZEEsWUFBUSxDQUFFTSxJQUFGLENBQVI7QUFDRCxHQUZELE1BRU87QUFDTEMsY0FBVSxDQUFDQyxFQUFYLENBQWVELFVBQVUsQ0FBQ0QsSUFBWCxDQUFpQkEsSUFBakIsQ0FBZjtBQUNEO0FBQ0YsQ0FORDs7QUFRQXBDLE9BQU8sQ0FBQzRCLElBQVIsQ0FBYVcsWUFBYixHQUE0QlYsS0FBNUIsQzs7Ozs7Ozs7Ozs7QUNoQ0EsSUFBSVcsT0FBTyxHQUFHLE1BQU0sQ0FBRSxDQUF0Qjs7QUFFQXhDLE9BQU8sQ0FBQzRCLElBQVIsQ0FBYVksT0FBYixHQUF1QkEsT0FBdkIsQzs7Ozs7Ozs7Ozs7QUNGQSxNQUFNQyxxQkFBcUIsR0FBRyxNQUFNO0FBQ2xDLE1BQUssQ0FBQ2pELE1BQU0sQ0FBQ2tELFNBQVAsRUFBRCxJQUF1QixDQUFDbEQsTUFBTSxDQUFDcUIsTUFBUCxFQUE3QixFQUErQztBQUM3Q3dCLGNBQVUsQ0FBQ0MsRUFBWCxDQUFlLE9BQWY7QUFDRDtBQUNGLENBSkQ7O0FBTUEsTUFBTUssc0JBQXNCLEdBQUcsQ0FBRUMsT0FBRixFQUFXZCxRQUFYLEtBQXlCO0FBQ3RELE1BQUt0QyxNQUFNLENBQUNxQixNQUFQLE1BQW1CLENBQUNhLEtBQUssQ0FBQ21CLFlBQU4sQ0FBb0JyRCxNQUFNLENBQUNxQixNQUFQLEVBQXBCLEVBQXFDLE9BQXJDLENBQXpCLEVBQTBFO0FBQ3hFYixXQUFPLENBQUM0QixJQUFSLENBQWFXLFlBQWIsQ0FBMkI7QUFBRVQsY0FBUSxFQUFFQTtBQUFaLEtBQTNCO0FBQ0Q7QUFDRixDQUpEOztBQU1BLE1BQU1nQix3QkFBd0IsR0FBRyxDQUFFRixPQUFGLEVBQVdkLFFBQVgsS0FBeUI7QUFDeEQsTUFBS3RDLE1BQU0sQ0FBQ3FCLE1BQVAsTUFBbUIsQ0FBQ2EsS0FBSyxDQUFDbUIsWUFBTixDQUFvQnJELE1BQU0sQ0FBQ3FCLE1BQVAsRUFBcEIsRUFBcUMsQ0FBRSxPQUFGLEVBQVcsU0FBWCxDQUFyQyxDQUF6QixFQUF5RjtBQUN2RmIsV0FBTyxDQUFDNEIsSUFBUixDQUFhVyxZQUFiLENBQTJCO0FBQUVULGNBQVEsRUFBRUE7QUFBWixLQUEzQjtBQUNEO0FBQ0YsQ0FKRDs7QUFNQSxNQUFNaUIsbUJBQW1CLEdBQUdWLFVBQVUsQ0FBQ1csS0FBWCxDQUFpQjtBQUMzQ0MsTUFBSSxFQUFFLGVBRHFDO0FBRTNDQyxlQUFhLEVBQUUsQ0FBRVQscUJBQUY7QUFGNEIsQ0FBakIsQ0FBNUI7QUFLQU0sbUJBQW1CLENBQUNsQixLQUFwQixDQUEyQixRQUEzQixFQUFxQztBQUNuQ29CLE1BQUksRUFBRSxPQUQ2QjtBQUVuQ0MsZUFBYSxFQUFFLENBQUVQLHNCQUFGLENBRm9COztBQUduQ1EsUUFBTSxHQUFHO0FBQ1BDLGVBQVcsQ0FBQ0MsTUFBWixDQUFvQixTQUFwQixFQUErQjtBQUFFQyxXQUFLLEVBQUU7QUFBVCxLQUEvQjtBQUNEOztBQUxrQyxDQUFyQztBQVFBUCxtQkFBbUIsQ0FBQ2xCLEtBQXBCLENBQTJCLFdBQTNCLEVBQXdDO0FBQ3RDb0IsTUFBSSxFQUFFLFVBRGdDO0FBRXRDQyxlQUFhLEVBQUUsQ0FBRUosd0JBQUYsQ0FGdUI7O0FBR3RDSyxRQUFNLEdBQUc7QUFDUEMsZUFBVyxDQUFDQyxNQUFaLENBQW9CLFNBQXBCLEVBQStCO0FBQUVDLFdBQUssRUFBRTtBQUFULEtBQS9CO0FBQ0Q7O0FBTHFDLENBQXhDO0FBUUFQLG1CQUFtQixDQUFDbEIsS0FBcEIsQ0FBMkIsWUFBM0IsRUFBeUM7QUFDdkNvQixNQUFJLEVBQUUsV0FEaUM7O0FBRXZDRSxRQUFNLEdBQUc7QUFDUEMsZUFBVyxDQUFDQyxNQUFaLENBQW9CLFNBQXBCLEVBQStCO0FBQUVDLFdBQUssRUFBRTtBQUFULEtBQS9CO0FBQ0Q7O0FBSnNDLENBQXpDLEU7Ozs7Ozs7Ozs7O0FDdkNBakIsVUFBVSxDQUFDa0IsUUFBWCxHQUFzQjtBQUNwQkosUUFBTSxHQUFHO0FBQ1BDLGVBQVcsQ0FBQ0MsTUFBWixDQUFvQixTQUFwQixFQUErQjtBQUFFQyxXQUFLLEVBQUU7QUFBVCxLQUEvQjtBQUNEOztBQUhtQixDQUF0QjtBQU1BRSxRQUFRLENBQUNDLE9BQVQsQ0FBa0IsTUFBTTtBQUN0QixNQUFJQyxZQUFZLEdBQUdyQixVQUFVLENBQUNzQixPQUFYLEVBQW5COztBQUNBLE1BQUtELFlBQVksSUFBSUEsWUFBWSxDQUFDN0IsS0FBYixDQUFtQm1CLEtBQW5CLENBQXlCQyxJQUF6QixLQUFrQyxRQUF2RCxFQUFrRTtBQUNoRWpELFdBQU8sQ0FBQzRCLElBQVIsQ0FBYVcsWUFBYjtBQUNEO0FBQ0YsQ0FMRDs7QUFPQSxJQUFLL0MsTUFBTSxDQUFDb0UsUUFBWixFQUF1QjtBQUNyQkMsU0FBTyxDQUFDQyxPQUFSLENBQWlCLE1BQU07QUFDckIsUUFBSyxDQUFDdEUsTUFBTSxDQUFDcUIsTUFBUCxFQUFELElBQW9Cd0IsVUFBVSxDQUFDc0IsT0FBWCxHQUFxQjlCLEtBQTlDLEVBQXNEO0FBQ3BEUSxnQkFBVSxDQUFDQyxFQUFYLENBQWUsT0FBZjtBQUNEO0FBQ0YsR0FKRDtBQUtELEM7Ozs7Ozs7Ozs7O0FDbkJELE1BQU15QixjQUFjLEdBQUcsQ0FBRW5CLE9BQUYsRUFBV2QsUUFBWCxLQUF5QjtBQUM5QyxNQUFLdEMsTUFBTSxDQUFDcUIsTUFBUCxFQUFMLEVBQXVCO0FBQ3JCYixXQUFPLENBQUM0QixJQUFSLENBQWFXLFlBQWIsQ0FBMkI7QUFBRVQsY0FBUSxFQUFFQTtBQUFaLEtBQTNCO0FBQ0Q7QUFDRixDQUpEOztBQU1BLE1BQU1rQyxZQUFZLEdBQUczQixVQUFVLENBQUNXLEtBQVgsQ0FBaUI7QUFDcENDLE1BQUksRUFBRSxRQUQ4QjtBQUVwQ0MsZUFBYSxFQUFFLENBQUVhLGNBQUY7QUFGcUIsQ0FBakIsQ0FBckI7QUFLQUMsWUFBWSxDQUFDbkMsS0FBYixDQUFvQixnQkFBcEIsRUFBc0M7QUFDcENvQixNQUFJLEVBQUUsUUFEOEI7O0FBRXBDRSxRQUFNLEdBQUc7QUFDUEMsZUFBVyxDQUFDQyxNQUFaLENBQW9CLFNBQXBCLEVBQStCO0FBQUVDLFdBQUssRUFBRTtBQUFULEtBQS9CO0FBQ0Q7O0FBSm1DLENBQXRDO0FBT0FVLFlBQVksQ0FBQ25DLEtBQWIsQ0FBb0IsUUFBcEIsRUFBOEI7QUFDNUJvQixNQUFJLEVBQUUsT0FEc0I7O0FBRTVCRSxRQUFNLEdBQUc7QUFDUEMsZUFBVyxDQUFDQyxNQUFaLENBQW9CLFNBQXBCLEVBQStCO0FBQUVDLFdBQUssRUFBRTtBQUFULEtBQS9CO0FBQ0Q7O0FBSjJCLENBQTlCO0FBT0FVLFlBQVksQ0FBQ25DLEtBQWIsQ0FBb0IsbUJBQXBCLEVBQXlDO0FBQ3ZDb0IsTUFBSSxFQUFFLGtCQURpQzs7QUFFdkNFLFFBQU0sR0FBRztBQUNQQyxlQUFXLENBQUNDLE1BQVosQ0FBb0IsU0FBcEIsRUFBK0I7QUFBRUMsV0FBSyxFQUFFO0FBQVQsS0FBL0I7QUFDRDs7QUFKc0MsQ0FBekM7QUFPQVUsWUFBWSxDQUFDbkMsS0FBYixDQUFvQix3QkFBcEIsRUFBOEM7QUFDNUNvQixNQUFJLEVBQUUsZ0JBRHNDOztBQUU1Q0UsUUFBTSxHQUFHO0FBQ1BDLGVBQVcsQ0FBQ0MsTUFBWixDQUFvQixTQUFwQixFQUErQjtBQUFFQyxXQUFLLEVBQUU7QUFBVCxLQUEvQjtBQUNEOztBQUoyQyxDQUE5QyxFOzs7Ozs7Ozs7OztBQ2hDQTlELE1BQU0sQ0FBQ2dELE9BQVAsQ0FBZ0IsTUFBTXhDLE9BQU8sQ0FBQzRCLElBQVIsQ0FBYVksT0FBYixFQUF0QixFOzs7Ozs7Ozs7Ozs7QUNBQSwyQ0FBOEM7QUFHakMsZUFBTyxHQUFHLElBQUksNkJBQWUsQ0FBQyxVQUFVLENBQVMsU0FBUyxDQUFDLENBQUM7QUFDNUQsc0JBQWMsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFnQixpQkFBaUIsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FDSi9GLDZDQUE0QztBQUFuQywrQ0FBVzs7Ozs7Ozs7Ozs7OztBQ0FwQiwyQ0FBOEM7QUFHakMsbUJBQVcsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFZLGFBQWEsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FDSHBGLDJDQUE4QztBQUdqQywyQkFBbUIsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFxQixzQkFBc0IsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7O0FDSDlHLG9DQUErQjtBQUMvQix3REFBMkI7QUFDM0Isa0NBQTZCOzs7Ozs7Ozs7Ozs7O0FDRjdCLDJDQUE4QztBQUdqQyw2QkFBcUIsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUF1QixZQUFZLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ0h4RywyQ0FBOEM7QUFHakMsb0JBQVksR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFjLGNBQWMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7O0FDSHhGLDZCQUF3QjtBQUN4QixtQ0FBOEI7Ozs7Ozs7Ozs7Ozs7QUNEOUIsK0RBQTREO0FBRS9DLG1CQUFXLEdBQVEsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFFLGFBQWEsQ0FBRSxDQUFDO0FBRXRFLG1CQUFXLENBQUMsS0FBSyxDQUFDO0lBQ2hCLE1BQU0sRUFBRSxjQUFNLFlBQUssRUFBTCxDQUFLO0lBQ25CLE1BQU0sRUFBRSxjQUFNLFlBQUssRUFBTCxDQUFLO0lBQ25CLE1BQU0sRUFBRSxjQUFNLFlBQUssRUFBTCxDQUFLO0NBQ3BCLENBQUMsQ0FBQztBQUVILG1CQUFXLENBQUMsSUFBSSxDQUFDO0lBQ2YsTUFBTSxFQUFFLGNBQU0sV0FBSSxFQUFKLENBQUk7SUFDbEIsTUFBTSxFQUFFLGNBQU0sV0FBSSxFQUFKLENBQUk7SUFDbEIsTUFBTSxFQUFFLGNBQU0sV0FBSSxFQUFKLENBQUk7Q0FDbkIsQ0FBQyxDQUFDO0FBRUgsSUFBTSxpQkFBaUIsR0FBRyxJQUFJLDJCQUFZLENBQUM7SUFDekMsS0FBSyxFQUFFO1FBQ0wsSUFBSSxFQUFFLE1BQU07UUFDWixLQUFLLEVBQUUsOEJBQThCO0tBQ3RDO0lBQ0QsS0FBSyxFQUFFO1FBQ0wsSUFBSSxFQUFFLE1BQU07UUFDWixLQUFLLEVBQUUsbUJBQW1CO0tBQzNCO0lBQ0QsSUFBSSxFQUFFO1FBQ0osSUFBSSxFQUFFLE1BQU07UUFDWixLQUFLLEVBQUUsNEJBQTRCO0tBQ3BDO0lBQ0QsSUFBSSxFQUFFO1FBQ0osSUFBSSxFQUFFLE1BQU07UUFDWixLQUFLLEVBQUUsaUJBQWlCO0tBQ3pCO0NBQ0YsQ0FBQyxDQUFDO0FBRUgsbUJBQVcsQ0FBQyxZQUFZLENBQUUsaUJBQWlCLENBQUUsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ25DOUMsMkNBQThDO0FBQzlDLHdDQUF1QztBQUd2QyxlQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztJQUNqQixNQUFNLEVBQUUsY0FBTSxZQUFLLEVBQUwsQ0FBSztJQUNuQixNQUFNLEVBQUUsY0FBTSxZQUFLLEVBQUwsQ0FBSztJQUNuQixNQUFNLEVBQUUsY0FBTSxZQUFLLEVBQUwsQ0FBSztDQUNwQixDQUFDLENBQUM7QUFFSCxlQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztJQUNoQixNQUFNLEVBQUUsY0FBTSxXQUFJLEVBQUosQ0FBSTtJQUNsQixNQUFNLEVBQUUsY0FBTSxXQUFJLEVBQUosQ0FBSTtJQUNsQixNQUFNLEVBQUUsY0FBTSxXQUFJLEVBQUosQ0FBSTtDQUNuQixDQUFDLENBQUM7QUFFVSxhQUFLLEdBQUcsNkJBQWUsQ0FBQyxZQUFZLENBQU8sZUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FDaEJ0RSwyQ0FBOEM7QUFHakMsYUFBSyxHQUFHLElBQUksNkJBQWUsQ0FBQyxVQUFVLENBQU8sT0FBTyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNIbkUsdUNBQXdCO0FBQ3hCLGdDQUEyQjtBQUMzQixzREFBeUQ7QUFBakQsbUNBQU87QUFBRSxpREFBYztBQUMvQixxREFBc0M7QUFDdEMsZ0NBQTJCO0FBRzNCLGlEQUEyQztBQUFuQyw2QkFBSztBQUFFLHlDQUFXO0FBQzFCLDZDQUF3Qjs7Ozs7Ozs7Ozs7OztBQ1J4QiwyQ0FBOEM7QUFHakMsZ0JBQVEsR0FBRyxJQUFJLDZCQUFlLENBQUMsVUFBVSxDQUFVLFVBQVUsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FDSDVFLDJDQUE4QztBQUdqQyxvQkFBWSxHQUFHLElBQUksNkJBQWUsQ0FBQyxVQUFVLENBQWMsY0FBYyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUNGeEYsaURBQXlEO0FBR3pELE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sRUFBRTtJQUFBLGlCQThCbkM7SUE3QkMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7UUFDaEIsT0FBTztLQUNSO0lBRUQsT0FBTztRQUNMLElBQUksRUFBRTtZQUNKLE9BQU8sbUJBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQzNELENBQUM7UUFFRCxRQUFRLEVBQUU7WUFDaUM7Z0JBQ3ZDLElBQUksRUFBRSxVQUFDLElBQUk7b0JBQ1QsT0FBTyxzQkFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO3dCQUNwRCxJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUU7d0JBQ3ZCLEtBQUssRUFBRSxDQUFDO3FCQUNULENBQUMsQ0FBQztnQkFDTCxDQUFDO2FBQ0Y7WUFDcUM7Z0JBQ3BDLElBQUksRUFBRSxVQUFDLElBQUk7b0JBQ1QsT0FBTyxtQkFBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7d0JBQzNCLEdBQUcsRUFBRSxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFO3FCQUM3QixFQUFFO3dCQUNELE1BQU0sRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7cUJBQ3ZCLENBQUMsQ0FBQztnQkFDTCxDQUFDO2FBQ0Y7U0FDRjtLQUNGLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ2xDSCx3REFBNEM7QUFDNUMsaURBQTJFO0FBRzNFLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLFNBQVMsRUFBRTtJQUFBLGlCQTZCbkM7SUE1QkQsSUFBTSxZQUFZLEdBQUcsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ25DLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ2hCLE9BQU87S0FDUjtJQUVELElBQUksQ0FBQyxZQUFZLEVBQUU7UUFDakIsTUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLHVCQUF1QixDQUFDLENBQUM7S0FDdEQ7SUFDRCxJQUFJLENBQUMsc0JBQUssQ0FBQyxZQUFZLENBQUMsWUFBWSxFQUFFLENBQUMsT0FBTyxFQUFFLGdCQUFnQixFQUFFLGNBQWMsRUFBRSxPQUFPLEVBQUUsYUFBYSxDQUFDLEVBQUUsc0JBQUssQ0FBQyxZQUFZLENBQUMsRUFBRTtRQUM5SCxNQUFNLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsZUFBZSxDQUFDO0tBQzdDO0lBRUMsT0FBTztRQUNMLElBQUksRUFBRTtZQUNKLE9BQU8scUJBQU8sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsU0FBUyxFQUFFLEtBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQzdELENBQUM7UUFFRCxRQUFRLEVBQUU7WUFDUjtnQkFDRSxJQUFJLEVBQUUsVUFBQyxNQUFNO29CQUNYLE9BQU8sNEJBQWMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUMsUUFBUSxFQUFHLE1BQU0sQ0FBQyxHQUFHLEVBQUUsRUFBRTt3QkFDOUQsSUFBSSxFQUFFLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFFO3dCQUN2QixLQUFLLEVBQUUsQ0FBQztxQkFDVCxDQUFDLENBQUM7Z0JBQ0wsQ0FBQzthQUNGO1NBQ0E7S0FDTjtBQUNELENBQUMsQ0FBQyxDQUFDO0FBR0wsTUFBTSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUU7SUFDekIsSUFBTSxZQUFZLEdBQUcsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO0lBRW5DLElBQUksQ0FBQyxZQUFZO1FBQ2YsQ0FBQyxzQkFBSyxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsY0FBYyxFQUFFLE9BQU8sRUFBRSxhQUFhLENBQUMsRUFBRSxTQUFTLENBQUMsRUFBRTtRQUNuSCxNQUFNLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsZUFBZSxDQUFDO0tBQzdDO0lBQ0QsT0FBTyw0QkFBYyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBQyxRQUFRLEVBQUUsWUFBWSxDQUFDLEdBQUcsRUFBQyxDQUFDLENBQUM7QUFDdEUsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUM1Q0gsbUVBQWdFO0FBRWhFLE1BQU0sQ0FBQyxPQUFPLENBQUUsUUFBUSxFQUFFLFVBQVUsS0FBSztJQUN2QyxLQUFLLENBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBRSxDQUFDO0lBQ3ZCLE9BQU8seUJBQVcsQ0FBQyxJQUFJLENBQUUsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLENBQUUsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ0pILGlEQUEyQztBQUUzQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxVQUN6QixNQUFjLEVBQ2Qsb0JBQTRCO0lBQzVCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQzNCLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUMvQixPQUFPO0tBQ1I7SUFDRCxPQUFPLHNCQUFRLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztRQUM5QixNQUFNO0tBQ1AsRUFBRTtRQUNELElBQUksRUFBRSxFQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztRQUNyQixLQUFLLEVBQUUsRUFBRSxHQUFHLG9CQUFvQjtLQUNqQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ2hCSCxpREFBOEM7QUFFOUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUU7SUFDN0IscUVBQXFFO0lBQ25FLE9BQU8seUJBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7QUFFL0IsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUNOSCxpREFBK0M7QUFFL0MsTUFBTSxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUU7SUFDN0IsT0FBTywwQkFBWSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ0pILGlEQUErQztBQUcvQyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRTtJQUM3QixPQUFPLDBCQUFZLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7O0FDSkgsZ0JBQWdCOztBQUdoQixpREFBc0Q7QUFFdEQsTUFBTSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsRUFBRTtJQUNyQyxPQUFPLGlDQUFtQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRSxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ1JILGlEQUFxRDtBQUVyRCxNQUFNLENBQUMsT0FBTyxDQUFFLE9BQU8sRUFBRTtJQUN2QixJQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsWUFBWSxDQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFFckYsSUFBSyxPQUFPLEVBQUc7UUFDYixPQUFPO1lBQ0wsbUJBQUssQ0FBQyxJQUFJLENBQUUsRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLEVBQUUsZ0JBQWdCLEVBQUUsQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFFO1lBQ2pFLHlCQUFXLENBQUMsSUFBSSxDQUFFLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBRTtTQUN6RSxDQUFDO0tBQ0g7U0FBTTtRQUNMLE9BQU8sSUFBSSxDQUFDO0tBQ2I7QUFDSCxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ2JILHFFQUFxRTtBQUNyRSw4Q0FBMkQ7QUFDM0QsOENBQTBDO0FBQzFDLG1DQUFnRDtBQUNoRCxzQ0FBNEM7QUFDNUMsMENBQXlDO0FBRXpDLElBQU0sY0FBYyxHQUFHLGFBQUssQ0FBQyxLQUFLLENBQUMsVUFBQyxHQUFHO0lBQ3JDLGFBQUssQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDbkIsT0FBTyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQztBQUVILElBQU0sY0FBYyxHQUFHLDRCQUE0QixDQUFDO0FBQ3BELElBQU0sT0FBTyxHQUFRLEtBQUssQ0FBQztBQUUzQixNQUFNLENBQUMsT0FBTyxDQUFDO0lBQ2IsT0FBTyxFQUFQLFVBQVEsVUFBa0I7UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsTUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUNuQyw2Q0FBNkMsQ0FBQyxDQUFDO1NBQ2xEO1FBRUQsYUFBSyxDQUFDLFVBQVUsRUFBRSxjQUFjLENBQUMsQ0FBQztRQUVsQyxJQUFJLFVBQVUsS0FBSyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQzlCLE1BQU0sSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLGtCQUFrQixFQUN2Qyw0REFBNEQsQ0FBQyxDQUFDO1NBQ2pFO1FBRUQsSUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLG1CQUFLLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztZQUN6QyxTQUFTLEVBQUUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxFQUFFO1NBQy9DLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUVYLElBQUksVUFBVSxFQUFFO1lBQ2QsTUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUNsQyxxQkFBcUIsQ0FBQyxDQUFDO1NBQzFCO1FBRUQsSUFBTSxJQUFJLEdBQUc7WUFDWCxTQUFTLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQztTQUNyQyxDQUFDO1FBRUYsbUJBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDckIsQ0FBQztJQUNELE1BQU0sRUFBTixVQUFPLFFBQWdCLEVBQUUsUUFBaUIsRUFBRSxLQUFjLEVBQUUsS0FBYSxFQUFFLEtBQWEsRUFBRSxJQUFhO1FBQ3JHLGFBQUssQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDaEMsYUFBSyxDQUFDLFFBQVEsRUFBRSxjQUFjLENBQUMsQ0FBQztRQUNoQyxhQUFLLENBQUMsS0FBSyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQzdCLGFBQUssQ0FBQyxLQUFLLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDN0IsYUFBSyxDQUFDLEtBQUssRUFBRSxjQUFjLENBQUMsQ0FBQztRQUU3QixJQUFNLElBQUksR0FBRztZQUNmLFFBQVEsRUFBRSxRQUFRO1lBQ2xCLEtBQUssRUFBRyxLQUFLO1lBQ2IsUUFBUSxFQUFHLFFBQVE7WUFDbkIsT0FBTyxFQUFFO2dCQUNQLElBQUksRUFBRyxLQUFLLEdBQUcsR0FBRyxHQUFHLEtBQUs7YUFDM0I7U0FDRDtRQUVELE9BQU8sUUFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBQ0EsVUFBVSxFQUFWLFVBQVcsTUFBYztRQUN2QixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixNQUFNLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQ25DLHVDQUF1QyxDQUFDLENBQUM7U0FDNUM7UUFDRCxhQUFLLENBQUMsTUFBTSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQzlCLElBQU0sVUFBVSxHQUFHLENBQUMsQ0FBQyxtQkFBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7UUFFM0QsSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNmLE1BQU0sSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUN0QyxxQkFBcUIsQ0FBQyxDQUFDO1NBQzFCO1FBRUQsbUJBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDdkIsQ0FBQztJQUNELGFBQWEsRUFBYixVQUFjLE9BQWdCO1FBQzVCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQUUsTUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUN2RCw2Q0FBNkMsQ0FBQyxDQUFDO1NBQ2hEO1FBQ0QsYUFBSyxDQUFDLE9BQU8sRUFBRTtZQUNiLElBQUksRUFBRSxjQUFjO1NBQ3JCLENBQUMsQ0FBQztRQUVILE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDL0IsSUFBSSxFQUFFLEVBQUMsT0FBTyxXQUFDO1NBQ2hCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFDRCxhQUFhLFlBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLO1FBQy9CLElBQUksS0FBSyxFQUFFO1lBQ1QsS0FBSyxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQzVDO2FBQU07WUFDTCxLQUFLLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztTQUNyQztJQUNILENBQUM7SUFDRCxrQkFBa0IsWUFBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQU07UUFDckMsSUFBSSxLQUFLLEVBQUU7WUFDVCxLQUFLLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDNUM7YUFBTTtZQUNMLEtBQUssQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3JDO0lBQ0gsQ0FBQztJQUNELFNBQVMsWUFBQyxVQUFVLEVBQUUsaUJBQWlCO1FBQ3JDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQUUsTUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUN2RCwrQ0FBK0MsQ0FBQyxDQUFDO1NBQ2xEO1FBRUQsYUFBSyxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUMxQixhQUFLLENBQUMsaUJBQWlCLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFFakMsT0FBTztZQUNMLE1BQU0sRUFBRSxxQkFBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7Z0JBQ2hDLElBQUksRUFBRSxVQUFVO2dCQUNoQixTQUFTLEVBQUUsSUFBSSxDQUFDLE1BQU07Z0JBQ3RCLFdBQVcsRUFBRSxpQkFBaUI7YUFDL0IsQ0FBQztTQUNILENBQUM7SUFDSixDQUFDO0lBQ0QsVUFBVSxZQUFDLElBQWlCLEVBQUUsTUFBYyxFQUFFLE9BQWU7UUFDM0QsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFBRSxNQUFNLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQ3ZELDZDQUE2QyxDQUFDLENBQUM7U0FDaEQ7UUFFRCxhQUFLLENBQUMsSUFBSSxFQUFFLGFBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUUsb0JBQVcsQ0FBQyxJQUFJLENBQUUsQ0FBQyxDQUFDLENBQUM7UUFDdkQsYUFBSyxDQUFDLE1BQU0sRUFBRSxjQUFjLENBQUMsQ0FBQztRQUM5QixhQUFLLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBRS9CLElBQU0sVUFBVSxHQUFHLENBQUMsQ0FBQyxtQkFBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7UUFFM0QsSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNmLE1BQU0sSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUN0QyxxQkFBcUIsQ0FBQyxDQUFDO1NBQzFCO1FBRUQsT0FBTztZQUNMLFNBQVMsRUFBRSxzQkFBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7Z0JBQ3BDLE1BQU0sRUFBRSxNQUFNO2dCQUNkLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTTtnQkFDckIsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRTtnQkFDckIsSUFBSSxFQUFFLElBQUk7YUFDWCxDQUFDO1NBQ0gsQ0FBQztJQUNKLENBQUM7SUFDRCxhQUFhLEVBQWI7UUFDRSxPQUFPLHNCQUFRLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQzVDLENBQUM7SUFDRCxnQkFBZ0IsWUFBRSxLQUFLLEVBQUUsUUFBUTtRQUMvQixRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUMsS0FBSyxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUVELE9BQU8sWUFBQyxJQUFTLEVBQUUsVUFBcUI7UUFDdEMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsTUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUNuQyxnREFBZ0QsQ0FBQyxDQUFDO1NBQ3JEO1FBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDMUIsSUFBSSxhQUFhLEdBQUcsRUFBRSxDQUFDO1FBQ3ZCLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUVmLElBQUcsVUFBVSxFQUFFO1lBQ2IsYUFBYSxHQUFHLEVBQUUsV0FBVyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBRSxFQUFFLENBQUM7WUFFN0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUMzQixLQUFLLEdBQUc7Z0JBQ04sYUFBYSxFQUFDLFNBQVM7Z0JBRXRCLEtBQUssRUFBRyxxaEhBQXFoSDtnQkFFOWhILFNBQVMsRUFBRyxhQUFhO2FBQzFCLENBQUM7U0FFSDthQUFNO1lBQ0wsYUFBYSxHQUFHLEVBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBRSxFQUFDLENBQUM7WUFFMUQsS0FBSyxHQUFHO2dCQUNQLEtBQUssRUFBRSw2dkJBQTZ2QjtnQkFFcHdCLFNBQVMsRUFBRyxhQUFhO2FBQzFCLENBQUM7U0FFSjtRQUVBLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDM0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUVuQixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXBDLElBQU0sZ0JBQWdCLEdBQUc7WUFDdkIsV0FBVyxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ3hCLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLFFBQVEsRUFBRSxTQUFTO1lBQ25CLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRTtTQUN0QixDQUFDO1FBRUYsSUFBSSxZQUFZLEdBQUcseUJBQVcsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFFbkUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsR0FBRyxZQUFZLENBQUMsQ0FBQztRQUMvQyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUMsQ0FBQztRQUVsQyxJQUFJLE9BQU8sR0FBRztZQUNaLElBQUksRUFBRSxjQUFjO1lBQ3BCLElBQUksRUFBRSxVQUFVO1lBQ2hCLE1BQU0sRUFBRSxNQUFNO1lBQ2QsT0FBTyxFQUFFO2dCQUNQLGNBQWMsRUFBRSxrQkFBa0I7YUFDbkM7U0FDRixDQUFDO1FBQ0YsSUFBSSxLQUFLLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBRWxDLElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQztRQUVyQixpQkFBTyxDQUFDLEtBQUssQ0FDWixXQUFXLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLElBQUksRUFBRTtZQUNoRCxNQUFNLEVBQUUsT0FBTyxDQUFDLE1BQU07WUFDdEIsT0FBTyxFQUFFLEVBQUMsY0FBYyxFQUFFLGtCQUFrQixFQUFDO1lBQzdDLElBQUksRUFBRSxPQUFPO1NBQ2QsQ0FBQzthQUNELElBQUksQ0FBQyxrQkFBUSxJQUFJLGVBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBZixDQUFlLENBQUM7YUFDakMsSUFBSSxDQUFDLGtCQUFRLElBQUksZUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQXBCLENBQW9CLENBQUM7YUFDdEMsSUFBSSxDQUFDLGtCQUFRO1lBRVosaUJBQWlCO1lBQ2xCLHlCQUFXLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsRUFBQyxJQUFJLEVBQUUsRUFBQyxRQUFRLEVBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBQyxFQUFFLENBQUMsQ0FBQztZQUMzRixPQUFPLFFBQVEsQ0FBQztRQUVsQixDQUFDLENBQUM7YUFDRCxLQUFLLENBQUMsYUFBRztZQUNSLE9BQU8sR0FBRyxDQUFDO1FBRWIsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVKLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFekIsT0FBTyxXQUFXLENBQUM7SUFDckIsQ0FBQztDQUdGLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQy9PVSwyQkFBbUIsR0FBRyxpQ0FBaUMsQ0FBQztBQWNyRSxJQUFZLFdBSVg7QUFKRCxXQUFZLFdBQVc7SUFDckIsa0NBQVksTUFBTTtJQUNsQixzQ0FBZ0IsVUFBVTtJQUMxQixxQ0FBZSxTQUFTO0FBQzFCLENBQUMsRUFKVyxXQUFXLEdBQVgsbUJBQVcsS0FBWCxtQkFBVyxRQUl0QjtBQWlDRCxJQUFZLFlBS1g7QUFMRCxXQUFZLFlBQVk7SUFDdEIseUNBQXlCO0lBQ3pCLG1EQUFtQztJQUNuQyxpREFBaUM7SUFDakMscUNBQXFCO0FBQ3ZCLENBQUMsRUFMVyxZQUFZLEdBQVosb0JBQVksS0FBWixvQkFBWSxRQUt2QjtBQXNCRCxJQUFZLFNBTVg7QUFORCxXQUFZLFNBQVM7SUFDbkIsNEJBQWU7SUFDZix3Q0FBMkI7SUFDM0IsNEJBQWU7SUFDZixnQ0FBbUI7SUFDbkIsOEJBQW1CO0FBQ3JCLENBQUMsRUFOVyxTQUFTLEdBQVQsaUJBQVMsS0FBVCxpQkFBUyxRQU1wQjtBQUVELElBQVkscUJBS1g7QUFMRCxXQUFZLHFCQUFxQjtJQUMzQiwwQ0FBZ0I7SUFDaEIsc0NBQVk7SUFDWiwwQ0FBZ0I7SUFDaEIsMENBQWdCO0FBQ3RCLENBQUMsRUFMVyxxQkFBcUIsR0FBckIsNkJBQXFCLEtBQXJCLDZCQUFxQixRQUtoQztBQXdDRCxJQUFZLGVBR1g7QUFIRCxXQUFZLGVBQWU7SUFDekIsc0RBQW1DO0lBQ25DLG9EQUFpQztBQUNuQyxDQUFDLEVBSFcsZUFBZSxHQUFmLHVCQUFlLEtBQWYsdUJBQWUsUUFHMUI7QUFFRCxJQUFZLG9CQUdYO0FBSEQsV0FBWSxvQkFBb0I7SUFDOUIsMkNBQWtCO0lBQ2xCLDZDQUFvQjtBQUN0QixDQUFDLEVBSFcsb0JBQW9CLEdBQXBCLDRCQUFvQixLQUFwQiw0QkFBb0IsUUFHL0I7QUFRRCxJQUFZLGlCQUtYO0FBTEQsV0FBWSxpQkFBaUI7SUFDM0Isc0NBQWlCO0lBQ2pCLDhDQUF5QjtJQUN6Qiw0Q0FBdUI7SUFDdkIsc0NBQWlCO0FBQ25CLENBQUMsRUFMVyxpQkFBaUIsR0FBakIseUJBQWlCLEtBQWpCLHlCQUFpQixRQUs1Qjs7Ozs7Ozs7Ozs7OztBQ3hKRCxxRUFBcUU7QUFDckUsd0NBQXFDO0FBQ3JDLDhDQUF1QztBQUN2Qyw4Q0FBaUQ7QUFDakQsZ0VBQWlEO0FBRWpELE1BQU0sQ0FBQyxPQUFPLENBQUMsbUJBQW1CLEVBQUUsVUFBUyxFQUFHO0lBRTlDLDJCQUFNLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxtQkFBbUIsRUFBRSxtQkFBVyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7QUFDaEUsQ0FBQyxDQUFDLENBQUM7QUFFSCxlQUFNLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsVUFBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLElBQUk7SUFDbEQsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNuQixHQUFHLENBQUMsR0FBRyxDQUFDLHVCQUFxQixNQUFNLENBQUMsT0FBUyxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxVQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsSUFBSTtJQUVoQyxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBTyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsVUFBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLElBQUk7SUFHbkMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNuQixHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMscUJBQU8sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRCxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQ3ZCSCx3Q0FBdUM7QUFFdkMsOENBQTJDO0FBQzNDO0lBQ0UsT0FBTyxDQUFDLENBQUM7QUFDWCxDQUFDO0FBQ0QsZ0JBQWlCLEVBQUU7SUFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDL0QsT0FBTyxJQUFJLENBQUM7QUFDZCxDQUFDO0FBQ0Q7SUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxDQUFDLENBQUM7SUFDbkQsT0FBTyxJQUFJLENBQUM7QUFDZCxDQUFDO0FBRUQsZUFBTSxDQUFDLE9BQU8sQ0FBQztJQUNiLHdCQUF3QjtJQUN4Qiw4QkFBOEI7SUFFOUIsSUFBSSxlQUFNLENBQUMsUUFBUSxFQUFFO1FBQ25CLHNFQUFzRTtRQUN0RSwwQ0FBMEM7S0FDM0M7SUFFRCxJQUFJLGFBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxFQUFFO1FBQ3ZDLE9BQU87S0FDUjtBQUVILENBQUMsQ0FBQyxDQUFDIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJNZXRlb3IubWV0aG9kcyh7XG4gIHNlbmRJbnZpdGF0aW9uKCBpbnZpdGF0aW9uICkge1xuICAgIGNoZWNrKCBpbnZpdGF0aW9uLCB7XG4gICAgICBlbWFpbDogU3RyaW5nLFxuICAgICAgcm9sZTogU3RyaW5nXG4gICAgfSk7XG5cbiAgICB0cnkge1xuICAgICAgTW9kdWxlcy5zZXJ2ZXIuc2VuZEludml0YXRpb24oe1xuICAgICAgICBlbWFpbDogaW52aXRhdGlvbi5lbWFpbCxcbiAgICAgICAgdG9rZW46IFJhbmRvbS5oZXhTdHJpbmcoIDE2ICksXG4gICAgICAgIHJvbGU6IGludml0YXRpb24ucm9sZSxcbiAgICAgICAgZGF0ZTogKCBuZXcgRGF0ZSgpICkudG9JU09TdHJpbmcoKVxuICAgICAgfSk7XG4gICAgfSBjYXRjaCggZXhjZXB0aW9uICkge1xuICAgICAgcmV0dXJuIGV4Y2VwdGlvbjtcbiAgICB9XG4gIH1cbn0pO1xuIiwiTWV0ZW9yLm1ldGhvZHMoe1xuICBhY2NlcHRJbnZpdGF0aW9uKCB1c2VyICkge1xuICAgIGNoZWNrKCB1c2VyLCB7XG4gICAgICBlbWFpbDogU3RyaW5nLFxuICAgICAgcGFzc3dvcmQ6IE9iamVjdCxcbiAgICAgIHRva2VuOiBTdHJpbmdcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICB2YXIgdXNlcklkID0gTW9kdWxlcy5zZXJ2ZXIuYWNjZXB0SW52aXRhdGlvbiggdXNlciApO1xuICAgICAgcmV0dXJuIHVzZXJJZDtcbiAgICB9IGNhdGNoKCBleGNlcHRpb24gKSB7XG4gICAgICByZXR1cm4gZXhjZXB0aW9uO1xuICAgIH1cbiAgfVxufSk7XG4iLCJNZXRlb3IubWV0aG9kcyh7XG4gIHJlYWRNZXRob2QoIGFyZ3VtZW50ICkge1xuICAgIGNoZWNrKCBhcmd1bWVudCwgU3RyaW5nICk7XG5cbiAgICB2YXIgZG9jdW1lbnQgPSBDb2xsZWN0aW9uLmZpbmRPbmUoIGFyZ3VtZW50ICk7XG5cbiAgICBpZiAoICFkb2N1bWVudCApIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoICdkb2N1bWVudC1ub3QtZm91bmQnLCAnTm8gZG9jdW1lbnRzIGZvdW5kIG1hdGNoaW5nIHRoaXMgcXVlcnkuJyApO1xuICAgIH1cblxuICAgIHJldHVybiBkb2N1bWVudDtcbiAgfVxufSk7XG4iLCJNZXRlb3IubWV0aG9kcyh7XG4gIHJldm9rZUludml0YXRpb24oIGludml0ZUlkICkge1xuICAgIGNoZWNrKCBpbnZpdGVJZCwgU3RyaW5nICk7XG5cbiAgICB0cnkge1xuICAgICAgSW52aXRhdGlvbnMucmVtb3ZlKCBpbnZpdGVJZCApO1xuICAgIH0gY2F0Y2goIGV4Y2VwdGlvbiApIHtcbiAgICAgIHJldHVybiBleGNlcHRpb247XG4gICAgfVxuICB9XG59KTtcbiIsIk1ldGVvci5tZXRob2RzKHtcbiAgc2V0Um9sZU9uVXNlciggb3B0aW9ucyApIHtcbiAgICBjaGVjayggb3B0aW9ucywge1xuICAgICAgdXNlcjogU3RyaW5nLFxuICAgICAgcm9sZTogU3RyaW5nXG4gICAgfSk7XG5cbiAgICB0cnkge1xuICAgICAgUm9sZXMuc2V0VXNlclJvbGVzKCBvcHRpb25zLnVzZXIsIFsgb3B0aW9ucy5yb2xlIF0gKTtcbiAgICB9IGNhdGNoKCBleGNlcHRpb24gKSB7XG4gICAgICByZXR1cm4gZXhjZXB0aW9uO1xuICAgIH1cbiAgfVxufSk7XG4iLCJNb2R1bGVzICAgICAgPSB7fTtcbk1vZHVsZXMuYm90aCA9IHt9O1xuIiwibGV0IHJvdXRlID0gKCBvcHRpb25zICkgPT4ge1xuICByZXR1cm4gb3B0aW9ucyAmJiBvcHRpb25zLnJlZGlyZWN0ID8gX3NlbmRVc2VyVG9EZWZhdWx0KCBvcHRpb25zLnJlZGlyZWN0ICkgOiBfc2VuZFVzZXJUb0RlZmF1bHQoKTtcbn07XG5cbmxldCBfc2VuZFVzZXJUb0RlZmF1bHQgPSAoIHJlZGlyZWN0ICkgPT4ge1xuICBsZXQgcm9sZXMgPSBfZ2V0Q3VycmVudFVzZXJSb2xlcygpO1xuXG4gIGlmICggcm9sZXNbMF0gPT09ICdhZG1pbicgKSAgICB7XG4gICAgX3JlZGlyZWN0VXNlciggJ3VzZXJzJywgcmVkaXJlY3QgKTtcbiAgfVxuXG4gIGlmICggcm9sZXNbMF0gPT09ICdtYW5hZ2VyJyApICB7XG4gICAgX3JlZGlyZWN0VXNlciggJ21hbmFnZXJzJywgcmVkaXJlY3QgKTtcbiAgfVxuXG4gIGlmICggcm9sZXNbMF0gPT09ICdlbXBsb3llZScgKSB7XG4gICAgX3JlZGlyZWN0VXNlciggJ2VtcGxveWVlcycsIHJlZGlyZWN0ICk7XG4gIH1cbn07XG5cbmxldCBfZ2V0Q3VycmVudFVzZXJSb2xlcyA9ICgpID0+IHtcbiAgcmV0dXJuIFJvbGVzLmdldFJvbGVzRm9yVXNlciggTWV0ZW9yLnVzZXJJZCgpICk7XG59O1xuXG5sZXQgX3JlZGlyZWN0VXNlciA9ICggcGF0aCwgcmVkaXJlY3QgKSA9PiB7XG4gIGlmICggcmVkaXJlY3QgKSB7XG4gICAgcmVkaXJlY3QoIHBhdGggKTtcbiAgfSBlbHNlIHtcbiAgICBGbG93Um91dGVyLmdvKCBGbG93Um91dGVyLnBhdGgoIHBhdGggKSApO1xuICB9XG59O1xuXG5Nb2R1bGVzLmJvdGgucmVkaXJlY3RVc2VyID0gcm91dGU7XG4iLCJsZXQgc3RhcnR1cCA9ICgpID0+IHt9O1xuXG5Nb2R1bGVzLmJvdGguc3RhcnR1cCA9IHN0YXJ0dXA7XG4iLCJjb25zdCBhdXRoZW50aWNhdGVkUmVkaXJlY3QgPSAoKSA9PiB7XG4gIGlmICggIU1ldGVvci5sb2dnaW5nSW4oKSAmJiAhTWV0ZW9yLnVzZXJJZCgpICkge1xuICAgIEZsb3dSb3V0ZXIuZ28oICdsb2dpbicgKTtcbiAgfVxufTtcblxuY29uc3QgYmxvY2tVbmF1dGhvcml6ZWRBZG1pbiA9ICggY29udGV4dCwgcmVkaXJlY3QgKSA9PiB7XG4gIGlmICggTWV0ZW9yLnVzZXJJZCgpICYmICFSb2xlcy51c2VySXNJblJvbGUoIE1ldGVvci51c2VySWQoKSwgJ2FkbWluJyApICkge1xuICAgIE1vZHVsZXMuYm90aC5yZWRpcmVjdFVzZXIoIHsgcmVkaXJlY3Q6IHJlZGlyZWN0IH0gKTtcbiAgfVxufTtcblxuY29uc3QgYmxvY2tVbmF1dGhvcml6ZWRNYW5hZ2VyID0gKCBjb250ZXh0LCByZWRpcmVjdCApID0+IHtcbiAgaWYgKCBNZXRlb3IudXNlcklkKCkgJiYgIVJvbGVzLnVzZXJJc0luUm9sZSggTWV0ZW9yLnVzZXJJZCgpLCBbICdhZG1pbicsICdtYW5hZ2VyJyBdICkgKSB7XG4gICAgTW9kdWxlcy5ib3RoLnJlZGlyZWN0VXNlciggeyByZWRpcmVjdDogcmVkaXJlY3QgfSApO1xuICB9XG59O1xuXG5jb25zdCBhdXRoZW50aWNhdGVkUm91dGVzID0gRmxvd1JvdXRlci5ncm91cCh7XG4gIG5hbWU6ICdhdXRoZW50aWNhdGVkJyxcbiAgdHJpZ2dlcnNFbnRlcjogWyBhdXRoZW50aWNhdGVkUmVkaXJlY3QgXVxufSk7XG5cbmF1dGhlbnRpY2F0ZWRSb3V0ZXMucm91dGUoICcvdXNlcnMnLCB7XG4gIG5hbWU6ICd1c2VycycsXG4gIHRyaWdnZXJzRW50ZXI6IFsgYmxvY2tVbmF1dGhvcml6ZWRBZG1pbiBdLFxuICBhY3Rpb24oKSB7XG4gICAgQmxhemVMYXlvdXQucmVuZGVyKCAnZGVmYXVsdCcsIHsgeWllbGQ6ICd1c2VycycgfSApO1xuICB9XG59KTtcblxuYXV0aGVudGljYXRlZFJvdXRlcy5yb3V0ZSggJy9tYW5hZ2VycycsIHtcbiAgbmFtZTogJ21hbmFnZXJzJyxcbiAgdHJpZ2dlcnNFbnRlcjogWyBibG9ja1VuYXV0aG9yaXplZE1hbmFnZXIgXSxcbiAgYWN0aW9uKCkge1xuICAgIEJsYXplTGF5b3V0LnJlbmRlciggJ2RlZmF1bHQnLCB7IHlpZWxkOiAnbWFuYWdlcnMnIH0gKTtcbiAgfVxufSk7XG5cbmF1dGhlbnRpY2F0ZWRSb3V0ZXMucm91dGUoICcvZW1wbG95ZWVzJywge1xuICBuYW1lOiAnZW1wbG95ZWVzJyxcbiAgYWN0aW9uKCkge1xuICAgIEJsYXplTGF5b3V0LnJlbmRlciggJ2RlZmF1bHQnLCB7IHlpZWxkOiAnZW1wbG95ZWVzJyB9ICk7XG4gIH1cbn0pO1xuIiwiRmxvd1JvdXRlci5ub3RGb3VuZCA9IHtcbiAgYWN0aW9uKCkge1xuICAgIEJsYXplTGF5b3V0LnJlbmRlciggJ2RlZmF1bHQnLCB7IHlpZWxkOiAnbm90Rm91bmQnIH0gKTtcbiAgfVxufTtcblxuQWNjb3VudHMub25Mb2dpbiggKCkgPT4ge1xuICBsZXQgY3VycmVudFJvdXRlID0gRmxvd1JvdXRlci5jdXJyZW50KCk7XG4gIGlmICggY3VycmVudFJvdXRlICYmIGN1cnJlbnRSb3V0ZS5yb3V0ZS5ncm91cC5uYW1lID09PSAncHVibGljJyApIHtcbiAgICBNb2R1bGVzLmJvdGgucmVkaXJlY3RVc2VyKCk7XG4gIH1cbn0pO1xuXG5pZiAoIE1ldGVvci5pc0NsaWVudCApIHtcbiAgVHJhY2tlci5hdXRvcnVuKCAoKSA9PiB7XG4gICAgaWYgKCAhTWV0ZW9yLnVzZXJJZCgpICYmIEZsb3dSb3V0ZXIuY3VycmVudCgpLnJvdXRlICkge1xuICAgICAgRmxvd1JvdXRlci5nbyggJ2xvZ2luJyApO1xuICAgIH1cbiAgfSk7XG59XG4iLCJjb25zdCBwdWJsaWNSZWRpcmVjdCA9ICggY29udGV4dCwgcmVkaXJlY3QgKSA9PiB7XG4gIGlmICggTWV0ZW9yLnVzZXJJZCgpICkge1xuICAgIE1vZHVsZXMuYm90aC5yZWRpcmVjdFVzZXIoIHsgcmVkaXJlY3Q6IHJlZGlyZWN0IH0gKTtcbiAgfVxufTtcblxuY29uc3QgcHVibGljUm91dGVzID0gRmxvd1JvdXRlci5ncm91cCh7XG4gIG5hbWU6ICdwdWJsaWMnLFxuICB0cmlnZ2Vyc0VudGVyOiBbIHB1YmxpY1JlZGlyZWN0IF1cbn0pO1xuXG5wdWJsaWNSb3V0ZXMucm91dGUoICcvaW52aXRlLzp0b2tlbicsIHtcbiAgbmFtZTogJ2ludml0ZScsXG4gIGFjdGlvbigpIHtcbiAgICBCbGF6ZUxheW91dC5yZW5kZXIoICdkZWZhdWx0JywgeyB5aWVsZDogJ2ludml0ZScgfSApO1xuICB9XG59KTtcblxucHVibGljUm91dGVzLnJvdXRlKCAnL2xvZ2luJywge1xuICBuYW1lOiAnbG9naW4nLFxuICBhY3Rpb24oKSB7XG4gICAgQmxhemVMYXlvdXQucmVuZGVyKCAnZGVmYXVsdCcsIHsgeWllbGQ6ICdsb2dpbicgfSApO1xuICB9XG59KTtcblxucHVibGljUm91dGVzLnJvdXRlKCAnL3JlY292ZXItcGFzc3dvcmQnLCB7XG4gIG5hbWU6ICdyZWNvdmVyLXBhc3N3b3JkJyxcbiAgYWN0aW9uKCkge1xuICAgIEJsYXplTGF5b3V0LnJlbmRlciggJ2RlZmF1bHQnLCB7IHlpZWxkOiAncmVjb3ZlclBhc3N3b3JkJyB9ICk7XG4gIH1cbn0pO1xuXG5wdWJsaWNSb3V0ZXMucm91dGUoICcvcmVzZXQtcGFzc3dvcmQvOnRva2VuJywge1xuICBuYW1lOiAncmVzZXQtcGFzc3dvcmQnLFxuICBhY3Rpb24oKSB7XG4gICAgQmxhemVMYXlvdXQucmVuZGVyKCAnZGVmYXVsdCcsIHsgeWllbGQ6ICdyZXNldFBhc3N3b3JkJyB9ICk7XG4gIH1cbn0pO1xuIiwiTWV0ZW9yLnN0YXJ0dXAoICgpID0+IE1vZHVsZXMuYm90aC5zdGFydHVwKCkgKTtcbiIsImltcG9ydCB7IE1vbmdvT2JzZXJ2YWJsZSB9IGZyb20gJ21ldGVvci1yeGpzJztcclxuaW1wb3J0IHtDb3Vyc2UsIENvdXJzZVN1YmplY3R9IGZyb20gJy4uLy4uL3NlcnZlci9tb2RlbHMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IENvdXJzZXMgPSBuZXcgTW9uZ29PYnNlcnZhYmxlLkNvbGxlY3Rpb248Q291cnNlPignY291cnNlcycpO1xyXG5leHBvcnQgY29uc3QgQ291cnNlU3ViamVjdHMgPSBuZXcgTW9uZ29PYnNlcnZhYmxlLkNvbGxlY3Rpb248Q291cnNlU3ViamVjdD4oJ2NvdXJzZV9zdWJqZWN0cycpO1xyXG4iLCJleHBvcnQgeyBQcmVkaWN0aW9ucyB9IGZyb20gJy4vcHJlZGljdGlvbnMnO1xyXG4iLCJpbXBvcnQgeyBNb25nb09ic2VydmFibGUgfSBmcm9tICdtZXRlb3Itcnhqcyc7XHJcbmltcG9ydCB7UHJlZGl0aW9ufSBmcm9tICcuLi8uLi9zZXJ2ZXIvbW9kZWxzJztcclxuXHJcbmV4cG9ydCBjb25zdCBQcmVkaWN0aW9ucyA9IG5ldyBNb25nb09ic2VydmFibGUuQ29sbGVjdGlvbjxQcmVkaXRpb24+KCdwcmVkaWN0aW9ucycpOyIsImltcG9ydCB7IE1vbmdvT2JzZXJ2YWJsZSB9IGZyb20gJ21ldGVvci1yeGpzJztcclxuaW1wb3J0IHsgVHJhbnNhY3Rpb25BY2NvdW50IH0gZnJvbSAnLi4vLi4vc2VydmVyL21vZGVscyc7XHJcblxyXG5leHBvcnQgY29uc3QgVHJhbnNhY3Rpb25BY2NvdW50cyA9IG5ldyBNb25nb09ic2VydmFibGUuQ29sbGVjdGlvbjxUcmFuc2FjdGlvbkFjY291bnQ+KCd0cmFuc2FjdGlvbl9hY2NvdW50cycpO1xyXG4iLCJleHBvcnQgKiBmcm9tICcuL3RyYW5zYWN0aW9ucyc7XHJcbmV4cG9ydCAqIGZyb20gJy4vYWNjb3VudHMnO1xyXG5leHBvcnQgKiBmcm9tICcuL3JlZmVyZW5jZXMnO1xyXG4iLCJpbXBvcnQgeyBNb25nb09ic2VydmFibGUgfSBmcm9tICdtZXRlb3Itcnhqcyc7XHJcbmltcG9ydCB7IFRyYW5zYWN0aW9uUmVmZXJlbmNlIH0gZnJvbSAnLi4vLi4vc2VydmVyL21vZGVscyc7XHJcblxyXG5leHBvcnQgY29uc3QgVHJhbnNhY3Rpb25SZWZlcmVuY2VzID0gbmV3IE1vbmdvT2JzZXJ2YWJsZS5Db2xsZWN0aW9uPFRyYW5zYWN0aW9uUmVmZXJlbmNlPigncmVmZXJlbmNlcycpO1xyXG4iLCJpbXBvcnQgeyBNb25nb09ic2VydmFibGUgfSBmcm9tICdtZXRlb3Itcnhqcyc7XHJcbmltcG9ydCB7IFRyYW5zYWN0aW9uIH0gZnJvbSAnLi4vLi4vc2VydmVyL21vZGVscyc7XHJcblxyXG5leHBvcnQgY29uc3QgVHJhbnNhY3Rpb25zID0gbmV3IE1vbmdvT2JzZXJ2YWJsZS5Db2xsZWN0aW9uPFRyYW5zYWN0aW9uPigndHJhbnNhY3Rpb25zJyk7XHJcbiIsImV4cG9ydCAqIGZyb20gJy4vdXNlcnMnO1xuZXhwb3J0ICogZnJvbSAnLi9pbnZpdGF0aW9ucyc7XG4iLCJpbXBvcnQge1NpbXBsZVNjaGVtYX0gZnJvbSAnc2ltcGwtc2NoZW1hL2Rpc3QvU2ltcGxlU2NoZW1hJztcblxuZXhwb3J0IGNvbnN0IEludml0YXRpb25zOiBhbnkgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbiggJ2ludml0YXRpb25zJyApO1xuXG5JbnZpdGF0aW9ucy5hbGxvdyh7XG4gIGluc2VydDogKCkgPT4gZmFsc2UsXG4gIHVwZGF0ZTogKCkgPT4gZmFsc2UsXG4gIHJlbW92ZTogKCkgPT4gZmFsc2Vcbn0pO1xuXG5JbnZpdGF0aW9ucy5kZW55KHtcbiAgaW5zZXJ0OiAoKSA9PiB0cnVlLFxuICB1cGRhdGU6ICgpID0+IHRydWUsXG4gIHJlbW92ZTogKCkgPT4gdHJ1ZVxufSk7XG5cbmNvbnN0IEludml0YXRpb25zU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIGVtYWlsOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnRW1haWwgdG8gc2VuZCBpbnZpdGF0aW9uIHRvLidcbiAgfSxcbiAgdG9rZW46IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdJbnZpdGF0aW9uIHRva2VuLidcbiAgfSxcbiAgcm9sZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1JvbGUgdG8gYXBwbHkgdG8gdGhlIHVzZXIuJ1xuICB9LFxuICBkYXRlOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnSW52aXRhdGlvbiBEYXRlJ1xuICB9XG59KTtcblxuSW52aXRhdGlvbnMuYXR0YWNoU2NoZW1hKCBJbnZpdGF0aW9uc1NjaGVtYSApO1xuIiwiaW1wb3J0IHsgTW9uZ29PYnNlcnZhYmxlIH0gZnJvbSAnbWV0ZW9yLXJ4anMnO1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBVc2VyIH0gZnJvbSAnLi4vLi4vc2VydmVyL21vZGVscyc7XG5cbk1ldGVvci51c2Vycy5hbGxvdyh7XG4gIGluc2VydDogKCkgPT4gZmFsc2UsXG4gIHVwZGF0ZTogKCkgPT4gZmFsc2UsXG4gIHJlbW92ZTogKCkgPT4gZmFsc2Vcbn0pO1xuXG5NZXRlb3IudXNlcnMuZGVueSh7XG4gIGluc2VydDogKCkgPT4gdHJ1ZSxcbiAgdXBkYXRlOiAoKSA9PiB0cnVlLFxuICByZW1vdmU6ICgpID0+IHRydWVcbn0pO1xuXG5leHBvcnQgY29uc3QgVXNlcnMgPSBNb25nb09ic2VydmFibGUuZnJvbUV4aXN0aW5nPFVzZXI+KE1ldGVvci51c2Vycyk7XG4iLCJpbXBvcnQgeyBNb25nb09ic2VydmFibGUgfSBmcm9tICdtZXRlb3Itcnhqcyc7XG5pbXBvcnQgeyBDaGF0IH0gZnJvbSAnLi4vc2VydmVyL21vZGVscyc7XG5cbmV4cG9ydCBjb25zdCBDaGF0cyA9IG5ldyBNb25nb09ic2VydmFibGUuQ29sbGVjdGlvbjxDaGF0PignY2hhdHMnKTtcbiIsImV4cG9ydCAqIGZyb20gJy4vY2hhdHMnO1xuZXhwb3J0ICogZnJvbSAnLi9tZXNzYWdlcyc7XG5leHBvcnQge0NvdXJzZXMsIENvdXJzZVN1YmplY3RzfSBmcm9tICcuL2NvdXJzZS9jb3Vyc2VzJztcbmV4cG9ydCAqIGZyb20gJy4vdHJhbnNhY3Rpb25hbC9pbmRleCc7XG5leHBvcnQgKiBmcm9tICcuL3N0dWRlbnRzJztcblxuXG5leHBvcnQge1VzZXJzLCBJbnZpdGF0aW9uc30gZnJvbSAnLi91c2Vycyc7XG5leHBvcnQgKiBmcm9tICcuL2hpdmRiJztcbiIsImltcG9ydCB7IE1vbmdvT2JzZXJ2YWJsZSB9IGZyb20gJ21ldGVvci1yeGpzJztcbmltcG9ydCB7IE1lc3NhZ2UgfSBmcm9tICcuLi9zZXJ2ZXIvbW9kZWxzJztcblxuZXhwb3J0IGNvbnN0IE1lc3NhZ2VzID0gbmV3IE1vbmdvT2JzZXJ2YWJsZS5Db2xsZWN0aW9uPE1lc3NhZ2U+KCdtZXNzYWdlcycpO1xuIiwiaW1wb3J0IHsgTW9uZ29PYnNlcnZhYmxlIH0gZnJvbSAnbWV0ZW9yLXJ4anMnO1xuaW1wb3J0IHsgU3R1ZGVudERhdGEgfSBmcm9tICcuLi9zZXJ2ZXIvbW9kZWxzJztcblxuZXhwb3J0IGNvbnN0IFN0dWRlbnRzRGF0YSA9IG5ldyBNb25nb09ic2VydmFibGUuQ29sbGVjdGlvbjxTdHVkZW50RGF0YT4oJ3N0dWRlbnRzRGF0YScpO1xuXG4iLCJpbXBvcnQge0NoYXQsIE1lc3NhZ2UsIFVzZXJ9IGZyb20gJy4uL21vZGVscyc7XHJcbmltcG9ydCB7Q2hhdHMsIE1lc3NhZ2VzLCBVc2Vyc30gZnJvbSAnLi4vLi4vY29sbGVjdGlvbnMnO1xyXG5cclxuXHJcbk1ldGVvclsncHVibGlzaENvbXBvc2l0ZSddKCdjaGF0cycsIGZ1bmN0aW9uKCk6IFB1Ymxpc2hDb21wb3NpdGVDb25maWc8Q2hhdD4ge1xyXG4gIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBmaW5kOiAoKSA9PiB7XHJcbiAgICAgIHJldHVybiBDaGF0cy5jb2xsZWN0aW9uLmZpbmQoeyBtZW1iZXJJZHM6IHRoaXMudXNlcklkIH0pO1xyXG4gICAgfSxcclxuXHJcbiAgICBjaGlsZHJlbjogW1xyXG4gICAgICA8UHVibGlzaENvbXBvc2l0ZUNvbmZpZzE8Q2hhdCwgTWVzc2FnZT4+IHtcclxuICAgICAgICBmaW5kOiAoY2hhdCkgPT4ge1xyXG4gICAgICAgICAgcmV0dXJuIE1lc3NhZ2VzLmNvbGxlY3Rpb24uZmluZCh7IGNoYXRJZDogY2hhdC5faWQgfSwge1xyXG4gICAgICAgICAgICBzb3J0OiB7IGNyZWF0ZWRBdDogLTEgfSxcclxuICAgICAgICAgICAgbGltaXQ6IDFcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgPFB1Ymxpc2hDb21wb3NpdGVDb25maWcxPENoYXQsIFVzZXI+PiB7XHJcbiAgICAgICAgZmluZDogKGNoYXQpID0+IHtcclxuICAgICAgICAgIHJldHVybiBVc2Vycy5jb2xsZWN0aW9uLmZpbmQoe1xyXG4gICAgICAgICAgICBfaWQ6IHsgJGluOiBjaGF0Lm1lbWJlcklkcyB9XHJcbiAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgIGZpZWxkczogeyBwcm9maWxlOiAxIH1cclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgXVxyXG4gIH07XHJcbn0pO1xyXG5cclxuIiwiaW1wb3J0IHtSb2xlc30gZnJvbSAnbWV0ZW9yL2FsYW5uaW5nOnJvbGVzJztcclxuaW1wb3J0IHtDaGF0cywgQ291cnNlcywgQ291cnNlU3ViamVjdHMsIE1lc3NhZ2VzfSBmcm9tICcuLi8uLi9jb2xsZWN0aW9ucyc7XHJcbmltcG9ydCB7Q291cnNlLCBDb3Vyc2VTdWJqZWN0fSBmcm9tICcuLi9tb2RlbHMnO1xyXG5cclxuTWV0ZW9yWydwdWJsaXNoQ29tcG9zaXRlJ10oJ2NvdXJzZXMnLCBmdW5jdGlvbiAoKTogUHVibGlzaENvbXBvc2l0ZUNvbmZpZzxDb3Vyc2U+IHtcclxuICBjb25zdCBsb2dnZWRJblVzZXIgPSBNZXRlb3IudXNlcigpO1xyXG4gIGlmICghdGhpcy51c2VySWQpIHtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIGlmICghbG9nZ2VkSW5Vc2VyKSB7XHJcbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgJ0F1dGhlbnRpY2F0aW9uIGZhaWxlZCcpO1xyXG4gIH1cclxuICBpZiAoIVJvbGVzLnVzZXJJc0luUm9sZShsb2dnZWRJblVzZXIsIFsndHV0b3InLCAnbWFuYWdlLWNvdXJzZXMnLCAndmlldy1jb3Vyc2VzJywgJ2FkbWluJywgJ3N1cGVyLWFkbWluJ10sIFJvbGVzLkdMT0JBTF9HUk9VUCkpIHtcclxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCAnQWNjZXNzIGRlbmllZCcpXHJcbiAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIGZpbmQ6ICgpID0+IHtcclxuICAgICAgICByZXR1cm4gQ291cnNlcy5jb2xsZWN0aW9uLmZpbmQoeyBvd25lcnNoaXA6IHRoaXMudXNlcklkIH0pO1xyXG4gICAgICB9LFxyXG5cclxuICAgICAgY2hpbGRyZW46IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBmaW5kOiAoY291cnNlKSA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiBDb3Vyc2VTdWJqZWN0cy5jb2xsZWN0aW9uLmZpbmQoe2NvdXJzZUlkIDogY291cnNlLl9pZCB9LCB7XHJcbiAgICAgICAgICAgICAgc29ydDogeyBjcmVhdGVkQXQ6IC0xIH0sXHJcbiAgICAgICAgICAgICAgbGltaXQ6IDFcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIF1cclxuICB9XHJcbiAgfSk7XHJcblxyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ3N1YmplY3RzJywgZnVuY3Rpb24gKCk6IE1vbmdvLkN1cnNvcjxDb3Vyc2VTdWJqZWN0PiB7XHJcbiAgY29uc3QgbG9nZ2VkSW5Vc2VyID0gTWV0ZW9yLnVzZXIoKTtcclxuXHJcbiAgaWYgKCFsb2dnZWRJblVzZXIgfHxcclxuICAgICFSb2xlcy51c2VySXNJblJvbGUobG9nZ2VkSW5Vc2VyLCBbJ3R1dG9yJywgJ21hbmFnZS1jb3Vyc2VzJywgJ3ZpZXctY291cnNlcycsICdhZG1pbicsICdzdXBlci1hZG1pbiddLCAnY291cnNlcycpKSB7XHJcbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgJ0FjY2VzcyBkZW5pZWQnKVxyXG4gIH1cclxuICByZXR1cm4gQ291cnNlU3ViamVjdHMuY29sbGVjdGlvbi5maW5kKHtjb3Vyc2VJZDogbG9nZ2VkSW5Vc2VyLl9pZH0pO1xyXG59KTtcclxuXHJcblxyXG4iLCJpbXBvcnQge0ludml0YXRpb25zfSBmcm9tICcuLi8uLi9jb2xsZWN0aW9ucy91c2Vycy9pbnZpdGF0aW9ucyc7XG5cbk1ldGVvci5wdWJsaXNoKCAnaW52aXRlJywgZnVuY3Rpb24oIHRva2VuICkge1xuICBjaGVjayggdG9rZW4sIFN0cmluZyApO1xuICByZXR1cm4gSW52aXRhdGlvbnMuZmluZCggeyAndG9rZW4nOiB0b2tlbiB9ICk7XG59KTtcbiIsImltcG9ydCB7TWVzc2FnZX0gZnJvbSAnLi4vbW9kZWxzJztcclxuaW1wb3J0IHtNZXNzYWdlc30gZnJvbSAnLi4vLi4vY29sbGVjdGlvbnMnO1xyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ21lc3NhZ2VzJywgZnVuY3Rpb24gKFxyXG4gIGNoYXRJZDogc3RyaW5nLFxyXG4gIG1lc3NhZ2VzQmF0Y2hDb3VudGVyOiBudW1iZXIpOiBNb25nby5DdXJzb3I8TWVzc2FnZT4ge1xyXG4gIGlmICghdGhpcy51c2VySWQgfHwgIWNoYXRJZCkge1xyXG4gICAgY29uc29sZS5sb2coJ0ludmFsaWQgVXNlciEhIScpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICByZXR1cm4gTWVzc2FnZXMuY29sbGVjdGlvbi5maW5kKHtcclxuICAgIGNoYXRJZFxyXG4gIH0sIHtcclxuICAgIHNvcnQ6IHtjcmVhdGVkQXQ6IC0xfSxcclxuICAgIGxpbWl0OiAzMCAqIG1lc3NhZ2VzQmF0Y2hDb3VudGVyXHJcbiAgfSk7XHJcbn0pO1xyXG4iLCJpbXBvcnQge1ByZWRpY3Rpb25zfSBmcm9tICcuLi8uLi9jb2xsZWN0aW9ucyc7XHJcblxyXG5NZXRlb3IucHVibGlzaCgncHJlZGljdGlvbnMnLCBmdW5jdGlvbiAoKXtcclxuXHQvL1ByZWRpY3Rpb25zLnB1Ymxpc2godGhpcywgJ3RvdGFsLXByZWRpY3Rpb25zJywgUHJlZGljdGlvbnMuZmluZCgpKTtcclxuICBcdHJldHVybiBQcmVkaWN0aW9ucy5maW5kKHt9KTtcclxuXHJcbn0pO1xyXG4iLCJpbXBvcnQge1N0dWRlbnRzRGF0YX0gZnJvbSAnLi4vLi4vY29sbGVjdGlvbnMnO1xyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ3N0dWRlbnRzRGF0YScsIGZ1bmN0aW9uICgpe1xyXG4gIHJldHVybiBTdHVkZW50c0RhdGEuY29sbGVjdGlvbi5maW5kKCk7XHJcbn0pO1xyXG4iLCJpbXBvcnQge1RyYW5zYWN0aW9uc30gZnJvbSAnLi4vLi4vY29sbGVjdGlvbnMnO1xuXG5cbk1ldGVvci5wdWJsaXNoKCd0cmFuc2FjdGlvbnMnLCBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiBUcmFuc2FjdGlvbnMuY29sbGVjdGlvbi5maW5kKHt9KTtcbn0pO1xuIiwiXG4vLyBUcmFuc2FjdGlvbmFsXG5cbmltcG9ydCB7VHJhbnNhY3Rpb25BY2NvdW50fSBmcm9tICcuLi9tb2RlbHMnO1xuaW1wb3J0IHtUcmFuc2FjdGlvbkFjY291bnRzfSBmcm9tICcuLi8uLi9jb2xsZWN0aW9ucyc7XG5cbk1ldGVvci5wdWJsaXNoKCd0cmFuc2FjdGlvbl9hY2NvdW50cycsIGZ1bmN0aW9uICgpOiBNb25nby5DdXJzb3I8VHJhbnNhY3Rpb25BY2NvdW50PiB7XG4gIHJldHVybiBUcmFuc2FjdGlvbkFjY291bnRzLmNvbGxlY3Rpb24uZmluZCh7b3duZXJJZDogTWV0ZW9yLnVzZXJJZCgpIH0pO1xufSk7XG4iLCJpbXBvcnQge0ludml0YXRpb25zLCBVc2Vyc30gZnJvbSAnLi4vLi4vY29sbGVjdGlvbnMnO1xuXG5NZXRlb3IucHVibGlzaCggJ3VzZXJzJywgZnVuY3Rpb24oKSB7XG4gIGNvbnN0IGlzQWRtaW4gPSBSb2xlcy51c2VySXNJblJvbGUoIHRoaXMudXNlcklkLCBbJ21hbmFnZS11c2VycycsICdhZG1pbiddLCAndXNlcnMnKTtcblxuICBpZiAoIGlzQWRtaW4gKSB7XG4gICAgcmV0dXJuIFtcbiAgICAgIFVzZXJzLmZpbmQoIHt9LCB7IGZpZWxkczogeyAnZW1haWxzLmFkZHJlc3MnOiAxLCAncm9sZXMnOiAxIH0gfSApLFxuICAgICAgSW52aXRhdGlvbnMuZmluZCgge30sIHsgZmllbGRzOiB7ICdlbWFpbCc6IDEsICdyb2xlJzogMSwgJ2RhdGUnOiAxIH0gfSApXG4gICAgXTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufSk7XG5cblxuIiwiLy8vPHJlZmVyZW5jZSBwYXRoPVwiLi4vbm9kZV9tb2R1bGVzL0B0eXBlcy9tZXRlb3Itcm9sZXMvaW5kZXguZC50c1wiLz5cbmltcG9ydCB7Q2hhdHMsIENvdXJzZXMsIFByZWRpY3Rpb25zfSBmcm9tICcuLi9jb2xsZWN0aW9ucyc7XG5pbXBvcnQgeyBNZXNzYWdlcyB9IGZyb20gJy4uL2NvbGxlY3Rpb25zJztcbmltcG9ydCB7IE1lc3NhZ2VUeXBlLCBQcm9maWxlIH0gZnJvbSAnLi9tb2RlbHMnO1xuaW1wb3J0IHsgY2hlY2ssIE1hdGNoIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7IFByb21pc2UgfSBmcm9tICdtZXRlb3IvcHJvbWlzZSc7XG5cbmNvbnN0IG5vbkVtcHR5U3RyaW5nID0gTWF0Y2guV2hlcmUoKHN0cikgPT4ge1xuICBjaGVjayhzdHIsIFN0cmluZyk7XG4gIHJldHVybiBzdHIubGVuZ3RoID4gMDtcbn0pO1xuXG5jb25zdCBnZXRTdGFuZm9yZFVSTCA9IFwiaHR0cHM6Ly9oaXZkYi5zdGFuZm9yZC5lZHVcIjtcbmNvbnN0IHRpbWVvdXQ6IGFueSA9IDUwMDAwO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gIGFkZENoYXQocmVjZWl2ZXJJZDogc3RyaW5nKTogdm9pZCB7XG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndW5hdXRob3JpemVkJyxcbiAgICAgICAgJ1VzZXIgbXVzdCBiZSBsb2dnZWQtaW4gdG8gY3JlYXRlIGEgbmV3IGNoYXQnKTtcbiAgICB9XG5cbiAgICBjaGVjayhyZWNlaXZlcklkLCBub25FbXB0eVN0cmluZyk7XG5cbiAgICBpZiAocmVjZWl2ZXJJZCA9PT0gdGhpcy51c2VySWQpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2lsbGVnYWwtcmVjZWl2ZXInLFxuICAgICAgICAnUmVjZWl2ZXIgbXVzdCBiZSBkaWZmZXJlbnQgdGhhbiB0aGUgY3VycmVudCBsb2dnZWQgaW4gdXNlcicpO1xuICAgIH1cblxuICAgIGNvbnN0IGNoYXRFeGlzdHMgPSAhIUNoYXRzLmNvbGxlY3Rpb24uZmluZCh7XG4gICAgICBtZW1iZXJJZHM6IHsgJGFsbDogW3RoaXMudXNlcklkLCByZWNlaXZlcklkXSB9XG4gICAgfSkuY291bnQoKTtcblxuICAgIGlmIChjaGF0RXhpc3RzKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdjaGF0LWV4aXN0cycsXG4gICAgICAgICdDaGF0IGFscmVhZHkgZXhpc3RzJyk7XG4gICAgfVxuXG4gICAgY29uc3QgY2hhdCA9IHtcbiAgICAgIG1lbWJlcklkczogW3RoaXMudXNlcklkLCByZWNlaXZlcklkXVxuICAgIH07XG5cbiAgICBDaGF0cy5pbnNlcnQoY2hhdCk7XG4gIH0sIFxuICBzaWdudXAodXNlcm5hbWU6IHN0cmluZywgcGFzc3dvcmQgOiBzdHJpbmcsIGVtYWlsIDogc3RyaW5nLCBmbmFtZTogc3RyaW5nLCBsbmFtZTogc3RyaW5nLCBpbXNpIDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICBjaGVjayh1c2VybmFtZSwgbm9uRW1wdHlTdHJpbmcpO1xuICAgIGNoZWNrKHBhc3N3b3JkLCBub25FbXB0eVN0cmluZyk7XG4gICAgY2hlY2soZW1haWwsIG5vbkVtcHR5U3RyaW5nKTtcbiAgICBjaGVjayhmbmFtZSwgbm9uRW1wdHlTdHJpbmcpO1xuICAgIGNoZWNrKGxuYW1lLCBub25FbXB0eVN0cmluZyk7XG5cdFxuICAgIGNvbnN0IHVzZXIgPSB7XG5cdFx0dXNlcm5hbWU6IHVzZXJuYW1lLFxuXHRcdGVtYWlsIDogZW1haWwsXG5cdFx0cGFzc3dvcmQgOiBwYXNzd29yZCxcblx0XHRwcm9maWxlOiB7XG5cdFx0ICBuYW1lIDogZm5hbWUgKyBcIiBcIiArIGxuYW1lXG5cdFx0fVxuXHR9XG5cdFxuXHRyZXR1cm4gQWNjb3VudHMuY3JlYXRlVXNlcih1c2VyKTtcbiB9LFxuICByZW1vdmVDaGF0KGNoYXRJZDogc3RyaW5nKTogdm9pZCB7XG4gICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndW5hdXRob3JpemVkJyxcbiAgICAgICAgJ1VzZXIgbXVzdCBiZSBsb2dnZWQtaW4gdG8gcmVtb3ZlIGNoYXQnKTtcbiAgICB9XG4gICAgY2hlY2soY2hhdElkLCBub25FbXB0eVN0cmluZyk7XG4gICAgY29uc3QgY2hhdEV4aXN0cyA9ICEhQ2hhdHMuY29sbGVjdGlvbi5maW5kKGNoYXRJZCkuY291bnQoKTtcblxuICAgIGlmICghY2hhdEV4aXN0cykge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignY2hhdC1ub3QtZXhpc3RzJyxcbiAgICAgICAgJ0NoYXQgZG9lc25cXCd0IGV4aXN0Jyk7XG4gICAgfVxuXG4gICAgQ2hhdHMucmVtb3ZlKGNoYXRJZCk7XG4gIH0sXG4gIHVwZGF0ZVByb2ZpbGUocHJvZmlsZTogUHJvZmlsZSk6IHZvaWQge1xuICAgIGlmICghdGhpcy51c2VySWQpIHsgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndW5hdXRob3JpemVkJyxcbiAgICAgICdVc2VyIG11c3QgYmUgbG9nZ2VkLWluIHRvIGNyZWF0ZSBhIG5ldyBjaGF0Jyk7XG4gICAgfVxuICAgIGNoZWNrKHByb2ZpbGUsIHtcbiAgICAgIG5hbWU6IG5vbkVtcHR5U3RyaW5nXG4gICAgfSk7XG5cbiAgICBNZXRlb3IudXNlcnMudXBkYXRlKHRoaXMudXNlcklkLCB7XG4gICAgICAkc2V0OiB7cHJvZmlsZX1cbiAgICB9KTtcbiAgfSxcbiAgYWRkUm9sZVRvVXNlcih1c2VySWQsIHJvbGUsIGdyb3VwKSB7XG4gICAgaWYgKGdyb3VwKSB7XG4gICAgICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXModXNlcklkLCByb2xlLCBncm91cCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIFJvbGVzLmFkZFVzZXJzVG9Sb2xlcyh1c2VySWQsIHJvbGUpO1xuICAgIH1cbiAgfSxcbiAgcmVtb3ZlUm9sZUZyb21Vc2VyKHVzZXJJZCwgcm9sZSwgZ3JvdXA/KSB7XG4gICAgaWYgKGdyb3VwKSB7XG4gICAgICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXModXNlcklkLCByb2xlLCBncm91cCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIFJvbGVzLmFkZFVzZXJzVG9Sb2xlcyh1c2VySWQsIHJvbGUpO1xuICAgIH1cbiAgfSxcbiAgYWRkQ291cnNlKGNvdXJzZU5hbWUsIGNvdXJzZURlc2NyaXB0aW9uKSB7XG4gICAgaWYgKCF0aGlzLnVzZXJJZCkgeyB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1bmF1dGhvcml6ZWQnLFxuICAgICAgJ1VzZXIgbXVzdCBiZSBsb2dnZWQtaW4gdG8gY3JlYXRlIGEgbmV3IGNvdXJzZScpO1xuICAgIH1cblxuICAgIGNoZWNrKGNvdXJzZU5hbWUsIFN0cmluZyk7XG4gICAgY2hlY2soY291cnNlRGVzY3JpcHRpb24sIFN0cmluZyk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgY291cnNlOiBDb3Vyc2VzLmNvbGxlY3Rpb24uaW5zZXJ0KHtcbiAgICAgICAgbmFtZTogY291cnNlTmFtZSxcbiAgICAgICAgb3duZXJzaGlwOiB0aGlzLnVzZXJJZCxcbiAgICAgICAgZGVzY3JpcHRpb246IGNvdXJzZURlc2NyaXB0aW9uXG4gICAgICB9KVxuICAgIH07XG4gIH0sXG4gIGFkZE1lc3NhZ2UodHlwZTogTWVzc2FnZVR5cGUsIGNoYXRJZDogc3RyaW5nLCBjb250ZW50OiBzdHJpbmcpIHtcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7IHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ3VuYXV0aG9yaXplZCcsXG4gICAgICAnVXNlciBtdXN0IGJlIGxvZ2dlZC1pbiB0byBjcmVhdGUgYSBuZXcgY2hhdCcpO1xuICAgIH1cblxuICAgIGNoZWNrKHR5cGUsIE1hdGNoLk9uZU9mKFN0cmluZywgWyBNZXNzYWdlVHlwZS5URVhUIF0pKTtcbiAgICBjaGVjayhjaGF0SWQsIG5vbkVtcHR5U3RyaW5nKTtcbiAgICBjaGVjayhjb250ZW50LCBub25FbXB0eVN0cmluZyk7XG5cbiAgICBjb25zdCBjaGF0RXhpc3RzID0gISFDaGF0cy5jb2xsZWN0aW9uLmZpbmQoY2hhdElkKS5jb3VudCgpO1xuXG4gICAgaWYgKCFjaGF0RXhpc3RzKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdjaGF0LW5vdC1leGlzdHMnLFxuICAgICAgICAnQ2hhdCBkb2VzblxcJ3QgZXhpc3QnKTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgbWVzc2FnZUlkOiBNZXNzYWdlcy5jb2xsZWN0aW9uLmluc2VydCh7XG4gICAgICAgIGNoYXRJZDogY2hhdElkLFxuICAgICAgICBzZW5kZXJJZDogdGhpcy51c2VySWQsXG4gICAgICAgIGNvbnRlbnQ6IGNvbnRlbnQsXG4gICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgICAgICAgdHlwZTogdHlwZVxuICAgICAgfSlcbiAgICB9O1xuICB9LFxuICBjb3VudE1lc3NhZ2VzKCk6IG51bWJlciB7XG4gICAgcmV0dXJuIE1lc3NhZ2VzLmNvbGxlY3Rpb24uZmluZCgpLmNvdW50KCk7XG4gIH0sXG4gIGNyZWF0ZVN5c3RlbVVzZXIgKGVtYWlsLCBwYXNzd29yZCkge1xuICAgIEFjY291bnRzLmNyZWF0ZVVzZXIoe2VtYWlsOiBwYXNzd29yZH0pO1xuICB9LFxuXG4gIHByZWRpY3QoYm9keTogYW55LCBpc1NlcXVlbmNlPyA6IGJvb2xlYW4pIHtcbiAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCd1bmF1dGhvcml6ZWQnLFxuICAgICAgICAnVXNlciBtdXN0IGJlIGxvZ2dlZC1pbiB0byBjcmVhdGUgYSBuZXcgcmVxdWVzdCcpO1xuICAgIH1cbiAgICBjb25zb2xlLmxvZygnYm9keScsIGJvZHkpO1xuICAgIGxldCBib2R5Rm9ybWF0dGVkID0ge307XG4gICAgbGV0IHF1ZXJ5ID0ge307XG5cbiAgICBpZihpc1NlcXVlbmNlKSB7XG4gICAgICBib2R5Rm9ybWF0dGVkID0geyBcInNlcXVlbmNlc1wiOiBKU09OLnBhcnNlKGJvZHkuc2VxdWVuY2VzICkgfTsgICBcblxuICAgICAgY29uc29sZS5sb2coYm9keUZvcm1hdHRlZCk7XG4gICAgICBxdWVyeSA9IHtcbiAgICAgICAgb3BlcmF0aW9uTmFtZTpcImV4YW1wbGVcIlxuICAgICAgICAsXG4gICAgICAgICBxdWVyeSA6IFwicXVlcnkgZXhhbXBsZSgkc2VxdWVuY2VzOiBbVW5hbGlnbmVkU2VxdWVuY2VJbnB1dF0hKSB7ICAgdmlld2VyIHsgICAgIGN1cnJlbnRWZXJzaW9uIHsgdGV4dCwgcHVibGlzaERhdGUgfSwgICAgIHNlcXVlbmNlQW5hbHlzaXMoc2VxdWVuY2VzOiAkc2VxdWVuY2VzKSB7ICAgICAgICAgaW5wdXRTZXF1ZW5jZSB7ICAgICAgICAgaGVhZGVyLCAgICAgICAgIHNlcXVlbmNlLCAgICAgICAgIE1ENSwgICAgICAgICBTSEE1MTIgICAgICAgfSwgICAgICAgdmFsaWRhdGlvblJlc3VsdHMgeyAgICAgICAgIGxldmVsLCAgICAgICAgIG1lc3NhZ2UgICAgICAgfSwgICAgICAgYWJzb2x1dGVGaXJzdE5BLCAgICAgICBhbGlnbmVkR2VuZVNlcXVlbmNlcyB7ICAgICAgICAgZ2VuZSB7ICAgICAgICAgICBuYW1lLCAgICAgICAgICAgY29uc2Vuc3VzLCAgICAgICAgICAgbGVuZ3RoLCAgICAgICAgICAgZHJ1Z0NsYXNzZXMgeyAgICAgICAgICAgICBuYW1lLCAgICAgICAgICAgICBmdWxsTmFtZSwgICAgICAgICAgICAgZHJ1Z3MgeyAgICAgICAgICAgICAgIG5hbWUsICAgICAgICAgICAgICAgZGlzcGxheUFiYnIsICAgICAgICAgICAgICAgZnVsbE5hbWUgICAgICAgICAgICAgfSAgICAgICAgICAgfSwgICAgICAgICAgIG11dGF0aW9uVHlwZXMgICAgICAgICB9LCAgICAgICAgIGZpcnN0QUEsICAgICAgICAgbGFzdEFBLCAgICAgICAgIGZpcnN0TkEsICAgICAgICAgbGFzdE5BLCAgICAgICAgIG1hdGNoUGNudCwgICAgICAgICBwcmV0dHlQYWlyd2lzZSB7ICAgICAgICAgICBwb3NpdGlvbkxpbmUsICAgICAgICAgICByZWZBQUxpbmUsICAgICAgICAgICBhbGlnbmVkTkFzTGluZSwgICAgICAgICAgIG11dGF0aW9uTGluZSAgICAgICAgIH0sICAgICAgICAgbXV0YXRpb25zIHsgICAgICAgICAgIGNvbnNlbnN1cywgICAgICAgICAgIHBvc2l0aW9uLCAgICAgICAgICAgQUFzLCAgICAgICAgICAgdHJpcGxldCwgICAgICAgICAgIGluc2VydGVkTkFzLCAgICAgICAgICAgaXNJbnNlcnRpb24sICAgICAgICAgICBpc0RlbGV0aW9uLCAgICAgICAgICAgaXNJbmRlbCwgICAgICAgICAgIGlzQW1iaWd1b3VzLCAgICAgICAgICAgaXNBcG9iZWNNdXRhdGlvbiwgICAgICAgICAgIGlzQXBvYmVjRFJNLCAgICAgICAgICAgaGFzU3RvcCwgICAgICAgICAgIGlzVW51c3VhbCwgICAgICAgICAgIHR5cGVzLCAgICAgICAgICAgcHJpbWFyeVR5cGUsICAgICAgICAgICBjb21tZW50cyB7ICAgICAgICAgICAgIHRyaWdnZXJlZEFBcywgICAgICAgICAgICAgdHlwZSwgICAgICAgICAgICAgdGV4dCAgICAgICAgICAgfSwgICAgICAgICAgIHRleHQsICAgICAgICAgICBzaG9ydFRleHQgICAgICAgICB9LCAgICAgICAgIEFQT0JFQzogbXV0YXRpb25zKGZpbHRlck9wdGlvbnM6IFtBUE9CRUNdKSB7ICAgICAgICAgICBwb3NpdGlvbiwgICAgICAgICAgIEFBcywgICAgICAgICAgIHRleHQgICAgICAgICB9LCAgICAgICAgIEFQT0JFQ19EUk06IG11dGF0aW9ucyhmaWx0ZXJPcHRpb25zOiBbQVBPQkVDX0RSTV0pIHsgICAgICAgICAgIHRleHQgICAgICAgICB9LCAgICAgICAgIERSTTogbXV0YXRpb25zKGZpbHRlck9wdGlvbnM6IFtEUk1dKSB7ICAgICAgICAgICB0ZXh0ICAgICAgICAgfSwgICAgICAgICBTRFJNOiBtdXRhdGlvbnMoZmlsdGVyT3B0aW9uczogW1NEUk1dKSB7ICAgICAgICAgICB0ZXh0ICAgICAgICAgfSwgICAgICAgICB1bnVzdWFsTXV0YXRpb25zOiBtdXRhdGlvbnMoZmlsdGVyT3B0aW9uczogW1VOVVNVQUxdKSB7ICAgICAgICAgICB0ZXh0ICAgICAgICAgfSwgICAgICAgICB0cmVhdG1lbnRTZWxlY3RlZE11dGF0aW9uczogbXV0YXRpb25zKCAgICAgICAgICAgZmlsdGVyT3B0aW9uczogW1BJX1RTTSwgTlJUSV9UU00sIE5OUlRJX1RTTSwgSU5TVElfVFNNXSAgICAgICAgICkgeyAgICAgICAgICAgdGV4dCAgICAgICAgIH0sICAgICAgICAgZnJhbWVTaGlmdHMgeyAgICAgICAgICAgcG9zaXRpb24sICAgICAgICAgICBpc0luc2VydGlvbiwgICAgICAgICAgIGlzRGVsZXRpb24sICAgICAgICAgICBzaXplLCAgICAgICAgICAgTkFzLCAgICAgICAgICAgdGV4dCAgICAgICAgIH0gICAgICAgfSwgICAgICAgZmlyc3RUZW5DbG9zZVN1YnR5cGVzOiBzdWJ0eXBlc1YyKGZpcnN0OiAxMCkgeyAgICAgICAgIGRpc3BsYXlXaXRob3V0RGlzdGFuY2UsICAgICAgICAgZGlzdGFuY2VQY250LCAgICAgICAgIHJlZmVyZW5jZUFjY2Vzc2lvbiAgICAgICB9LCAgICAgICBiZXN0TWF0Y2hpbmdTdWJ0eXBlIHsgZGlzcGxheSB9LCAgICAgICBtaXh0dXJlUGNudCwgICAgICAgbXV0YXRpb25zIHsgICAgICAgICBwb3NpdGlvbiwgICAgICAgICBBQXMsICAgICAgICAgc2hvcnRUZXh0ICAgICAgIH0sICAgICAgIGZyYW1lU2hpZnRzIHsgICAgICAgICB0ZXh0ICAgICAgIH0sICAgICAgIGRydWdSZXNpc3RhbmNlIHsgICAgICAgICBnZW5lIHsgICAgICAgICAgIG5hbWUsICAgICAgICAgICBjb25zZW5zdXMsICAgICAgICAgICBsZW5ndGgsICAgICAgICAgICBkcnVnQ2xhc3NlcyB7IG5hbWUgfSwgICAgICAgICAgIG11dGF0aW9uVHlwZXMgICAgICAgICB9LCAgICAgICAgIGRydWdTY29yZXMgeyAgICAgICAgICAgZHJ1Z0NsYXNzIHsgICAgICAgICAgICAgbmFtZSwgICAgICAgICAgICAgZnVsbE5hbWUsICAgICAgICAgICAgIGRydWdzIHsgICAgICAgICAgICAgICBuYW1lLCAgICAgICAgICAgICAgIGRpc3BsYXlBYmJyLCAgICAgICAgICAgICAgIGZ1bGxOYW1lICAgICAgICAgICAgIH0gICAgICAgICAgIH0sICAgICAgICAgICBkcnVnIHsgZGlzcGxheUFiYnIgfSwgICAgICAgICAgIFNJUiwgICAgICAgICAgIHNjb3JlLCAgICAgICAgICAgbGV2ZWwsICAgICAgICAgICB0ZXh0LCAgICAgICAgICAgcGFydGlhbFNjb3JlcyB7ICAgICAgICAgICAgIG11dGF0aW9ucyB7ICAgICAgICAgICAgICAgdGV4dCAgICAgICAgICAgICB9LCAgICAgICAgICAgICBzY29yZSAgICAgICAgICAgfSAgICAgICAgIH0sICAgICAgICAgbXV0YXRpb25zQnlUeXBlcyB7ICAgICAgICAgICBtdXRhdGlvblR5cGUsICAgICAgICAgICBtdXRhdGlvbnMgeyAgICAgICAgICAgICBjb25zZW5zdXMsICAgICAgICAgICAgIHBvc2l0aW9uLCAgICAgICAgICAgICBBQXMsICAgICAgICAgICAgIHRyaXBsZXQsICAgICAgICAgICAgIGluc2VydGVkTkFzLCAgICAgICAgICAgICBpc0luc2VydGlvbiwgICAgICAgICAgICAgaXNEZWxldGlvbiwgICAgICAgICAgICAgaXNJbmRlbCwgICAgICAgICAgICAgaXNBbWJpZ3VvdXMsICAgICAgICAgICAgIGlzQXBvYmVjTXV0YXRpb24sICAgICAgICAgICAgIGlzQXBvYmVjRFJNLCAgICAgICAgICAgICBoYXNTdG9wLCAgICAgICAgICAgICBpc1VudXN1YWwsICAgICAgICAgICAgIHRleHQsICAgICAgICAgICAgIHNob3J0VGV4dCAgICAgICAgICAgfSAgICAgICAgIH0gICAgICAgICBjb21tZW50c0J5VHlwZXMgeyAgICAgICAgICAgY29tbWVudFR5cGUsICAgICAgICAgICBjb21tZW50cyB7ICAgICAgICAgICAgIHR5cGUsICAgICAgICAgICAgIHRleHQsICAgICAgICAgICAgIGhpZ2hsaWdodFRleHQgICAgICAgICAgIH0gICAgICAgICB9ICAgICAgIH0gICAgICAgICB9ICAgfSB9XCJcbiAgICAgICAgLFxuICAgICAgICB2YXJpYWJsZXMgOiBib2R5Rm9ybWF0dGVkXG4gICAgICB9O1xuXG4gICAgfSBlbHNlIHtcbiAgICAgIGJvZHlGb3JtYXR0ZWQgPSB7XCJtdXRhdGlvbnNcIjogSlNPTi5wYXJzZShib2R5Lm11dGF0aW9ucyApfTtcblxuICAgICAgIHF1ZXJ5ID0ge1xuICAgICAgICBxdWVyeTogXCJxdWVyeSBleGFtcGxlKCRtdXRhdGlvbnM6W1N0cmluZ10hKSB7ICB2aWV3ZXIgeyAgICBjdXJyZW50VmVyc2lvbiB7IHRleHQsIHB1Ymxpc2hEYXRlIH0sICAgIG11dGF0aW9uc0FuYWx5c2lzKG11dGF0aW9uczogJG11dGF0aW9ucykgeyAgICAgIHZhbGlkYXRpb25SZXN1bHRzIHtsZXZlbCwgICAgICAgICBtZXNzYWdlICAgICAgIH0sICAgICAgIGRydWdSZXNpc3RhbmNlIHsgICAgICAgICBnZW5lIHsgbmFtZSB9LCAgICAgICAgIGRydWdTY29yZXMgeyAgICAgICAgICAgZHJ1Z0NsYXNzIHsgbmFtZSB9LCAgICAgICAgICAgZHJ1ZyB7IG5hbWUsZGlzcGxheUFiYnIsZnVsbE5hbWV9LCAgICAgICAgICAgU0lSLCAgICAgICAgICAgc2NvcmUsICAgICAgICAgICBsZXZlbCwgICAgICAgICAgIHRleHQsICAgICAgICAgICBwYXJ0aWFsU2NvcmVzIHsgICAgICAgICAgICAgbXV0YXRpb25zIHsgICAgICAgICAgICAgICB0ZXh0ICAgICAgICAgICAgIH0sICAgICAgICAgICAgIHNjb3JlICAgICAgICAgICB9ICAgICAgICAgfSwgICAgICAgICBtdXRhdGlvbnNCeVR5cGVzIHsgICAgICAgICAgIG11dGF0aW9uVHlwZSwgICAgICAgICAgIG11dGF0aW9ucyB7ICAgICAgICAgICAgIHRleHQgICAgICAgICAgIH0gICAgICAgICB9ICAgICAgICAgY29tbWVudHNCeVR5cGVzIHsgICAgICAgICAgIGNvbW1lbnRUeXBlLCAgICAgICAgICAgY29tbWVudHMgeyAgICAgICAgICAgICB0ZXh0ICAgICAgICAgICB9ICAgICAgICAgfSAgICAgICB9ICAgICB9ICAgfSB9XCJcbiAgICAgICAgLFxuICAgICAgICB2YXJpYWJsZXM6ICBib2R5Rm9ybWF0dGVkIFxuICAgICAgfTtcblxuICAgfVxuXG4gICAgY29uc29sZS5sb2coYm9keUZvcm1hdHRlZCk7XG4gICAgY29uc29sZS5sb2cocXVlcnkpO1xuXG4gICAgbGV0IHRoZUJvZHkgPSBKU09OLnN0cmluZ2lmeShxdWVyeSk7XG5cbiAgICBjb25zdCBwcmVkaXRpb25SZXF1ZXN0ID0ge1xuICAgICAgcmVxdWVzdGVkQnk6IHRoaXMudXNlcklkLFxuICAgICAgcmVxdWVzdDogdGhlQm9keSxcbiAgICAgIHJlc3BvbnNlOiAnUEVORElORycsXG4gICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKClcbiAgICB9O1xuXG4gICAgbGV0IHByZWRpY3Rpb25JZCA9IFByZWRpY3Rpb25zLmNvbGxlY3Rpb24uaW5zZXJ0KHByZWRpdGlvblJlcXVlc3QpO1xuXG4gICAgY29uc29sZS5sb2coJ1NhdmUgUHJlZGljdGlvbiAnICsgcHJlZGljdGlvbklkKTtcbiAgICBjb25zb2xlLmxvZygnU2VuZGluZyAnICsgdGhlQm9keSk7XG5cbiAgICB2YXIgb3B0aW9ucyA9IHtcbiAgICAgIGhvc3Q6IGdldFN0YW5mb3JkVVJMLFxuICAgICAgcGF0aDogJy9ncmFwaHFsJyxcbiAgICAgIG1ldGhvZDogJ1BPU1QnLCBcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJ1xuICAgICAgfVxuICAgIH07XG4gICAgbGV0IGZldGNoID0gcmVxdWlyZSgnbm9kZS1mZXRjaCcpO1xuXG4gICAgbGV0IHRoZVJlc3BvbnNlID0gJyc7XG5cbiAgICBQcm9taXNlLmF3YWl0KFxuICAgICB0aGVSZXNwb25zZSA9IGZldGNoKG9wdGlvbnMuaG9zdCArIG9wdGlvbnMucGF0aCwge1xuICAgICAgbWV0aG9kOiBvcHRpb25zLm1ldGhvZCxcbiAgICAgIGhlYWRlcnM6IHsnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nfSxcbiAgICAgIGJvZHk6IHRoZUJvZHlcbiAgICB9KVxuICAgIC50aGVuKHJlc3BvbnNlID0+IHJlc3BvbnNlLmpzb24oKSlcbiAgICAudGhlbihyZXNwb25zZSA9PiByZXNwb25zZS5kYXRhLnZpZXdlcilcbiAgICAudGhlbihyZXNwb25zZSA9PiB7XG5cbiAgICAgIC8vdXBkYXRlIHJlc3BvbnNlXG4gICAgIFByZWRpY3Rpb25zLmNvbGxlY3Rpb24udXBkYXRlKHByZWRpY3Rpb25JZCwgeyRzZXQ6IHtyZXNwb25zZSA6IEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlKX0gfSk7XG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG5cbiAgICB9KVxuICAgIC5jYXRjaChlcnIgPT4ge1xuICAgICAgcmV0dXJuIGVycjtcblxuICAgIH0pKTtcbiAgICBcbiAgICBjb25zb2xlLmxvZyh0aGVSZXNwb25zZSk7XG5cbiAgICByZXR1cm4gdGhlUmVzcG9uc2U7XG4gIH1cblxuXG59KTtcblxuIiwiZXhwb3J0IGNvbnN0IERFRkFVTFRfUElDVFVSRV9VUkwgPSAnL2Fzc2V0cy9kZWZhdWx0LXByb2ZpbGUtcGljLnN2Zyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHJvZmlsZSB7XG4gIG5hbWU/OiBzdHJpbmc7XG4gIHBpY3R1cmU/OiBzdHJpbmc7XG4gIHBpY3R1cmVJZD86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBTdHVkZW50RGF0YSB7XG4gIF9pZD86IHN0cmluZztcbiAgbmFtZT86IHN0cmluZztcbiAgdXNlcm5hbWU/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBlbnVtIE1lc3NhZ2VUeXBlIHtcbiAgVEVYVCA9IDxhbnk+J3RleHQnLFxuICBMT0NBVElPTiA9IDxhbnk+J2xvY2F0aW9uJyxcbiAgUElDVFVSRSA9IDxhbnk+J3BpY3R1cmUnXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2hhdCB7XG4gIF9pZD86IHN0cmluZztcbiAgdGl0bGU/OiBzdHJpbmc7XG4gIHBpY3R1cmU/OiBzdHJpbmc7XG4gIGxhc3RNZXNzYWdlPzogTWVzc2FnZTtcbiAgbWVtYmVySWRzPzogc3RyaW5nW107XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWVzc2FnZSB7XG4gIF9pZD86IHN0cmluZztcbiAgY2hhdElkPzogc3RyaW5nO1xuICBzZW5kZXJJZD86IHN0cmluZztcbiAgY29udGVudD86IHN0cmluZztcbiAgY3JlYXRlZEF0PzogRGF0ZTtcbiAgdHlwZT86IE1lc3NhZ2VUeXBlXG4gIG93bmVyc2hpcD86IHN0cmluZztcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQ291cnNlIHtcbiAgX2lkPzogc3RyaW5nO1xuICBuYW1lPzogc3RyaW5nO1xuICBkZXNjcmlwdGlvbj86IHN0cmluZztcbiAgb3duZXJzaGlwPzogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvdXJzZVN1YmplY3Qge1xuICBfaWQ/OiBzdHJpbmc7XG4gIG5hbWU/OiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICBjb3Vyc2VJZD86IHN0cmluZztcbn1cblxuZXhwb3J0IGVudW0gUXVlc3Rpb25UeXBlIHtcbiAgT1BFTl9FTkRFRCA9ICdPUEVOX0VOREVEJyxcbiAgTVVMVElQTEVfQ0hPSUNFID0gJ01VTFRJUExFX0NIT0lDRScsXG4gIEJST0tFTl9QQVNTQUdFID0gJ0JST0tFTl9QQVNTQUdFJyxcbiAgTUFUQ0hJTkcgPSAnTUFUQ0hJTkcnXG59XG5cbmludGVyZmFjZSBRdWVzdGlvbiB7XG4gIGlkPzogc3RyaW5nO1xuICB0eXBlPzogUXVlc3Rpb25UeXBlO1xuICBxdWVyeT86IGFueTtcbiAgYW5zd2VyPzogYW55O1xuICBwYXlsb2FkPzogYW55O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFF1ZXN0aW9uQ2hvaWNlIHtcbiAgaWQ/OiBzdHJpbmc7XG4gIGNob2ljZT86IHN0cmluZztcbiAgaXNDb3JyZWN0PzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBBc3NpZ25tZW50IHtcbiAgaWQ/OiBzdHJpbmc7XG4gIHRpdGxlPzogc3RyaW5nO1xuICBxdWVzdGlvbnM/OiBRdWVzdGlvbltdO1xufVxuXG5leHBvcnQgZW51bSBSb2xlc0VudW0ge1xuICBBRE1JTiA9ICdBRE1JTicsXG4gIFNVUEVSX0FETUlOID0gJ1NVUEVSX0FETUlOJyxcbiAgVFVUT1IgPSAnVFVUT1InLFxuICBTVFVERU5UID0gJ1NUVURFTlQnLFxuICAnUEFSRU5UJyA9ICdQQVJFTlQnXG59XG5cbmV4cG9ydCBlbnVtIEFjdGlvblBlcm1pc3Npb25zRW51bSB7XG4gICAgICBDUkVBVEU9ICdDUkVBVEUnLFxuICAgICAgVklFVz0gJ1ZJRVcnLFxuICAgICAgVVBEQVRFPSAnVVBEQVRFJyxcbiAgICAgIERFTEVURT0gJ0RFTEVURSdcbn1cblxuZXhwb3J0IGludGVyZmFjZSBSb2xlIHtcbiAgX2lkPzogc3RyaW5nO1xuICBuYW1lPzogUm9sZXNFbnVtLFxuICBwZXJtaXNzaW9ucz86IEFjdGlvblBlcm1pc3Npb25cbn1cblxuZXhwb3J0IGludGVyZmFjZSBBY3Rpb25QZXJtaXNzaW9uIHtcbiAgX2lkPzogc3RyaW5nO1xuICBwZXJtaXNzaW9uPzogQWN0aW9uUGVybWlzc2lvbnNFbnVtXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVXNlciBleHRlbmRzIE1ldGVvci5Vc2VyIHtcbiAgcHJvZmlsZT86IFByb2ZpbGUsXG4gIHJvbGVJZD86IFtzdHJpbmddXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTG9jYXRpb24ge1xuICBsYXQ6IG51bWJlcjtcbiAgbG5nOiBudW1iZXI7XG4gIHpvb206IG51bWJlcjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQaWN0dXJlIHtcbiAgX2lkPzogc3RyaW5nO1xuICBjb21wbGV0ZT86IGJvb2xlYW47XG4gIGV4dGVuc2lvbj86IHN0cmluZztcbiAgbmFtZT86IHN0cmluZztcbiAgcHJvZ3Jlc3M/OiBudW1iZXI7XG4gIHNpemU/OiBudW1iZXI7XG4gIHN0b3JlPzogc3RyaW5nO1xuICB0b2tlbj86IHN0cmluZztcbiAgdHlwZT86IHN0cmluZztcbiAgdXBsb2FkZWRBdD86IERhdGU7XG4gIHVwbG9hZGluZz86IGJvb2xlYW47XG4gIHVybD86IHN0cmluZztcbiAgdXNlcklkPzogc3RyaW5nO1xufVxuXG5leHBvcnQgZW51bSBUcmFuc2FjdGlvblR5cGUge1xuICBCQUxBTkNFX0lOUVVJUlkgPSAnQkFMQU5DRV9JTlFVSVJZJyxcbiAgRlVORFNfVFJBTlNGRVIgPSAnRlVORFNfVFJBTlNGRVInXG59XG5cbmV4cG9ydCBlbnVtIFRyYW5zYWN0aW9uRGlyZWN0aW9uIHtcbiAgRk9SV0FSRD0gJ0ZPUldBUkQnLFxuICBSRVZFUlNBTD0gJ1JFVkVSU0FMJ1xufVxuXG5pbnRlcmZhY2UgVHJhbnNhY3Rpb25IZWFkZXIge1xuICBkaXJlY3Rpb24/OiBUcmFuc2FjdGlvbkRpcmVjdGlvbixcbiAgaXNSZXRyeT86IGJvb2xlYW4sXG4gIHJldHJ5Q291bnQ/OiBudW1iZXJcbn1cblxuZXhwb3J0IGVudW0gVHJhbnNhY3Rpb25TdGF0dXMge1xuICBQT1NURUQgPSAnUE9TVEVEJyxcbiAgUFJPQ0VTU0lORyA9ICdQUk9DRVNTSU5HJyxcbiAgUFJPQ0VTU0VEID0gJ1BST0NFU1NFRCcsXG4gIEZBSUxFRCA9ICdGQUlMRUQnXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVHJhbnNhY3Rpb24ge1xuICBfaWQ/OiBzdHJpbmc7XG4gIGluaXRpYXRvcklkPzogc3RyaW5nO1xuICByZWZJZD86IHN0cmluZztcbiAgaGVhZGVyPzogVHJhbnNhY3Rpb25IZWFkZXI7XG4gIHBheWxvYWQ/OiBhbnk7XG4gIHR5cGU6IFRyYW5zYWN0aW9uVHlwZSxcbiAgc3RhdHVzOiBUcmFuc2FjdGlvblN0YXR1c1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRyYW5zYWN0aW9uUmVmZXJlbmNlIHtcbiAgX2lkPzogc3RyaW5nLFxuICBjcmVhdGVkQXQ6IERhdGVcbn1cblxuZXhwb3J0IGludGVyZmFjZSBUcmFuc2FjdGlvbkFjY291bnQge1xuICBfaWQ/OiBzdHJpbmcsXG4gIG93bmVySWQ6IHN0cmluZyxcbiAgYWNjb3VudE51bWJlcj86IHN0cmluZyxcbiAgYWN0dWFsQmFsYW5jZT86IG51bWJlcixcbiAgYXZhaWxhYmxlQmFsYW5jZT86IG51bWJlclxufVxuXG5cblxuLypcbkhJViBEQlxuKi9cbmV4cG9ydCBpbnRlcmZhY2UgUHJlZGl0aW9uIHtcbiAgX2lkPzogc3RyaW5nLFxuICByZXF1ZXN0ZWRCeTogc3RyaW5nLFxuICByZXF1ZXN0OiBhbnksXG4gIHJlc3BvbnNlOiBhbnksXG4gIGNyZWF0ZWRBdDogRGF0ZVxuXG59XG4iLCIvLyBMaXN0ZW4gdG8gaW5jb21pbmcgSFRUUCByZXF1ZXN0cyAoY2FuIG9ubHkgYmUgdXNlZCBvbiB0aGUgc2VydmVyKS5cclxuaW1wb3J0IHtXZWJBcHB9IGZyb20gJ21ldGVvci93ZWJhcHAnO1xyXG5pbXBvcnQge0NvdXJzZXN9IGZyb20gJy4uL2NvbGxlY3Rpb25zJztcclxuaW1wb3J0IHtQcmVkaWN0aW9uc30gZnJvbSBcIi4uL2NvbGxlY3Rpb25zL2hpdmRiXCI7XHJcbmltcG9ydCB7Q291bnRzfSBmcm9tICdtZXRlb3Ivcm9zOnB1Ymxpc2gtY291bnRzJztcclxuXHJcbk1ldGVvci5wdWJsaXNoKCdwcmVkaWN0aW9ucy5jb3VudCcsIGZ1bmN0aW9uKHsgfSkge1xyXG5cclxuICBDb3VudHMucHVibGlzaCh0aGlzLCAncHJlZGljdGlvbnMuY291bnQnLCBQcmVkaWN0aW9ucy5maW5kKCkpO1xyXG59KTtcclxuXHJcbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvaGVsbG8nLCAocmVxLCByZXMsIG5leHQpID0+IHtcclxuICByZXMud3JpdGVIZWFkKDIwMCk7XHJcbiAgcmVzLmVuZChgSGVsbG8gd29ybGQgZnJvbTogJHtNZXRlb3IucmVsZWFzZX1gKTtcclxufSkudXNlKCcvY291cnNlcycsIChyZXEsIHJlcywgbmV4dCkgPT4ge1xyXG5cclxuICByZXMud3JpdGVIZWFkKDIwMCk7XHJcbiAgcmVzLmVuZChKU09OLnN0cmluZ2lmeShDb3Vyc2VzLmNvbGxlY3Rpb24uZmluZCh7fSkuZmV0Y2goKSkpO1xyXG59KS51c2UoJy9jb3Vyc2VzL2lkJywgKHJlcSwgcmVzLCBuZXh0KSA9PiB7XHJcblxyXG5cclxuICByZXMud3JpdGVIZWFkKDIwMCk7XHJcbiAgcmVzLmVuZChKU09OLnN0cmluZ2lmeShDb3Vyc2VzLmNvbGxlY3Rpb24uZmluZE9uZSh7fSkpKTtcclxufSk7XHJcblxyXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnO1xuaW1wb3J0IHtVc2Vyc30gZnJvbSBcIi4uL2NvbGxlY3Rpb25zL3VzZXJzXCI7XG5mdW5jdGlvbiBjb3VudEFjdGl2ZSAoKSB7XG4gIHJldHVybiAwO1xufVxuZnVuY3Rpb24gaW5zZXJ0ICh0eCkge1xuICBjb25zb2xlLmxvZygnY3VzdG9tIG1ldGhvZCA6dHggaW5zZXJ0IHNpbXVsYXRlZC4nICsgdHguc3RhdHVzKTtcbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBleGlzdHMgKCkge1xuICBjb25zb2xlLmxvZygnY3VzdG9tIG1ldGhvZCA6dHggaW5zZXJ0IHNpbXVsYXRlZC4nKTtcbiAgcmV0dXJuIHRydWU7XG59XG5cbk1ldGVvci5zdGFydHVwKCgpID0+IHtcbiAgLy9jb25zb2xlLmxvZyhBY2NvdW50cyk7XG4gIC8vQWNjb3VudHMuX2JjcnlwdFJvdW5kcyA9IDEwO1xuXG4gIGlmIChNZXRlb3Iuc2V0dGluZ3MpIHtcbiAgICAvL09iamVjdC5hc3NpZ24oQWNjb3VudHMuX29wdGlvbnMsIE1ldGVvci5zZXR0aW5nc1snYWNjb3VudHMtcGhvbmUnXSk7XG4gICAgLy8gU01TLnR3aWxpbyA9IE1ldGVvci5zZXR0aW5nc1sndHdpbGlvJ107XG4gIH1cblxuICBpZiAoVXNlcnMuY29sbGVjdGlvbi5maW5kKCkuY291bnQoKSA+IDApIHtcbiAgICByZXR1cm47XG4gIH1cblxufSk7XG5cbiJdfQ==
