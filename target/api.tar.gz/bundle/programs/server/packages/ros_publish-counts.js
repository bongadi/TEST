(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var Counts, publishCount;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/ros_publish-counts/packages/ros_publish-counts.js        //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ros:publish-counts/publish-counts.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 1
    Counts = {};                                                                                                       // 2
    Counts.publish = function (self, name, cursor, options) {                                                          // 3
        var initializing = true;                                                                                       // 4
        var handle;                                                                                                    // 5
        options = options || {};                                                                                       // 6
                                                                                                                       // 7
        var extraField, countFn;                                                                                       // 8
                                                                                                                       // 9
        if (options.countFromField) {                                                                                  // 10
            extraField = options.countFromField;                                                                       // 11
            if ('function' === typeof extraField) {                                                                    // 12
                countFn = Counts._safeAccessorFunction(extraField);                                                    // 13
            } else {                                                                                                   // 14
                countFn = function (doc) {                                                                             // 15
                    return doc[extraField] || 0;    // return 0 instead of undefined.                                  // 16
                }                                                                                                      // 17
            }                                                                                                          // 18
        } else if (options.countFromFieldLength) {                                                                     // 19
            extraField = options.countFromFieldLength;                                                                 // 20
            if ('function' === typeof extraField) {                                                                    // 21
                countFn = Counts._safeAccessorFunction(function (doc) {                                                // 22
                    return extraField(doc).length;                                                                     // 23
                });                                                                                                    // 24
            } else {                                                                                                   // 25
                countFn = function (doc) {                                                                             // 26
                    if (doc[extraField]) {                                                                             // 27
                        return doc[extraField].length;                                                                 // 28
                    } else {                                                                                           // 29
                        return 0;                                                                                      // 30
                    }                                                                                                  // 31
                }                                                                                                      // 32
            }                                                                                                          // 33
        }                                                                                                              // 34
                                                                                                                       // 35
                                                                                                                       // 36
        if (countFn && options.nonReactive)                                                                            // 37
            throw new Error("options.nonReactive is not yet supported with options.countFromFieldLength or options.countFromFieldSum");
                                                                                                                       // 39
        cursor._cursorDescription.options.fields = Counts._optimizeQueryFields(cursor._cursorDescription.options.fields, extraField);
                                                                                                                       // 41
        var count = 0;                                                                                                 // 42
                                                                                                                       // 43
        if (options.fastCount) {                                                                                       // 44
            if (cursor._cursorDescription.options.limit)                                                               // 45
                throw new Error("There is no reason to use fastCount with limit.  fastCount is to enable large data sets to have fast but potentially inaccurate cursors.");
                                                                                                                       // 47
            count = cursor.count();                                                                                    // 48
            cursor._cursorDescription.options.skip = count;                                                            // 49
        }                                                                                                              // 50
                                                                                                                       // 51
        var observers = {                                                                                              // 52
            added: function (doc) {                                                                                    // 53
                if (countFn) {                                                                                         // 54
                    count += countFn(doc);                                                                             // 55
                } else {                                                                                               // 56
                    count += 1;                                                                                        // 57
                }                                                                                                      // 58
                                                                                                                       // 59
                if (!initializing)                                                                                     // 60
                    self.changed('counts', name, {count: count});                                                      // 61
            },                                                                                                         // 62
            removed: function (doc) {                                                                                  // 63
                if (countFn) {                                                                                         // 64
                    count -= countFn(doc);                                                                             // 65
                } else {                                                                                               // 66
                    count -= 1;                                                                                        // 67
                }                                                                                                      // 68
                self.changed('counts', name, {count: count});                                                          // 69
            }                                                                                                          // 70
        };                                                                                                             // 71
                                                                                                                       // 72
        if (countFn) {                                                                                                 // 73
            observers.changed = function (newDoc, oldDoc) {                                                            // 74
                if (countFn) {                                                                                         // 75
                    count += countFn(newDoc) - countFn(oldDoc);                                                        // 76
                }                                                                                                      // 77
                                                                                                                       // 78
                self.changed('counts', name, {count: count});                                                          // 79
            };                                                                                                         // 80
        }                                                                                                              // 81
                                                                                                                       // 82
        if (!countFn) {                                                                                                // 83
            self.added('counts', name, {count: cursor.count()});                                                       // 84
            if (!options.noReady)                                                                                      // 85
                self.ready();                                                                                          // 86
        }                                                                                                              // 87
                                                                                                                       // 88
        if (!options.nonReactive)                                                                                      // 89
            handle = cursor.observe(observers);                                                                        // 90
                                                                                                                       // 91
        if (countFn)                                                                                                   // 92
            self.added('counts', name, {count: count});                                                                // 93
                                                                                                                       // 94
        if (!options.noReady)                                                                                          // 95
            self.ready();                                                                                              // 96
                                                                                                                       // 97
        initializing = false;                                                                                          // 98
                                                                                                                       // 99
        self.onStop(function () {                                                                                      // 100
            if (handle)                                                                                                // 101
                handle.stop();                                                                                         // 102
        });                                                                                                            // 103
                                                                                                                       // 104
        return {                                                                                                       // 105
            stop: function () {                                                                                        // 106
                if (handle) {                                                                                          // 107
                    handle.stop();                                                                                     // 108
                    handle = undefined;                                                                                // 109
                }                                                                                                      // 110
            }                                                                                                          // 111
        };                                                                                                             // 112
    };                                                                                                                 // 113
    // back compatibility                                                                                              // 114
    publishCount = Counts.publish;                                                                                     // 115
                                                                                                                       // 116
    Counts._safeAccessorFunction = function safeAccessorFunction(fn) {                                                 // 117
        // ensure that missing fields don't corrupt the count.  If the count field                                     // 118
        // doesn't exist, then it has a zero count.                                                                    // 119
        return function (doc) {                                                                                        // 120
            try {                                                                                                      // 121
                return fn(doc) || 0;    // return 0 instead of undefined                                               // 122
            }                                                                                                          // 123
            catch (err) {                                                                                              // 124
                if (err instanceof TypeError) {   // attempted to access property of undefined (i.e. deep access).     // 125
                    return 0;                                                                                          // 126
                } else {                                                                                               // 127
                    throw err;                                                                                         // 128
                }                                                                                                      // 129
            }                                                                                                          // 130
        };                                                                                                             // 131
    }                                                                                                                  // 132
                                                                                                                       // 133
    Counts._optimizeQueryFields = function optimizeQueryFields(fields, extraField) {                                   // 134
        switch (typeof extraField) {                                                                                   // 135
            case 'function':      // accessor function used.                                                           // 136
                if (undefined === fields) {                                                                            // 137
                    // user did not place restrictions on cursor fields.                                               // 138
                    console.warn('publish-counts: Collection cursor has no field limits and will fetch entire documents.  ' +
                        'consider specifying only required fields.');                                                  // 140
                    // if cursor field limits are empty to begin with, leave them empty.  it is the                    // 141
                    // user's responsibility to specify field limits when using accessor functions.                    // 142
                }                                                                                                      // 143
                // else user specified restrictions on cursor fields.  Meteor will ensure _id is one of them.          // 144
                // WARNING: unable to verify user included appropriate field for accessor function to work.  we can't hold their hand ;_;
                                                                                                                       // 146
                return fields;                                                                                         // 147
                                                                                                                       // 148
            case 'string':        // countFromField or countFromFieldLength has property name.                         // 149
                // extra field is a property                                                                           // 150
                                                                                                                       // 151
                // automatically set limits if none specified.  keep existing limits since user                        // 152
                // may use a cursor transform and specify a dynamic field to count, but require other                  // 153
                // fields in the transform process  (e.g. https://github.com/percolatestudio/publish-counts/issues/47).
                fields = fields || {};                                                                                 // 155
                // _id and extraField are required                                                                     // 156
                fields._id = true;                                                                                     // 157
                fields[extraField] = true;                                                                             // 158
                                                                                                                       // 159
                if (2 < _.keys(fields).length)                                                                         // 160
                    console.warn('publish-counts: unused fields detected in cursor fields option', _.omit(fields, ['_id', extraField]));
                                                                                                                       // 162
                // use modified field limits.  automatically defaults to _id and extraField if none specified by user. // 163
                return fields;                                                                                         // 164
                                                                                                                       // 165
            case 'undefined':     // basic count                                                                       // 166
                if (fields && 0 < _.keys(_.omit(fields, ['_id'])).length)                                              // 167
                    console.warn('publish-counts: unused fields removed from cursor fields option.', _.omit(fields, ['_id']));
                                                                                                                       // 169
                // dispose of user field limits, only _id is required                                                  // 170
                fields = {_id: true};                                                                                  // 171
                                                                                                                       // 172
                // use modified field limits.  automatically defaults to _id if none specified by user.                // 173
                return fields;                                                                                         // 174
                                                                                                                       // 175
            default:                                                                                                   // 176
                throw new Error("unknown invocation of Count.publish() detected.");                                    // 177
        }                                                                                                              // 178
    }                                                                                                                  // 179
}                                                                                                                      // 180
                                                                                                                       // 181
if (Meteor.isClient) {                                                                                                 // 182
    Counts = new Mongo.Collection('counts');                                                                           // 183
                                                                                                                       // 184
    Counts.get = function (name) {                                                                                     // 185
        var count = this.findOne(name);                                                                                // 186
        return count && count.count || 0;                                                                              // 187
    };                                                                                                                 // 188
                                                                                                                       // 189
    if (Package.templating) {                                                                                          // 190
        Package.templating.Template.registerHelper('getPublishedCount', function (name) {                              // 191
            return Counts.get(name);                                                                                   // 192
        });                                                                                                            // 193
    }                                                                                                                  // 194
}                                                                                                                      // 195
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("ros:publish-counts", {
  Counts: Counts,
  publishCount: publishCount
});

})();
